<?php
session_start();
//open connetion file
include_once("connection.php");
$con = new connection();
$con->connect();

// Select admin Information
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);

//session check
if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}
  
  
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Food Mania </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <script type="text/javascript">
      function chk()
      {
        var a=confirm("Are you want to sure delete this Dish.....?");
        if(a==true)
          return true;
        else
          return false;
      }
    </script>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <?php include_once("side_bar.php");	 ?>
        </div>

        <!-- top navigation -->
        <?php include_once("top_nav.php"); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left"></div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h1 align="center">Main Dishes</h1>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
					<div class="clearfix"></div>
                     
                    <h4 align="center"><a href="main_dishes_add.php" style="text-decoration:underline;">Click here to Add more Dishes</a></h4>
                    <?php 
					
					// Insert, Update, Delete in tbl_main_dishes
					if(isset($_GET['tmp']))
					{
						$tmp="delete";
						$main_dishes_id=$_GET['main_dishes_id'];
						$res=$con->iud_in_tbl_main_dishes($main_dishes_id,$tmp,$main_dishes_name,$main_dishes_is_status);
						if($res==false)
						header("Location:main_dishes.php?main_dishes_id=$main_dishes_id&table=recfound");
						else
							header("Location:main_dishes.php?main_dishes_id=$main_dishes_id");			
					}

					
					
					
					
					
					if(isset($_GET['table']))
					{ 
						if($_GET['table']=="yes")
						{?>
  			          	<h3 align="center" style="color:#93C">New Dish is Add in List</h3><?php	
    					} 
						elseif($_GET['table']=="no")
						{ ?>
		             	<h3 align="center" style="color:#F00">Dish is not Add... Please try again... after some time</h3> <?php
						}
            elseif($_GET['table']=="yesup")
            {?>
                    <h3 align="center" style="color:#93C"> Dish is Updated in List</h3><?php 
            }
            elseif($_GET['table']=="noup")
            { ?>
                  <h3 align="center" style="color:#F00">Dish is not Updated... Please try again... after some time</h3> <?php
            }
			elseif($_GET['table']=="recfound")
            { ?>
                  <h3 align="center" style="color:#F00">Dish is not Deleted.... Please First Delete All Sub dishes</h3> <?php
            }
					}		
           ?>
                    <div class="clearfix"></div>
                    <table class="table table-bordered" style="font-size:16px;text-align:center;">
                      <thead>
                        <tr class="dark" style="background:#FFC;">
                          <th style="text-align:center;">Dish Name</th>
                          <th style="text-align:center;">Status</th>
                          <th style="text-align:center;">Edit</th>
                          <th style="text-align:center;">Delete</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
          					  // Select all dishes from tbl_main_dishes
          					  $main_dishes_id="";
                      		  $res=$con->select_main_dishes($main_dishes_id);
          					  if($num=mysql_num_rows($res)>0)
          					  {
          						  while($ans=mysql_fetch_array($res))
          						  {
          							extract($ans);
          							echo "<tr>";  
          							  	echo "<td style='text-transform:capitalize;'>$main_dishes_name</td>"; ?>
          							  <td align="center" class="a-center ">
          								  <?php 
          								  if($main_dishes_is_status==1) 
          								  {?>
          								  	<img src="../../img/icon_img/cy.png" height="25" width="25"> <?php
          						  	      }
          								  else
          								  { ?>
                              <img src="../../img/icon_img/cn.png" height="25" width="25"> <?php
          								  }
          								   ?>  </td>
          							  <td><a href="main_dishes_add.php?main_dishes_id=<?php echo $main_dishes_id; ?>" style="font-size:20px;"><i class="glyphicon glyphicon-pencil"></i></a></td>
                                        <td><a onclick="return chk();" href="main_dishes.php?tmp=delete&main_dishes_id=<?php echo $main_dishes_id; ?>" style="font-size:20px;"><i class="glyphicon glyphicon-trash"></i></a></td>
          			   <?php          echo "</tr>";
          							}
          					  }
          					  else
          					  {
          						  echo "<tr>";?>
          						  	<td colspan="15" style="color:#C6F;">No Main Dishes are Available</td>
          <?php						  echo "</tr>";
          					  }
          					  ?>
                       </tbody>
                    </table>

                  </div>
                </div>
              </div>

              <div class="clearfix"></div>

              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once("footer.php"); ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>