<?php session_start();
//open connetion file
include_once("connection.php");
$con = new connection();
$con->connect();

// Select admin Information
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);


//session check
if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}


// show shot information about order in drop down bar when customer click on notification icon
$tmp="select_last_five_order";
$res=$con->iuds_order($tmp,$id,$status);
while($ans=mysql_fetch_array($res))
 { ?>
   <li id="show_order_info" <?php 
    if($ans['order_is_status']=="2")
    { ?>
      style="background-color:lightgreen" <?php 
    } ?> >
    
   <a href="order_full_details.php?order_id=<?php echo $ans['order_id']; ?>">
       <span id="customer_name"  style="text-transform:capitalize;"><?php 
        $register_id=$ans['register_id'];
        $tmp="select";
        $res2=$con->iuds_tbl_redister($tmp,$register_id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);
        echo $res2['register_fname']."&nbsp;".$res2['register_lname'];
        ?></span>
    <span id="customer_address" class="message" style="text-transform:capitalize;">
       <?php echo $ans['order_delivery_address']; ?>
     </span>
  </a>
</li><?php                 
  } ?>

  