<?php

class connection
{	
  	public function connect()
	{
       $con=mysql_connect("localhost","root","") or die("connection is not open");
       	mysql_select_db("db_foodmania",$con);
	}
	
	// Check user is available or not
	public function check_admin($uname,$pass)
	{
		$check_admin="SELECT * FROM tbl_admin WHERE admin_name='".$uname."' and admin_passwd='".$pass."'";
		$res=mysql_query($check_admin);
		$a=mysql_fetch_array($res);
		if($a[0]==1)
			return true;
		else
			return false;		
	}
	
	
	// Select admin Information & Select all this site information
	public function select_admin()
	{
		$select_admin="SELECT * FROM tbl_admin";
		$res=mysql_query($select_admin);
		return $res;
	}
	
	
	// Edit Admin Profile
	public function edit_admin($tmp,$name,$bod,$gender,$email,$passwd,$file_up,$food_add,$food_op_mon_sat,$food_cl_mon_sat,$food_op_sun_spe,$food_cl_sun_spe,$cno_1,$cno_2)
	{
		if($tmp=="update")
		{
			$edit_admin="UPDATE tbl_admin SET 
											admin_name='".$name."' , 
											admin_bod='".$bod."' , 
											admin_gender='".$gender."', 
											admin_email_id='".$email."', 
											admin_passwd='".$passwd."',
											admin_profile='".$file_up."'  
									WHERE 
											admin_id=1";
			if(mysql_query($edit_admin))
				return true;
			else
				return false;
		}
		elseif($tmp=="update_food_info")
		{
			$query="UPDATE tbl_admin SET 
						food_mania_address='".$food_add."',
						food_mania_op_mon_sat='".$food_op_mon_sat."',
						food_mania_cl_mon_sat='".$food_cl_mon_sat."',
						food_mania_op_sun_spe='".$food_op_sun_spe."',
						food_mania_cl_sun_spe='".$food_cl_sun_spe."',
						food_mania_cno_1='".$cno_1."',
						food_mania_cno_2='".$cno_2."' 
					WHERE admin_id=1";
			if(mysql_query($query))
				return true;
			else
				echo false;
		}
	}
	
	
    // Select all dishes from tbl_main_dishes
	public function select_main_dishes($main_dishes_id)
	{
		if(empty($main_dishes_id))
		{
			$select_dishes="SELECT * FROM tbl_main_dishes ORDER BY(main_dishes_name)";
			$res=mysql_query($select_dishes);
			return $res;
		}
		else
		{
			$select_dishes="SELECT * FROM tbl_main_dishes WHERE main_dishes_id=$main_dishes_id";
			$res=mysql_query($select_dishes);
			$ans=mysql_fetch_array($res);
			return $ans;
		}	
	}
	
	
	// Insert, Update, Delete in tbl_main_dishes
	public function iud_in_tbl_main_dishes($main_dishes_id,$tmp,$main_dishes_name,$main_dishes_is_status)
	{
		if($tmp=="insert")
		{
			$query="INSERT INTO tbl_main_dishes values(NULL,
													'".$main_dishes_name."',
													'".date("Y/m/d H:i:s")."',
													'".date("Y/m/d H:i:s")."',
													'".$main_dishes_is_status."')";
			if(mysql_query($query))
				return true;
			else
				return false;
			
		}
		elseif($tmp=="update")
		{
			$query="UPDATE tbl_main_dishes SET main_dishes_name='".$main_dishes_name."', main_dishes_modify_date='".date("Y/m/d H:i:s")."',main_dishes_is_status='".$main_dishes_is_status."' WHERE main_dishes_id='".$main_dishes_id."'";
					
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="delete")
		{
			$query="SELECT COUNT(sub_dishes_id) FROM tbl_sub_dishes WHERE main_dishes_id=$main_dishes_id";
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);
			if($ans[0]==0)
			{
				$query="DELETE FROM tbl_main_dishes WHERE main_dishes_id=$main_dishes_id";
				$res=mysql_query($query);
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	
	// Select All Dishes in Sub caratery
	public function select_sub_dishes($main_dishes_id,$sub_dishes_id)
	{
		if(!empty($main_dishes_id) && empty($sub_dishes_id))
		{
			$num_rec_per_page=10;
			if(isset($_GET['page']))
					$start_from=($_GET['page']-1) * $num_rec_per_page;
				else
					$start_from=0 * $num_rec_per_page;
			
			$query="SELECT * FROM tbl_sub_dishes where main_dishes_id=$main_dishes_id ORDER BY(sub_dishes_name) LIMIT $start_from,$num_rec_per_page";
			$res=mysql_query($query);
			return $res;
			
		}
		elseif(!empty($main_dishes_id) && !empty($sub_dishes_id))
		{
			$query="SELECT * FROM tbl_sub_dishes WHERE sub_dishes_id=$sub_dishes_id";
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);
			return  $ans;
		}
	}
	
	// Insert, Update, Delete in tbl_sub_dishes
	public function iud_in_tbl_sub_dishes($sub_dishes_id,$main_dishes_id,$tmp,$name,$price,$discription,$status,$img)
	{
		if($tmp=="insert")
		{
			$query="INSERT INTO tbl_sub_dishes VALUES (NULL,
													'".$main_dishes_id."',
													'".$name."',
													'".$price."',
													'".$img."',
													'".$discription."',
													'".date("Y/m/d H:i:s")."',
													'".date("Y/m/d H:i:s")."',
													'".$status."'
													)";
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="update")
		{
			$query="UPDATE tbl_sub_dishes SET sub_dishes_name='".$name."', sub_dishes_price='".$price."', sub_dishes_img='".$img."', sub_dishes_discription='".$discription."', sub_dishes_modify_date='".date("Y/m/d H:i:s")."', sub_dishes_is_status='".$status."' WHERE sub_dishes_id=".$sub_dishes_id;
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="delete")
		{
			$query="SELECT sub_dishes_img FROM tbl_sub_dishes WHERE sub_dishes_id=".$sub_dishes_id;
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);
			unlink("../../img/food_img/$ans[0]");
			$query2="DELETE FROM tbl_sub_dishes WHERE sub_dishes_id=".$sub_dishes_id;
			if(mysql_query($query2))
				return true;
			else
				return false;
		}
		elseif($tmp=="select_sub_dishes")
		{
			if(!empty($sub_dishes_id))
			{
				$query="SELECT * FROM tbl_sub_dishes WHERE sub_dishes_id=".$sub_dishes_id;
				$res=mysql_query($query);
				if($ans=mysql_fetch_array($res))
				{
					return $ans;
				}
				else
					return false;	
			}
			else
			{
				return "no_return_value";
			}
			
		}
		
	}
		
	// Insert, Update, Delete, Select In table tbl_register
	public function iuds_tbl_redister($tmp,$id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address)
	{
		if($tmp=="select")
		{
			if($id=="")
			{
				$num_rec_per_page=10;
			    if(isset($_GET['page']))
					$start_from=($_GET['page']-1) * $num_rec_per_page;
				else
					$start_from=0 * $num_rec_per_page;
				$query="SELECT * FROM tbl_register ORDER BY(register_fname) LIMIT $start_from,$num_rec_per_page";
				$res=mysql_query($query);
				return $res;
			}
			else
			{
				$query="SELECT * FROM tbl_register WHERE register_id=".$id;
				$res=mysql_query($query);
				$ans=mysql_fetch_array($res);
				return $ans;
			}
		}
		elseif($tmp=="update_status")
		{
			$query="UPDATE tbl_register SET register_is_status='".$status."' WHERE register_id=$id";
			$res=mysql_query($query);
			return $id;
			
		}
		elseif($tmp=="select_online_customer")
		{
			$query="SELECT * FROM tbl_register WHERE register_session='1' ORDER BY(register_fname)";
			$res=mysql_query($query);
			return $res;
		}
		
	}
	
	// Insert, Update, Delete, Select In table tbl_event
	public function iuds_tbl_event($tmp,$id,$name,$img,$start_date,$end_date,$discription,$img,$status)
	{
		if($tmp=="select")
		{
			if(!empty($id))
			{
				$query="SELECT * FROM tbl_event WHERE event_id=$id";
				$res=mysql_query($query);
				$ans=mysql_fetch_array($res);
				return $ans;
				
			}
			elseif(empty($id))
			{
				$num_rec_per_page=10;
			    if(isset($_GET['page']))
					$start_from=($_GET['page']-1) * $num_rec_per_page;
				else
					$start_from=0 * $num_rec_per_page;
				$query="SELECT * FROM tbl_event ORDER BY(event_start_date)  LIMIT $start_from,$num_rec_per_page";
				$res=mysql_query($query);
				return $res;
			}
		}
		elseif($tmp=="insert")
		{
			$query="INSERT INTO tbl_event VALUES(NULL,
										'".$name."',
										'".$start_date."',
										'".$end_date."',
										'".$discription."',
										'".$img."',
										'".date("Y/m/d H:i:s")."',
										'".date("Y/m/d H:i:s")."',
										'".$status."')";
			if(mysql_query($query))	
				return true;
			else
				return false;					
		}
		elseif($tmp=="delete")
		{
			$q="SELECT event_img FROM tbl_event WHERE event_id=".$event_id;
			$r=mysql_query($q);
			$a=mysql_fetch_array($r);
			unlink("../../img/event_img/$ans[0]");
			
			$query="DELETE FROM tbl_event WHERE event_id=$id";
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="update")
		{
			$query="UPDATE tbl_event SET event_name='".$name."', event_start_date='".$start_date."', event_end_date='".$end_date."', event_discription='".$discription."', event_img='".$img."', event_modify_date='".date("Y/m/d H:i:s")."',event_is_status='".$status."'  WHERE event_id=".$id;
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="delete_past_event")
		{
			//delete pase event form table tbl_event
			$query="DELETE FROM tbl_event WHERE event_end_date<='".date("Y/m/d H:i:s")."'";
			mysql_query($query);
		}
		elseif($tmp="select_live_event")
		{
			$query="SELECT * FROM tbl_event WHERE event_start_date<='".date("Y/m/d H:i:s")."' AND event_end_date>='".date("Y/m/d H:i:s")."' ORDER BY(event_start_date)";
				$res=mysql_query($query);
				return $res;
		}
	}
	
	
	// Insert, Update, Delete,select in tbl_slider
    public function iuds_tbl_slider($slider_id,$tmp,$status,$img)
	{
		if($tmp=="insert")
		{
			$query="INSERT INTO tbl_slider VALUES (NULL,
													'".$img."',
													'".date("Y/m/d H:i:s")."',
													'".date("Y/m/d H:i:s")."',
													'".$status."'
													)";
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="update")
		{
			$query="UPDATE tbl_slider SET slider_img='".$img."', slider_modify_date='".date("Y/m/d H:i:s")."', slider_is_status='".$status."' WHERE slider_id=".$slider_id;
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="delete")
		{
			$q="SELECT slider_img FROM tbl_slider WHERE slider_id=".$slider_id;
			$r=mysql_query($q);
			$a=mysql_fetch_array($r);
			unlink("../../img/event_img/$ans[0]");
			

			$query="DELETE FROM tbl_slider WHERE slider_id=$slider_id";
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="select")
		{
			$num_rec_per_page=10;
			if(!empty($slider_id))
			{
				$query="SELECT * FROM tbl_slider WHERE slider_id=".$slider_id;
				$res=mysql_query($query);
				if($ans=mysql_fetch_array($res))
					return $ans;
				else
					return false;
			}
			else
			{
				if(isset($_GET['page']))
					$start_from=($_GET['page']-1) * $num_rec_per_page;
				else
					$start_from=0 * $num_rec_per_page;
				
				$select_slider="SELECT * FROM tbl_slider ORDER BY(slider_id) DESC LIMIT $start_from,$num_rec_per_page";
				$res=mysql_query($select_slider);
				return $res;
			}
		}
		
	}
	
	//Count all customer, main dishes, subdishes & events
	public function count($tmp)
	{
		if($tmp=="count_customer")
		{
			$query="SELECT COUNT(register_id) FROM tbl_register WHERE register_is_status='1'";
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);	
			return $ans;
		}
		elseif($tmp=="count_main_dishes")
		{
			$query="SELECT COUNT(main_dishes_id) FROM tbl_main_dishes WHERE main_dishes_is_status='1'";
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);	
			return $ans;
		}
		elseif($tmp=="count_sub_dishes")
		{
			$query="SELECT COUNT(sub_dishes_id) FROM tbl_sub_dishes WHERE sub_dishes_is_status='1'";
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);	
			return $ans;
		}
		elseif($tmp=="count_feture_event")
		{
			$query="SELECT COUNT(event_id) FROM tbl_event WHERE event_is_status='1'";
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);	
			return $ans;
		}
		elseif($tmp=="count_panding_order")
		{		
			$query="SELECT COUNT(order_id) FROM tbl_order WHERE order_is_status='1' || order_is_status='2'";
			$res=mysql_query($query);
			if($ans=mysql_fetch_array($res))
				return $ans;
			else
				return false;
		}
		elseif($tmp=="count_todays_total_order")
		{
			$query="SELECT COUNT(order_id) FROM tbl_order WHERE order_is_status!='3' && order_modify_date<='".date("Y/m/d H:i:s")."' && order_modify_date>='".date("Y/m/d 00:00:00")."'";
			$res=mysql_query($query);
			if($ans=mysql_fetch_array($res))
				return $ans;
			else
				return false;
		}
		
			

	}

	//select and delete table tbl_feedback
	public function iuds_tbl_feedback($tmp,$feefback_id)
	{
		if($tmp=="select")
		{
			if(empty($feefback_id))
			{
				$num_rec_per_page=10;
			    if(isset($_GET['feedback_page']) && !empty($_GET['feedback_page']))
					$start_from=($_GET['feedback_page']-1) * $num_rec_per_page;
				else
					$start_from=0 * $num_rec_per_page;
			
				$query="SELECT * FROM tbl_feedback ORDER BY (feedback_entry_date)DESC LIMIT $start_from,$num_rec_per_page";
				if($res=mysql_query($query))
					return $res;
				else
					return false;
			}
			else
			{
				$query="SELECT * FROM tbl_feedback WHERE feedback_id=".$feefback_id;
				$res=mysql_query($query);
				if($ans=mysql_fetch_array($res))
					return $ans;
				else
					return false;

			}
		}
		elseif($tmp=="delete")
		{
			$query="DELETE FROM tbl_feedback WHERE feedback_id=".$feefback_id;
			mysql_query($query);
		}
	}

	//select order information
	public function iuds_order($tmp,$id,$status)
	{
		if($tmp=="select")
		{
			if(empty($id))
			{
				$num_rec_per_page=10;
			    if(isset($_GET['order_page']) && !empty($_GET['order_page']))
					$start_from=($_GET['order_page']-1) * $num_rec_per_page;
				else
					$start_from=0 * $num_rec_per_page;
			
				$query="SELECT * FROM tbl_order WHERE order_is_status!='3'  ORDER BY (order_entry_date) DESC LIMIT $start_from,$num_rec_per_page";
				if($res=mysql_query($query))
					return $res;
				else
					return false;
			}
			else
			{
				$query="SELECT * FROM tbl_order WHERE order_id=".$id;
				$res=mysql_query($query);
				if($ans=mysql_fetch_array($res))
					return $ans;
				else
					return false;
			}
			
		}
		elseif($tmp=="update_status")
		{
			$query="UPDATE tbl_order SET order_is_status='".$status."' WHERE order_id=".$id;
			if($res=mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="change_first_time_status")
		{
			$q="UPDATE tbl_order SET order_is_status='1' WHERE order_id=".$id;
			mysql_query($q);	
		}
		elseif($tmp=="select_order_information_form_suctomer_id")
		{

			$num_rec_per_page=10;
		    if(isset($_GET['page']) && !empty($_GET['page']))
				$start_from=($_GET['page']-1) * $num_rec_per_page;
			else
				$start_from=0 * $num_rec_per_page;
			
			$query="SELECT * FROM tbl_order WHERE register_id=".$id ." ORDER BY(order_entry_date)DESC LIMIT $start_from,$num_rec_per_page";
			if($res=mysql_query($query))
				return $res;
			else
				return false;
		}
		elseif($tmp=="count_total_order")
		{
			$query="SELECT COUNT(order_id) FROM tbl_order WHERE order_is_status=2";
			$res=mysql_query($query);
			if($ans=mysql_fetch_array($res))
				return $ans[0];
			else
				return false;
		}
		elseif($tmp=="select_last_five_order");
		{
			$query="SELECT * FROM tbl_order WHERE (order_is_status=2  OR order_is_status=1) ORDER BY order_id DESC LIMIT 0,5";
			if($ans=mysql_query($query))
				return $ans;
			else
				return false;
		}
	}

	//insert update delete and select table tbl_payment
	public function iuds_tbl_payment($tmp,$id,$payment_type,$status)
	{
		if($tmp=="select")
		{
			if(!empty($id))
			{
				$query="SELECT * FROM tbl_payment WHERE payment_id=".$id;
				$res=mysql_query($query);
				if($ans=mysql_fetch_array($res))
					return $ans;
				else
					return false;
			}
			else
			{
				$query="SELECT * FROM tbl_payment";
				if($res=mysql_query($query))
					return $res;
				else
					return false;
			}
		}
		elseif($tmp=="delete")
		{
			$query="DELETE FROM tbl_payment WHERE payment_id=".$id;
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="insert")
		{
			$query="INSERT INTO tbl_payment VALUES(NULL,
											'".$payment_type."',
											'".date("Y/m/d H:i:s")."',
											'".date("Y/m/d H:i:s")."',
											'".$status."'
											)";
			if(mysql_query($query))
				return true;
			else
				return false;
		}
		elseif($tmp=="update")
		{
			$query="UPDATE tbl_payment SET payment_type='".$payment_type."', payment_modify_date='".date("Y/m/d H:i:s")."',payment_is_status='".$status."' WHERE payment_id=".$id;
			if(mysql_query($query))
				return true;
			else
				return false;
		}
	}
	

	// insert update delete bill information
	public function iuds_tbl_bill($tmp,$bill_id,$order_id,$register_id,$payment_id)
	{
		if($tmp=="select")
		{
			if(!empty($bill_id))
			{
				$query="SELECT * FROM tbl_bill WHERE bill_id=".$bill_id;
				$res=mysql_query($query);
				if($ans=mysql_fetch_array($res))
					return $ans;
				else
					return false;
			}
			else
			{
				$num_rec_per_page=10;
			    if(isset($_GET['bill_page']) && !empty($_GET['bill_page']))
					$start_from=($_GET['bill_page']-1) * $num_rec_per_page;
				else
					$start_from=0 * $num_rec_per_page;
			
				
				$query="SELECT * FROM tbl_bill ORDER BY(bill_entry_date) DESC LIMIT $start_from,$num_rec_per_page";
				if($res=mysql_query($query))
					return $res;
				else
					return false;
			}
		}
	}		
}


?>