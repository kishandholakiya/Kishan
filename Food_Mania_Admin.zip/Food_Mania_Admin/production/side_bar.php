<div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="full_page.php" class="site_title"><img src="../../img/icon_img/hotel-reception-bell.png" height="45" width="45" /> <span>Food Mania</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="../../img/admin_profile_img/<?php echo $admin_profile; ?>" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo $admin_name; ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
               
                <ul class="nav side-menu">
                  <li> <a href="full_page.php"><img src="../../img/icon_img/home.png" />  Home</a>
                  </li>
                  
                  
                  <li><a href="main_dishes.php"><img src="../../img/icon_img/main_dishes_img.png" /> Main Dishes</a>  
                  </li>
                  
                  <li><a><img src="../../img/icon_img/sub_dishes_img.png"  /> Sub Dishes<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <?php 
					$res=$con->select_main_dishes($main_dishes_id);
					while($ans=mysql_fetch_array($res))
					{
						extract($ans);
						echo "<li><a href='sub_dishes.php?main_dishes_id=$main_dishes_id' style='text-transform:capitalize;'>$main_dishes_name</a></li>";
					}
					?>
                    </ul>
                  </li>
                  
                  <li><a href="slider.php"><img src="../../img/icon_img/category.png" />  Slider </span></a>
                  </li>
                  
                  
                  
                  
                  <li><a href="customer_details.php"><img src="../../img/icon_img/customer_information.png" />   </i> Customer Information</a>
                    
                  </li>
                  <li><a href="events.php"><img src="../../img/icon_img/event.png" />   Events  </a>
                                      </li>
                  <li><a href="reach_us.php"><img src="../../img/icon_img/reach_us.png" />    Reach Us</span></a>
                  </li>

                  <li><a href="payment.php"><img src="../../img/icon_img/payment.png" /> Payment</span></a>
                  </li>
                  
                </ul>
              </div>
              <div class="menu_section">
                <h3>Live On</h3>
                <ul class="nav side-menu">
                  <li><a href="online_customer.php"><img src="../../img/icon_img/online_customer.png" />    Online Customer</a>
                  </li>
                  
                  
                  <li><a href="live_events.php"><img src="../../img/icon_img/live_events.png" /> Live Event</a>
                  </li>
                  </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
            	<p style="font-size:13px;color:#fff0f5;text-align:center;"> good TRADITION good NUTRITION</p>  
            </div>
          </div>