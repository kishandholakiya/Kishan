<?php
session_start();
//open connetion file
include_once("connection.php");
$con = new connection();
$con->connect();

// Select admin Information
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);


//session check
if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}

// show notification number in top navigation bar
$tmp="count_total_order";
$res=$con->iuds_order($tmp,$id,$status);
echo $res;



?>