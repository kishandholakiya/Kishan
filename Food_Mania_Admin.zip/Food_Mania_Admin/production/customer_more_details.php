<?php
session_start();
//open connetion file
include_once("connection.php");
$con = new connection();
$con->connect();

//select all information about admin
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);

if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Food Mania</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">
	<!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <?php include_once("side_bar.php"); ?>
        </div>

        <!-- top navigation -->
        <?php include_once("top_nav.php"); ?>
        <!-- /top navigation -->

        <!-- page content -->
        
        <div class="right_col" role="main">
          <div class="">
            	<div class="row">
               		<div class="col-md-12 col-sm-12 col-xs-12">
                		<div align="center" class="x_panel" style="font-size:40px; margin-top:10px;">
                            <div class="col-md-1 col-sm-1 col-xs-1">
                            <?php 
                            if(isset($_GET['name']))
                            { ?>
                              <a class="glyphicon glyphicon-arrow-left" href="online_customer.php"></a> <?php 
                            }
                            else
                            { ?>
                              <a class="glyphicon glyphicon-arrow-left" href="customer_details.php"></a> <?php 
                            }
                            ?>
                            </div>

                            <div class="col-md-10 col-sm-10 col-xs-10">
                            <h1 align="center">Customer Information</h1>
                            </div>
                            
                  		</div>       
                	</div>
            	</div>
            <div class="clearfix"></div>
        
        <!--Show Information of customer  -->
      <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2>Personal Information</h2>	
                <ul class="nav navbar-right panel_toolbox">
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                  </li>
                  
                </ul>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
    		<?php
			$id=$_GET['register_id'];
			$fname=$lname=$address=$gender=$bod=$contect=$email=$pass=$status=$ip_address="";
			$tmp="select";
			// Insert, Update, Delete, Select In table tbl_register
			$res=$con->iuds_tbl_redister($tmp,$id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);
      extract($res);
			
			?>
            <div style="text-align:center;font-size:20px;">
            <?php 
			if(isset($_POST['btn_submit']))
			{
				if($_POST['status']=="on")
	                $status="1";
                else
	                $status="0";
				$tmp="update_status";
				$id=$_POST['id'];
				$fname=$lname=$address=$gender=$bod=$contect=$email=$pass=$ip_address="";
				$res=$con->iuds_tbl_redister($tmp,$id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);
				header("Location:customer_more_details.php?register_id=$res&m=1");
				
			}
			?>
            <form method="post" name="frm">
            <input type="hidden" name="id" value="<?php echo $register_id; ?>">
            <?php 
			if(isset($_GET['m']))
				{?>
				<h3 align="center" style="color:#93C">Status of Customer is changed...</h3><?php
				}?>
            
                <table style="border:">
                	<tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">First Name</td>
                        <td style="width:300px;text-transform:capitalize;"><?php echo $register_fname;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Last Name</td>
                        <td style="width:300px;text-transform:capitalize;"><?php echo $register_lname;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Address</td>
                        <td style="width:300px;text-transform:capitalize;"><?php echo $register_address;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Gender</td>
                        <td style="width:300px;"><?php echo $register_gender;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Date of Birth</td>
                        <td style="width:300px;"><?php echo $register_bod;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Contect No.</td>
                        <td style="width:300px;"><?php echo $register_contect_no;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Email_Id</td>
                        <td style="width:300px;"><?php echo $register_email_id;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Entry Date</td>
                        <td style="width:300px;"><?php echo $register_entry_date;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Modify Date</td>
                        <td style="width:300px;"><?php echo $register_modify_date;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Ip Address</td>
                        <td style="width:300px;"><?php echo $register_ip_address;?></td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;font-weight:600;">Status</td>
                        <td style="width:300px;"><div class="col-md-12 col-sm-12 col-xs-12">
                             <div class="">
                                <label>
                                  <input type="checkbox" name="status" class="js-switch" <?php 
                                      if($register_is_status=="1")
                                        echo "checked";
                                      else
                                        echo "";
                                      ?>/>
                                 
                                </label>
                             </div>
                            </div>
                        
                        
                        </td>
                    </tr>
                    
                    <tr style="height:50px;">
                    	<td style="width:300px;"><a class="btn btn-primary" href="customer	_details.php?register_id=<?php echo $register_id; ?>">Cancle</a></td>
                        <td style="width:300px;"><input name="btn_submit" id="btn_submit" type="submit" class="btn btn-success" value="Submit" onClick="return chk();">
                        
</td>
                    </tr>
                    
                   </table>	
                  </form>
                </div>
    
              </div>
            </div>
          </div>
</div>
	
    
    
    <!--Show Order Information of one customer-->
    <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2>Order Information</h2>	
                <ul class="nav navbar-right panel_toolbox">
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                  </li>
                  
                </ul>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
            		<table class="table table-bordered" style="font-size:16px;text-align:center;">
                      <thead>
                        <tr class="dark" style="background:#FFC;">
                          <th style="text-align:center;">Entry Date</th>
                          <th style="text-align:center;">Dish Information <small>(Name=>Taste=>Price=>Quantity=>total Price)</small></th>
                          <th style="text-align:center;">Total Price</th>
                          <th style="text-align:center;">Payment Type</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                      // Select all dishes from tbl_main_dishes
                      $tmp="select_order_information_form_suctomer_id";
                      $id=$_GET['register_id'];
                      $res=$con->iuds_order($tmp,$id,$status);
                      if($num=mysql_num_rows($res)>0)
                      {
                        while($ans=mysql_fetch_array($res))
                        {
                        extract($ans);
                        echo "<tr>";
                            ?><td style='text-transform:capitalize;'><?php echo $order_entry_date; ?></td>
                            
                            <td style='text-transform:capitalize;'><?php 
                            $ans1=explode(",", $order_total_quantity_and_price); 
                            $a=0;

                            $taste=explode(",", $taste_id); 
                            $i=0;
                            foreach($ans1 as $key1=>$value1)
                            {
                              $ans2=explode("-", $value1); 
                              foreach($ans2 as $key2=>$value2);
                              {
                                if(!empty($value2))
                                {
                                  $tmp="select_sub_dishes";
                                  $sub_dishes_id=$ans2[1];
                                  $main_dishes_id=$name=$price=$discription=$status=$img="";
                                  $res2=$con->iud_in_tbl_sub_dishes($sub_dishes_id,$main_dishes_id,$tmp,$name,$price,$discription,$status,$img);
                                   ?>

                                    <div class="row">
                                      <div class="col-sm-4">
                                        <?php echo $res2['sub_dishes_name']; ?> 
                                      </div>

                                      <div class="col-sm-3"><?php
                                       if($taste[$i]!=0)
                                        {
                                          $q2="SELECT taste_name FROM tbl_taste WHERE taste_id=".$taste[$i];
                                          $r2=mysql_query($q2);
                                          $a2=mysql_fetch_array($r2);
                                          echo $a2[0];
                                        }
                                        else
                                        {
                                          echo "No Taste";
                                        }?></div>


                                      <div class="col-sm-1">
                                        <?php echo $res2['sub_dishes_price']; ?>
                                      </div>


                                      <div class="col-sm-1">
                                        <?php echo $ans2[0]; ?> 
                                      </div>


                                      <div class="col-sm-3"> <?php 
                                        $b=$ans2[0]*$res2['sub_dishes_price']; 
                                        echo "₹&nbsp;".$b;?>
                                      </div><?php  
                                        $a=$a+$b;
                                        $i++;
                                        echo "<hr>" ?>
                                    </div>
                                  <?php 
                                }
                              }
                            } ?>
                            </td>

                            <td style='text-transform:capitalize;'><?php echo $a; ?></td>

                            <td><?php
                              $tmp="select";
                              $id=$payment_id;
                              $res2=$con->iuds_tbl_payment($tmp,$id,$payment_type,$status);
                              echo $res2['payment_type'];
                             ?></td>

                            
                   <?php          echo "</tr>";
                        }
                      }
                      else
                      {
                        echo "<tr>";?>
                          <td colspan="15" style="color:#C6F;">No Orders are Given by Customer</td>
          <?php             echo "</tr>";
                      }
                      ?>
                    </tbody>
                  </table>

                  <div align="center"> <?php
                    $num_rec_per_page=10;
                    //count total record of order of customer
                    $q="SELECT COUNT(register_id) FROM tbl_order WHERE register_id=$register_id ";
                    $r=mysql_query($q);
                    $a=mysql_fetch_array($r);
                    $total_records=$a[0];
                    if($num_rec_per_page>$total_records)
                    {
                      $total_pages=1;  
                    }
                    else
                    {
                      $total_pages = ceil($total_records / $num_rec_per_page); 
                    }

                    if(isset($_GET['page']))
                    {
                      $page=$_GET['page'];
                      if(3 <= $page && $page <= $total_pages-2)
                      {
                        $start=$page-2;
                        $end=$page+2;
                      }
                      elseif(2 == $page && $page <= $total_pages-2)
                      {
                        $start=$page-1;
                        $end=$page+2;
                      }
                      elseif(2 == $page && $page== $total_pages)
                      {
                        $start=$page-1;
                        $end=$page;
                      }
                      elseif(2 == $page && $page <= $total_pages-1)
                      {
                        $start=$page-1;
                        $end=$page+1;
                      }
                       
                      elseif(1 == $page && $page <= $total_pages-2)
                      {
                        $start=$page;
                        $end=$page+2;
                      }
                      elseif(1 == $page && $page == $total_pages-1)
                      {
                        $start=$page;
                        $end=$page+1;
                      }
                      elseif(1 == $page && $page == $total_pages)
                      {
                        $start=$page;
                        $end=$page;
                      }
                      elseif(2 == $page && $page == $total_pages)
                      {
                        $start=$page-1;
                        $end=$page+1;
                      }
                      elseif(2 == $page && $page == $total_pages-1)
                      {
                        $start=$page;
                        $end=$page+1;
                      }
                      elseif(3<= $page && $total_pages==$page+1)
                      {
                        $start=$page-2;
                        $end=$page+1;
                      }
                      elseif(3<= $page && $total_pages==$page)
                      {
                        $start=$page-2;
                        $end=$page;
                      }
                    }
                    else
                    {
                      $start=1;
                      if($total_pages==$start)
                      {
                        $end=$start;  
                      }
                      elseif($total_pages==$start+1)
                      {
                        $end=$start+1;
                      }
                      elseif($total_pages>=$start+2)
                      {
                        $end=$start+2;
                      }
                    }
                    echo "<a href='customer_more_details.php?register_id=$register_id&page=1'>".'<< first'."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
                      $j=1;  
                    for ($i=$start; $i<=$end; $i++) 
                    { 
                      if($i==$_GET['page'] || ($j==1 && !isset($_GET['page'])))
                      {
                        echo "&nbsp;&nbsp;<a style='color:red;' href='customer_more_details.php?register_id=$register_id&page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                      }
                      else
                      {
                        echo "&nbsp;&nbsp;<a href='customer_more_details.php?register_id=$register_id&page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                      
                      }
                      $j++;
                    }
                    
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='customer_more_details.php?register_id=$register_id&page=$total_pages'>".'last >>'."</a> ";  ?>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

            
      
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once("footer.php"); ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.php5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
	<!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
	
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
    
    
    <!--Check Update Status-->
    <script language="javascript">
	function chk()
	{
		var a=confirm("Are You Sure for Change status of Customer.....?");
		if(a==true)
			return true;
		else
			return false;
	}
	</script>
    <!-- /Check Update Status-->
  </body>
</html>