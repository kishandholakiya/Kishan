<?php
session_start();
include_once("connection.php");
$con = new connection();
$con->connect();

// Select admin Information
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);

//session check
if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Food Mania</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <?php include_once("side_bar.php"); ?>
        </div>
       

        <!-- top navigation -->
        	<?php include_once("top_nav.php"); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title" align="center" style="font-size:40px; margin-top:10px;">
                    <div class="col-md-1 col-sm-1 col-xs-1">
                      <?php 
                      if(isset($_GET['name']))
                      { ?>
                        <a class="glyphicon glyphicon-arrow-left" href="live_events.php"></a> <?php 
                      }
                      else
                      { ?>
                        <a class="glyphicon glyphicon-arrow-left" href="events.php"></a> <?php
                      } ?>
                    </div>

                    <div class="col-md-10 col-sm-10 col-xs-10">
                    <h1 align="center">Event Information</h1>
                    </div>
                            
                  		
                  <div class="clearfix"></div>
                </div>
                <?php 
        				if(isset($_GET['notic']))
                {
                  if($_GET['notic']=="yesup")
                  {?>
                    <h3 align="center" style="color:#93C">Event is Updated...</h3>
              <?php }
                  elseif($_GET['notic']=="noup")
                  {?>
                    <h3 align="center" style="color:#F00">Event is not Updated... Please Check Connection</h3>
              <?php   }
                  
              }

                if(isset($_GET['event_id']))
        				{	
        					$tmp="select";
        					$id=$_GET['event_id'];
        					$name=$img=$start_date=$end_date=$discription=$status="";
        					$res=$con->iuds_tbl_event($tmp,$id,$name,$img,$start_date,$end_date,$discription,$img,$status);
        					extract($res);
        					
        				}
        				?>
                
                  <div class="x_content">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
                      <br>
                      <a href="events_add.php?event_id=<?php echo $_GET['event_id']; ?>" class="btn btn-success" style="width:200px;font-size:20px;"><i class="fa fa-edit m-right-xs"></i>Edit Event</a><br><br>
						<div style="font-size:20px;">
                        <table>
                        	<tr style="height:50px;">
                            	<td style="width:300px;font-weight:600;">Event Name</td>
                                <td style="width:300px;text-transform:capitalization;"><?php echo $event_name;?></td>
                            </tr>
                            
                            <tr style="height:50px;">
                            	<td style="width:300px;font-weight:600;">Starting Time</td>
                                <td style="width:300px;"><?php echo $event_start_date;?></td>
                            </tr>
                            
                            <tr style="height:50px;">
                            	<td style="width:300px;font-weight:600;">Ending Time</td>
                                <td style="width:300px;"><?php echo $event_end_date;?></td>
                            </tr>
                            
                            <tr style="height:50px;">
                            	<td style="width:300px;font-weight:600;">Discription</td>
                                <td style="width:300px;"><?php echo $event_discription;?></td>
                            </tr>
                            
                            <tr style="height:50px;">
                            	<td style="width:300px;font-weight:600;">Status</td>
                                <td style="width:300px;"><?php 
								  if($event_is_status=="1") 
								  {?>
								  	<img src="../../img/icon_img/cy.png" height="25" width="25"> <?php
						  	      }
								  else
								  { ?>
                                  	<img src="../../img/icon_img/cn.png" height="25" width="25"> <?php
								  }
								   ?>  
</td>
                            </tr>
                            
                            <tr style="height:50px;">
                            	<td style="width:300px;font-weight:600;">Image of Event</td>
                                <td style="width:300px;"><div align="center"><img class="img-responsive img-rounded avatar-view" src="../../img/event_img/<?php echo $event_img; ?>" height="200px" width="200px"></div></td>
                            </tr>
                            
                        </table><br>
                        
                       	</div>		
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once("footer.php"); ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- morris.js -->
    <script src="../vendors/raphael/raphael.min.js"></script>
    <script src="../vendors/morris.js/morris.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <script>
      $(function() {
        Morris.Bar({
          element: 'graph_bar',
          data: [
            { "period": "Jan", "Hours worked": 80 }, 
            { "period": "Feb", "Hours worked": 125 }, 
            { "period": "Mar", "Hours worked": 176 }, 
            { "period": "Apr", "Hours worked": 224 }, 
            { "period": "May", "Hours worked": 265 }, 
            { "period": "Jun", "Hours worked": 314 }, 
            { "period": "Jul", "Hours worked": 347 }, 
            { "period": "Aug", "Hours worked": 287 }, 
            { "period": "Sep", "Hours worked": 240 }, 
            { "period": "Oct", "Hours worked": 211 }
          ],
          xkey: 'period',
          hideHover: 'auto',
          barColors: ['#26B99A', '#34495E', '#ACADAC', '#3498DB'],
          ykeys: ['Hours worked', 'sorned'],
          labels: ['Hours worked', 'SORN'],
          xLabelAngle: 60,
          resize: true
        });

        $MENU_TOGGLE.on('click', function() {
          $(window).resize();
        });
      });
    </script>

    <!-- datepicker -->
    <script type="text/javascript">
      $(document).ready(function() {

        var cb = function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
          $('#reportrange span').php(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
          //alert("Callback has fired: [" + start.format('MMMM D, YYYY') + " to " + end.format('MMMM D, YYYY') + ", label = " + label + "]");
        }

        var optionSet1 = {
          startDate: moment().subtract(29, 'days'),
          endDate: moment(),
          minDate: '01/01/2012',
          maxDate: '12/31/2015',
          dateLimit: {
            days: 60
          },
          showDropdowns: true,
          showWeekNumbers: true,
          timePicker: false,
          timePickerIncrement: 1,
          timePicker12Hour: true,
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          opens: 'left',
          buttonClasses: ['btn btn-default'],
          applyClass: 'btn-small btn-primary',
          cancelClass: 'btn-small',
          format: 'MM/DD/YYYY',
          separator: ' to ',
          locale: {
            applyLabel: 'Submit',
            cancelLabel: 'Clear',
            fromLabel: 'From',
            toLabel: 'To',
            customRangeLabel: 'Custom',
            daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            firstDay: 1
          }
        };
        $('#reportrange span').php(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
        $('#reportrange').daterangepicker(optionSet1, cb);
        $('#reportrange').on('show.daterangepicker', function() {
          console.log("show event fired");
        });
        $('#reportrange').on('hide.daterangepicker', function() {
          console.log("hide event fired");
        });
        $('#reportrange').on('apply.daterangepicker', function(ev, picker) {
          console.log("apply event fired, start/end dates are " + picker.startDate.format('MMMM D, YYYY') + " to " + picker.endDate.format('MMMM D, YYYY'));
        });
        $('#reportrange').on('cancel.daterangepicker', function(ev, picker) {
          console.log("cancel event fired");
        });
        $('#options1').click(function() {
          $('#reportrange').data('daterangepicker').setOptions(optionSet1, cb);
        });
        $('#options2').click(function() {
          $('#reportrange').data('daterangepicker').setOptions(optionSet2, cb);
        });
        $('#destroy').click(function() {
          $('#reportrange').data('daterangepicker').remove();
        });
      });
    </script>
    <!-- /datepicker -->
  </body>
</html>