<?php
session_start();
//open connetion file
include_once("connection.php");
$con = new connection();
$con->connect();

// Select admin Information
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);

//session check
if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}
  
  
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Food Mania </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <?php include_once("side_bar.php");	 ?>
        </div>

        <!-- top navigation -->
        <?php include_once("top_nav.php"); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left"></div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h1 align="center">Payment</h1>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
          					<div class="clearfix"></div>
                      <h4 align="center"><a href="payment_add.php" style="text-decoration:underline;">Click here to Add more Payment type</a></h4>
                      <?php 
                      if(isset($_GET['notic']))
                      { 
                        if($_GET['notic']=="yes")
                        {?>
                                <h3 align="center" style="color:#93C">New Payment type is Added</h3><?php 
                          } 
                        elseif($_GET['notic']=="no")
                        { ?>
                              <h3 align="center" style="color:#F00">Payment type is not Added... Please try Again</h3> <?php
                        }
                        elseif($_GET['notic']=="yesup")
                        {?>
                                <h3 align="center" style="color:#93C"> Payment type is Updated</h3><?php 
                        }
                        elseif($_GET['notic']=="noup")
                        { ?>
                              <h3 align="center" style="color:#F00">Payment type is not Updated... Please try again... </h3> <?php
                        }
                      } ?>
          					<div class="clearfix"></div>
                      <table class="table table-bordered" style="font-size:16px;text-align:center;">
                      <thead>
                        <tr class="dark" style="background:#FFC;">
                          <th style="text-align:center;">Payment Type</th>
                          <th style="text-align:center;">Status</th>
                          <th style="text-align:center;">Edit</th>
                          <th style="text-align:center;">Delete</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                        // Insert, Update, Delete,select in tbl_slider
                        if(isset($_GET['tmp']))
                        {
                          $tmp="delete";
                          $id=$_GET['payment_id'];
                          $res=$con->iuds_tbl_payment($tmp,$id,$payment_type,$status);
                          if($res==true)
                            header("Location:payment.php");
                          else
                            header("Location:payment.php");
                        }
                        
                        // Insert, Update, Delete,select in tbl_slider
                        $tmp="select";
                        $res=$con->iuds_tbl_payment($tmp,$id,$payment_type,$status);
                        
                        if(mysql_num_rows($res)>0)
                        {
                          while($ans=mysql_fetch_array($res))
                          {
                            extract($ans);  
                            echo "<tr>";?>
                      
                              <td style='text-transform:capitalize;'><?php echo $payment_type; ?></td> 
                              
                            <td align="center" class="a-center ">
                              <?php 
                              if($payment_is_status==1) 
                              {?>
                                <img src="../../img/icon_img/cy.png" style="height:25px;width:25px;"> <?php
                                  }
                              else
                              { ?>
                                <img src="../../img/icon_img/cn.png" style="height:25px;width:25px;"> <?php
                              }
                               ?>  
                                              </td>
                            <td><a href="payment_add.php?payment_id=<?php echo $payment_id; ?>" style="font-size:20px;"><i class="glyphicon glyphicon-pencil"></i></a></td>
                              
                            <td><a onClick="return chk();" href="payment.php?tmp=delete&payment_id=<?php echo $payment_id; ?>" style="font-size:20px;"><i class="glyphicon glyphicon-trash"></i></a></td>
                     <?php          echo "</tr>";
                          $tempary_id++;
                          }
                        }
                        else
                        {
                          echo "<tr>";?>
                            <td colspan="15" style="color:#C6F;">No slider are Available</td>
            <?php             echo "</tr>";
                        }
                        ?>
                       </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div class="clearfix"></div>
              </div>
              
              
              <!-- Payment informatin start-->      
              <div class="row">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                      <div class="x_title">
                        <h2>Bill Information</h2>	
                        <ul class="nav navbar-right panel_toolbox">
                          <li><a class="collapse-link"></a></li>
                          <li><a class="collapse-link"></a></li>
                          <li><a class="collapse-link"></a></li>
                          <li><a class="collapse-link"></a></li>
                          <li><a class="collapse-link"></a></li>
                          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                          </li>
                          
                        </ul>
                        <div class="clearfix"></div>
                      </div>
                      <div class="x_content">
                           <table class="table table-bordered" style="font-size:16px;text-align:center;">
                              <thead>
                                <tr class="dark" style="background:#FFC;">
                                  <th style="text-align:center;">Customer Name</th>
                                  <th style="text-align:center;">Payment Type</th>
                                  <th style="text-align:center;">Total Payment</th>
                                  <th style="text-align:center;">Entry Date</th>
                                </tr>
                              </thead>
                              
                              <tbody>
                              <?php 
                      // Select all dishes from tbl_bill
                      $tmp="select";
                      $res=$con->iuds_tbl_bill($tmp,$bill_id,$order_id,$register_id,$payment_id);
                      if($num=mysql_num_rows($res)>0)
                      {
                        while($ans=mysql_fetch_array($res))
                        {
                        extract($ans);
                        echo "<tr>";
                            ?>
                            <td style='text-transform:capitalize;'><?php
                              //select all customer name 
                              $tmp="select"; 
                              $r_id=$register_id;
                              $res2=$con->iuds_tbl_redister($tmp,$r_id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);  
                              echo  $res2['register_fname']."&nbsp;".$res2['register_lname']; ?>
                            </td>

                            <td style='text-transform:capitalize;'><?php 
                              //select payment name form payment id
                              $tmp="select";
                              $p_id=$payment_id;
                              $res3=$con->iuds_tbl_payment($tmp,$p_id,$payment_type,$status);
                               echo $res3['payment_type'];
                               ?>
                            </td>

                            <td style='text-transform:capitalize;'><?php 
                            $res4=$con->iuds_order($tmp,$order_id,$status);
                            extract($res4);
                            $ans1=explode(",", $order_total_quantity_and_price); 
                            $a=0;
                            foreach($ans1 as $key1=>$value1)
                            {
                              $ans2=explode("-", $value1); 
                              foreach($ans2 as $key2=>$value2);
                              {
                                $tmp="select_sub_dishes";
                                $sub_dishes_id=$ans2[1];
                                $main_dishes_id=$name=$price=$discription=$status=$img="";
                                $res4=$con->iud_in_tbl_sub_dishes($sub_dishes_id,$main_dishes_id,$tmp,$name,$price,$discription,$status,$img);
                                $b=$ans2[0]*$res4['sub_dishes_price']; 
                                $a=$a+$b;
                              }
                              
                            } 
                            echo "₹&nbsp;".$a; ?></td>

                            <td style='text-transform:capitalize;'><?php echo $bill_entry_date; ?></td>
                           </tr><?php   
                        }
                      }
                      else
                      {
                        echo "<tr>";?>
                          <td colspan="15" style="color:#C6F;">No Payment are Transferred</td>
          <?php             echo "</tr>";
                      }
                      ?>
                               </tbody>
                            </table>
                            <div align="center"><?php
                              $num_rec_per_page=10;
                              //count total record of slider
                              $q="SELECT COUNT(order_id) FROM tbl_order WHERE order_is_status!='3'   ORDER BY (order_entry_date) DESC ";
                              $r=mysql_query($q);
                              $a=mysql_fetch_array($r);
                              $total_records=$a[0];

                              if($num_rec_per_page>$total_records)
                              {
                                $total_pages=1;  
                              }
                              else
                              {
                                $total_pages = ceil($total_records / $num_rec_per_page); 
                              }
                                
                              if(isset($_GET['order_page']))
                              {
                                $order_page=$_GET['order_page'];
                                if(3 <= $order_page && $order_page <= $total_pages-2)
                                {
                                  $start=$order_page-2;
                                  $end=$order_page+2;
                                }
                                elseif(2 == $order_page && $order_page <= $total_pages-2)
                                {
                                  $start=$order_page-1;
                                  $end=$order_page+2;
                                }
                                elseif(2 == $order_page && $order_page== $total_pages)
                                {
                                  $start=$order_page-1;
                                  $end=$order_page;
                                }
                                elseif(2 == $order_page && $order_page <= $total_pages-1)
                                {
                                  $start=$order_page-1;
                                  $end=$order_page+1;
                                }
                                elseif(1 == $order_page && $order_page <= $total_pages-2)
                                {
                                  $start=$order_page;
                                  $end=$order_page+2;
                                }
                                elseif(1 == $order_page && $order_page == $total_pages-1)
                                {
                                  $start=$order_page;
                                  $end=$order_page+1;
                                }
                                elseif(1 == $order_page && $order_page == $total_pages)
                                {
                                  $start=$order_page;
                                  $end=$order_page;
                                }
                                elseif(2 == $order_page && $order_page == $total_pages)
                                {
                                  $start=$order_page-1;
                                  $end=$order_page+1;
                                }
                                elseif(2 == $order_page && $order_page == $total_pages-1)
                                {
                                  $start=$order_page;
                                  $end=$order_page+1;
                                }
                                elseif(3<= $order_page && $total_pages==$order_page+1)
                                {
                                  $start=$order_page-2;
                                  $end=$order_page+1;
                                }
                                elseif(3<= $order_page && $total_pages==$order_page)
                                {
                                  $start=$order_page-2;
                                  $end=$order_page;
                                }
                              }
                              else
                              {
                                $start=1;
                                if($total_pages==$start)
                                {
                                  $end=$start;  
                                }
                                elseif($total_pages==$start+1)
                                {
                                  $end=$start+1;
                                }
                                elseif($total_pages>=$start+2)
                                {
                                  $end=$start+2;
                                }
                              }
                              echo "<a href='payment.php?bill_page=1'>".'<< first'."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
                              $j=1;  
                              for ($i=$start; $i<=$end; $i++) 
                              {   
                                if($i==$_GET['bill_page'] || ($j==1 && !isset($_GET['bill_page'])))
                                {
                                  echo "&nbsp;&nbsp;<a style='color:red;' href='payment.php?bill_page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                                }
                                else
                                {
                                  echo "&nbsp;&nbsp;<a href='payment.php?bill_page=".$i."'> ".$i."</a> &nbsp;&nbsp;";     
                                }
                                $j++;
                              }
                            
                              echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='payment.php?bill_page=$total_pages'>".'last >>'."</a> ";  ?>
                          </div>
                        </div>
                    </div>
                  </div>
		        </div>
        <!-- Payment informatin end-->      
              
              
          </div>
        </div>


<!-- payment information start -->
      

<!-- payment information end -->



        <!-- /page content -->

        <!-- footer content -->
        <?php include_once("footer.php"); ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!-- Check confirmation form admin -->
    <script type="text/javascript">
      function chk()
      {
        var a=confirm("Are you want to sure delete this Payment type.....?");
        if(a==true)
          return true;
        else
          return false;
      }
    </script>

  </body>
</html>