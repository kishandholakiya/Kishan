<?php
session_start();
//open connetion file
include_once("connection.php");
$con = new connection();
$con->connect();

// Select admin Information
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);


//session check
if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}


//delete feedback information from tbl_feedback
if(isset($_GET['del_feedback']))
{
  $tmp="delete";
  $id=$_GET['del_feedback'];
  $con->iuds_tbl_feedback($tmp,$id);
  header("Location:full_page.php");
}



?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <?php 
  if("full_page.php")
    {
      ?>
        <meta http-equiv="refresh" content="10">
    <?php } ?>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Food Maina </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
<div class="main_container">
        <div class="col-md-3 left_col">

          <?php include_once("side_bar.php"); ?>
        </div>

        <!-- top navigation -->
		<?php include_once("top_nav.php"); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row tile_count">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count"> <?php
              $tmp="count_panding_order";
              $res=$con->count($tmp); ?>
              <span class="count_top"><i class="fa fa-user"></i>Total Panding Order</span>
              <div class="count"><?php echo $res[0]; ?></div>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count"> <?php
              $tmp="count_todays_total_order";
              $res=$con->count($tmp); ?>
              <span class="count_top"><i class="fa fa-user"></i> Today's Total Order</span>
              <div class="count"><?php echo $res[0]; ?></div>
            </div>
            
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count"> <?php 
              $tmp="count_main_dishes";
              $res=$con->count($tmp); ?>
              <span class="count_top"><i class="fa fa-user"></i> Total Main Dishes</span>
              <div class="count"><?php echo $res[0]; ?></div>
            </div>
            
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count"><?php 
              $tmp="count_sub_dishes";
              $res=$con->count($tmp); ?>
              <span class="count_top"><i class="fa fa-user"></i> Total Sub Dishes</span>
              <div class="count"><?php echo $res[0]; ?></div>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count"><?php 
              $tmp="count_feture_event";
              $res=$con->count($tmp); ?>
              <span class="count_top"><i class="fa fa-user"></i> Total Events</span>
              <div class="count"><?php echo $res[0]; ?></div>
            </div>

            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count"> <?php 
              $tmp="count_customer";
              $res=$con->count($tmp); ?>
              <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
              <div class="count"><?php echo $res[0]; ?></div>
            </div>
            
          </div>
          <!-- /top tiles -->
	
    <div class="">
            	<div class="row">
               		<div class="col-md-12 col-sm-12 col-xs-12">
                		<div align="center" class="x_panel" style="font-size:40px; margin-top:10px;">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                            	<h1 align="center">Order Information</h1>
                            </div>
                  		</div>       
                	</div>
            	</div>
            <div class="clearfix"></div>
        
        <!--Show Information of customer  -->
      <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2>Order of Dishes</h2>	
                <ul class="nav navbar-right panel_toolbox">
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                  </li>
                  
                </ul>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
    		        <table class="table table-bordered" style="font-size:16px;text-align:center;">
                      <thead>
                        <tr class="dark" style="background:#FFC;">
                          <th style="text-align:center;">Entry Date</th>
                          <th style="text-align:center;">Customer Name</th>
                          <th style="text-align:center;">Delivery Address</th>
                          <th style="text-align:center;">Payment Type</th>
                          <th style="text-align:center;">Status</th>
                          <th style="text-align:center;">Full Details</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                      // Select all dishes from tbl_main_dishes
                      $tmp="select";
                      $res=$con->iuds_order($tmp,$id,$status);
                      if($num=mysql_num_rows($res)>0)
                      {
                        while($ans=mysql_fetch_array($res))
                        {
                        extract($ans);
                        echo "<tr>";
                            ?><td style='text-transform:capitalize;'><?php echo $order_entry_date; ?></td>
                            
                            <td style='text-transform:capitalize;'><?php
                              //select all customer name  
                              $id=$register_id;
                              $res2=$con->iuds_tbl_redister($tmp,$id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);  
                              echo  $res2['register_fname']."&nbsp;".$res2['register_lname']; ?>
                            </td>

                            <td style='text-transform:capitalize;'><?php echo $order_delivery_address; ?></td>

                            <td style='text-transform:capitalize;'>
                              <?php 
                              //select payment name form payment id
                              $tmp="select";
                              $id=$payment_id;
                              $res3=$con->iuds_tbl_payment($tmp,$id,$payment_type,$status);
                              echo $res3['payment_type']; ?>
                            </td>

                            <td style='text-transform:capitalize;'><?php 
                            if($order_is_status=="0") 
                            { ?>
                              <img src="../../img/icon_img/red.png" style="height:25px;width:25px;"> <?php
                            }
                            elseif( $order_is_status == "1")
                            { ?>
                               <img src="../../img/icon_img/pink.png" style="height:25px;width:25px;"> <?php
                            }
                            elseif($order_is_status=="2")
                            { ?>
                              <img src="../../img/icon_img/green.png" style="height:25px;width:25px;">
                               <?php
                            }  ?></td>

                            <td><a href="order_full_details.php?order_id=<?php echo $order_id; ?>" style="font-size:25px;"><i class="glyphicon glyphicon-info-sign"></i></a></td><?php          
                          echo "</tr>";
                        }
                      }
                      else
                      {
                        echo "<tr>";?>
                          <td colspan="15" style="color:#C6F;">No Orders are Available</td>
          <?php             echo "</tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                  <div align="center"><?php
                    $num_rec_per_page=10;
                    //count total record of slider
                    $q="SELECT COUNT(order_id) FROM tbl_order WHERE order_is_status!='3'   ORDER BY (order_entry_date) DESC ";
                    $r=mysql_query($q);
                    $a=mysql_fetch_array($r);
                    $total_records=$a[0];

                    if($num_rec_per_page>$total_records)
                    {
                      $total_pages=1;  
                    }
                    else
                    {
                      $total_pages = ceil($total_records / $num_rec_per_page); 
                    }


                    if(isset($_GET['order_page']) && !empty($_GET['order_page']))
                    {
                      $order_page=$_GET['order_page'];
                      if(3 <= $order_page && $order_page <= $total_pages-2)
                      {
                        $start=$order_page-2;
                        $end=$order_page+2;
                      }
                      elseif(2 == $order_page && $order_page <= $total_pages-2)
                      {
                        $start=$order_page-1;
                        $end=$order_page+2;
                      }
                      elseif(2 == $order_page && $order_page== $total_pages)
                      {
                        $start=$order_page-1;
                        $end=$order_page;
                      }
                      elseif(2 == $order_page && $order_page <= $total_pages-1)
                      {
                        $start=$order_page-1;
                        $end=$order_page+1;
                      }   
                      elseif(1 == $order_page && $order_page <= $total_pages-2)
                      {
                        $start=$order_page;
                        $end=$order_page+2;
                      }
                      elseif(1 == $order_page && $order_page == $total_pages-1)
                      {
                        $start=$order_page;
                        $end=$order_page+1;
                      }
                      elseif(1 == $order_page && $order_page == $total_pages)
                      {
                        $start=$order_page;
                        $end=$order_page;
                      }
                      elseif(2 == $order_page && $order_page == $total_pages)
                      {
                        $start=$order_page-1;
                        $end=$order_page+1;
                      }
                      elseif(2 == $order_page && $order_page == $total_pages-1)
                      {
                        $start=$order_page;
                        $end=$order_page+1;
                      }
                      elseif(3<= $order_page && $total_pages==$order_page+1)
                      {
                        $start=$order_page-2;
                        $end=$order_page+1;
                      }
                      elseif(3<= $order_page && $total_pages==$order_page)
                      {
                        $start=$order_page-2;
                        $end=$order_page;
                      }
                    }
                    else
                    {
                      $start=1;
                      if($total_pages==$start)
                      {
                        $end=$start;  
                      }
                      elseif($total_pages==$start+1)
                      {
                        $end=$start+1;
                      }
                      elseif($total_pages>=$start+2)
                      {
                        $end=$start+2;
                      }
                    }
					
					//get feedback_page number
                    if(isset($_GET['order_page']) && !empty($_GET['order_page']))
                      $order_page=$_GET['order_page'];
                    else
                      $order_page=1;
						

                    //get feedback_page number
                    if(isset($_GET['feedback_page']) && !empty($_GET['feedback_page']))
                      $feedback_page=$_GET['feedback_page'];
                    else
                      $feedback_page=1; ?>

                    <a href='full_page.php?order_page=1&feedback_page=<?php echo $feedback_page; ?>'><< first </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                    <?php 
                    for ($i=$start; $i<=$end; $i++) 
                    { 
                      if($i==$order_page || (!isset($_GET['order_page']) && $i==1) )
                      { ?>
                        &nbsp;&nbsp;<a style='color:red;' href="full_page.php?order_page=<?php echo $i; ?>&feedback_page=<?php echo $feedback_page; ?>"> <?php echo $i; ?></a> &nbsp;&nbsp; <?php 
                      }
                      else
                      { ?>
                        &nbsp;&nbsp;<a href="full_page.php?order_page=<?php echo $i; ?>&feedback_page=<?php echo $feedback_page; ?>"> <?php echo $i; ?></a> &nbsp;&nbsp; <?php  
                      }
                      $j++;
                    } ?>
                  
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='full_page.php?order_page=<?php echo  $total_pages; ?>&feedback_page=<?php echo $feedback_page; ?>'> last >></a>
                  </div>
              </div>
            </div>
          </div>
</div>
    
    
    <!--Show Order Information of one customer-->
    <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2>FeedBack Information</h2>	
                <ul class="nav navbar-right panel_toolbox">
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"></a></li>
                  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                  </li>
                  
                </ul>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
    	           <table class="table table-bordered" style="font-size:16px;text-align:center;">
                      <thead>
                        <tr class="dark" style="background:#FFC;">
                          <th style="text-align:center;">Customer Name</th>
                          <th style="text-align:center;">Entry Date</th>
                          <th style="text-align:center;">FeedBack</th>
                          <th style="text-align:center;">Delete</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                      // Select all dishes from tbl_main_dishes
                      $tmp="select";
                      $res=$con->iuds_tbl_feedback($tmp,$feefback_id);
                      if($num=mysql_num_rows($res)>=1)
                      {
                        while($ans=mysql_fetch_array($res))
                        {
                        extract($ans);
                        echo "<tr>";
                            //select all customer name  
                            $tmp="select";
                            $id=$registration_id;
                            $fname=$lname=$address=$gender=$bod=$contect=$email=$pass=$status=$ip_address="";
                            $res2=$con->iuds_tbl_redister($tmp,$id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);  ?>
                           
                            <td style='text-transform:capitalize;'><?php 
                            
                            echo  $res2['register_fname']."&nbsp;".$res2['register_lname']; ?></td>

                            <td style='text-transform:capitalize;'><?php echo $feedback_entry_date; ?></td>

                            <td style='text-transform:capitalize;'><?php echo $feedback_info; ?></td>

                            <td><a onclick="return chkfeedback();" href="full_page.php?del_feedback=<?php echo $feedback_id; ?>" style="font-size:20px;"><i class="glyphicon glyphicon-trash"></i></a></td>
                   <?php          echo "</tr>";
                        }
                      }
                      else
                      {
                        echo "<tr>";?>
                          <td colspan="15" style="color:#C6F;">No FeedBacks are Available</td>
          <?php             echo "</tr>";
                      }
                      ?>
                       </tbody>
                    </table>
                    <div align="center"> <?php
                      $num_rec_per_page=10;
                      //count total record of slider
                      $q="SELECT COUNT(feedback_id) FROM tbl_feedback ORDER BY (feedback_entry_date)DESC";
                      $r=mysql_query($q);
                      $a=mysql_fetch_array($r);
                      $total_records=$a[0];

                      if($num_rec_per_page>$total_records)
                      {
                        $total_pages=1;  
                      }
                      else
                      {
                        $total_pages = ceil($total_records / $num_rec_per_page); 
                      }
                      
                      if(isset($_GET['feedback_page']) && !empty($_GET['feedback_page']))
                      {
                        $feedback_page=$_GET['feedback_page'];
                        if(3 <= $feedback_page && $feedback_page <= $total_pages-2)
                        {
                          $start2=$feedback_page-2;
                          $end2=$feedback_page+2;
                        }
                        elseif(2 == $feedback_page && $feedback_page <= $total_pages-2)
                        {
                          $start2=$feedback_page-1;
                          $end2=$feedback_page+2;
                        }
                        elseif(2 == $feedback_page && $feedback_page== $total_pages)
                        {
                          $start2=$feedback_page-1;
                          $end2=$feedback_page;
                        }
                        elseif(2 == $feedback_page && $feedback_page <= $total_pages-1)
                        {
                          $start2=$feedback_page-1;
                          $end2=$feedback_page+1;
                        } 
                        elseif(1 == $feedback_page && $feedback_page <= $total_pages-2)
                        {
                          $start2=$feedback_page;
                          $end2=$feedback_page+2;
                        }
                        elseif(1 == $feedback_page && $feedback_page == $total_pages-1)
                        {
                          $start2=$feedback_page;
                          $end2=$feedback_page+1;
                        }
                        elseif(1 == $feedback_page && $feedback_page == $total_pages)
                        {
                          $start2=$feedback_page;
                          $end2=$feedback_page;
                        }
                        elseif(2 == $feedback_page && $feedback_page == $total_pages)
                        {
                          $start2=$feedback_page-1;
                          $end2=$feedback_page+1;
                        }
                        elseif(2 == $feedback_page && $feedback_page == $total_pages-1)
                        {
                          $start2=$feedback_page;
                          $end2=$feedback_page+1;
                        }
                        elseif(3<= $feedback_page && $total_pages==$feedback_page+1)
                        {
                          $start2=$feedback_page-2;
                          $end2=$feedback_page+1;
                        }
                        elseif(3<= $feedback_page && $total_pages==$feedback_page)
                        {
                          $start2=$feedback_page-2;
                          $end2=$feedback_page;
                        }
                      }
                      else
                      {
                        $start2=1;
                        if($total_pages==$start2)
                        {
                          $end2=$start2;  
                        }
                        elseif($total_pages==$start2+1)
                        {
                          $end2=$start2+1;
                        }
                        elseif($total_pages>=$start2+2)
                        {
                          $end2=$start2+2;
                        }
                      } ?>

                      

                      
                      <a href='full_page.php?order_page=<?php echo $order_page; ?>&feedback_page=1'><< first </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                      
                      <?php 
                      $j=1;  
                      for ($i=$start2; $i<=$end2; $i++) 
                      { 
                        if($feedback_page==$i) 
                        { ?>
                          &nbsp;&nbsp;<a style='color:red;' href='full_page.php?order_page=<?php echo $order_page;?>&feedback_page=<?php echo $i; ?>'> <?php echo $i; ?></a> &nbsp;&nbsp; <?php  
                        }
                        else
                        { ?>
                          &nbsp;&nbsp;<a href='full_page.php?order_page=<?php echo $order_page;?>&feedback_page=<?php echo $i; ?>'> <?php echo $i; ?></a> &nbsp;&nbsp; <?php  
                        }
                        $j++;
                      }?>
                      
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='full_page.php?order_page=<?php echo $order_page; ?>&feedback_page=<?php echo $total_pages; ?>'>last >></a> 
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once("footer.php"); ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!-- bootstrap-daterangepicker -->
    <script>
      $(document).ready(function() {
        $('#birthday').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_4"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
      });
    </script>
    <!-- /bootstrap-daterangepicker -->

    <!-- bootstrap-wysiwyg -->
    <script>
      $(document).ready(function() {
        function initToolbarBootstrapBindings() {
          var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
              'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
              'Times New Roman', 'Verdana'
            ],
            fontTarget = $('[title=Font]').siblings('.dropdown-menu');
          $.each(fonts, function(idx, fontName) {
            fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
          });
          $('a[title]').tooltip({
            container: 'body'
          });
          $('.dropdown-menu input').click(function() {
              return false;
            })
            .change(function() {
              $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
            })
            .keydown('esc', function() {
              this.value = '';
              $(this).change();
            });

          $('[data-role=magic-overlay]').each(function() {
            var overlay = $(this),
              target = $(overlay.data('target'));
            overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
          });

          if ("onwebkitspeechchange" in document.createElement("input")) {
            var editorOffset = $('#editor').offset();

            $('.voiceBtn').css('position', 'absolute').offset({
              top: editorOffset.top,
              left: editorOffset.left + $('#editor').innerWidth() - 35
            });
          } else {
            $('.voiceBtn').hide();
          }
        }

        function showErrorAlert(reason, detail) {
          var msg = '';
          if (reason === 'unsupported-file-type') {
            msg = "Unsupported format " + detail;
          } else {
            console.log("error uploading file", reason, detail);
          }
          $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
            '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
        }

        initToolbarBootstrapBindings();

        $('#editor').wysiwyg({
          fileUploadError: showErrorAlert
        });

        window.prettyPrint;
        prettyPrint();
      });
    </script>
    <!-- /bootstrap-wysiwyg -->

    <!-- Select2 -->
    <script>
      $(document).ready(function() {
        $(".select2_single").select2({
          placeholder: "Select a state",
          allowClear: true
        });
        $(".select2_group").select2({});
        $(".select2_multiple").select2({
          maximumSelectionLength: 4,
          placeholder: "With Max Selection limit 4",
          allowClear: true
        });
      });
    </script>
    <!-- /Select2 -->

    <!-- jQuery Tags Input -->
    <script>
      function onAddTag(tag) {
        alert("Added a tag: " + tag);
      }

      function onRemoveTag(tag) {
        alert("Removed a tag: " + tag);
      }

      function onChangeTag(input, tag) {
        alert("Changed a tag: " + tag);
      }

      $(document).ready(function() {
        $('#tags_1').tagsInput({
          width: 'auto'
        });
      });
    </script>
    <!-- /jQuery Tags Input -->

    <!-- Parsley -->
    <script>
      $(document).ready(function() {
        $.listen('parsley:field:validate', function() {
          validateFront();
        });
        $('#demo-form .btn').on('click', function() {
          $('#demo-form').parsley().validate();
          validateFront();
        });
        var validateFront = function() {
          if (true === $('#demo-form').parsley().isValid()) {
            $('.bs-callout-info').removeClass('hidden');
            $('.bs-callout-warning').addClass('hidden');
          } else {
            $('.bs-callout-info').addClass('hidden');
            $('.bs-callout-warning').removeClass('hidden');
          }
        };
      });

      $(document).ready(function() {
        $.listen('parsley:field:validate', function() {
          validateFront();
        });
        $('#demo-form2 .btn').on('click', function() {
          $('#demo-form2').parsley().validate();
          validateFront();
        });
        var validateFront = function() {
          if (true === $('#demo-form2').parsley().isValid()) {
            $('.bs-callout-info').removeClass('hidden');
            $('.bs-callout-warning').addClass('hidden');
          } else {
            $('.bs-callout-info').addClass('hidden');
            $('.bs-callout-warning').removeClass('hidden');
          }
        };
      });
      try {
        hljs.initHighlightingOnLoad();
      } catch (err) {}
    </script>
    <!-- /Parsley -->

    <!-- Autosize -->
    <script>
      $(document).ready(function() {
        autosize($('.resizable_textarea'));
      });
    </script>
    <!-- /Autosize -->

    <!-- jQuery autocomplete -->
    <script>
      $(document).ready(function() {
        var countries = { AD:"Andorra",A2:"Andorra Test",AE:"United Arab Emirates",AF:"Afghanistan",AG:"Antigua and Barbuda",AI:"Anguilla",AL:"Albania",AM:"Armenia",AN:"Netherlands Antilles",AO:"Angola",AQ:"Antarctica",AR:"Argentina",AS:"American Samoa",AT:"Austria",AU:"Australia",AW:"Aruba",AX:"Åland Islands",AZ:"Azerbaijan",BA:"Bosnia and Herzegovina",BB:"Barbados",BD:"Bangladesh",BE:"Belgium",BF:"Burkina Faso",BG:"Bulgaria",BH:"Bahrain",BI:"Burundi",BJ:"Benin",BL:"Saint Barthélemy",BM:"Bermuda",BN:"Brunei",BO:"Bolivia",BQ:"British Antarctic Territory",BR:"Brazil",BS:"Bahamas",BT:"Bhutan",BV:"Bouvet Island",BW:"Botswana",BY:"Belarus",BZ:"Belize",CA:"Canada",CC:"Cocos [Keeling] Islands",CD:"Congo - Kinshasa",CF:"Central African Republic",CG:"Congo - Brazzaville",CH:"Switzerland",CI:"Côte d’Ivoire",CK:"Cook Islands",CL:"Chile",CM:"Cameroon",CN:"China",CO:"Colombia",CR:"Costa Rica",CS:"Serbia and Montenegro",CT:"Canton and Enderbury Islands",CU:"Cuba",CV:"Cape Verde",CX:"Christmas Island",CY:"Cyprus",CZ:"Czech Republic",DD:"East Germany",DE:"Germany",DJ:"Djibouti",DK:"Denmark",DM:"Dominica",DO:"Dominican Republic",DZ:"Algeria",EC:"Ecuador",EE:"Estonia",EG:"Egypt",EH:"Western Sahara",ER:"Eritrea",ES:"Spain",ET:"Ethiopia",FI:"Finland",FJ:"Fiji",FK:"Falkland Islands",FM:"Micronesia",FO:"Faroe Islands",FQ:"French Southern and Antarctic Territories",FR:"France",FX:"Metropolitan France",GA:"Gabon",GB:"United Kingdom",GD:"Grenada",GE:"Georgia",GF:"French Guiana",GG:"Guernsey",GH:"Ghana",GI:"Gibraltar",GL:"Greenland",GM:"Gambia",GN:"Guinea",GP:"Guadeloupe",GQ:"Equatorial Guinea",GR:"Greece",GS:"South Georgia and the South Sandwich Islands",GT:"Guatemala",GU:"Guam",GW:"Guinea-Bissau",GY:"Guyana",HK:"Hong Kong SAR China",HM:"Heard Island and McDonald Islands",HN:"Honduras",HR:"Croatia",HT:"Haiti",HU:"Hungary",ID:"Indonesia",IE:"Ireland",IL:"Israel",IM:"Isle of Man",IN:"India",IO:"British Indian Ocean Territory",IQ:"Iraq",IR:"Iran",IS:"Iceland",IT:"Italy",JE:"Jersey",JM:"Jamaica",JO:"Jordan",JP:"Japan",JT:"Johnston Island",KE:"Kenya",KG:"Kyrgyzstan",KH:"Cambodia",KI:"Kiribati",KM:"Comoros",KN:"Saint Kitts and Nevis",KP:"North Korea",KR:"South Korea",KW:"Kuwait",KY:"Cayman Islands",KZ:"Kazakhstan",LA:"Laos",LB:"Lebanon",LC:"Saint Lucia",LI:"Liechtenstein",LK:"Sri Lanka",LR:"Liberia",LS:"Lesotho",LT:"Lithuania",LU:"Luxembourg",LV:"Latvia",LY:"Libya",MA:"Morocco",MC:"Monaco",MD:"Moldova",ME:"Montenegro",MF:"Saint Martin",MG:"Madagascar",MH:"Marshall Islands",MI:"Midway Islands",MK:"Macedonia",ML:"Mali",MM:"Myanmar [Burma]",MN:"Mongolia",MO:"Macau SAR China",MP:"Northern Mariana Islands",MQ:"Martinique",MR:"Mauritania",MS:"Montserrat",MT:"Malta",MU:"Mauritius",MV:"Maldives",MW:"Malawi",MX:"Mexico",MY:"Malaysia",MZ:"Mozambique",NA:"Namibia",NC:"New Caledonia",NE:"Niger",NF:"Norfolk Island",NG:"Nigeria",NI:"Nicaragua",NL:"Netherlands",NO:"Norway",NP:"Nepal",NQ:"Dronning Maud Land",NR:"Nauru",NT:"Neutral Zone",NU:"Niue",NZ:"New Zealand",OM:"Oman",PA:"Panama",PC:"Pacific Islands Trust Territory",PE:"Peru",PF:"French Polynesia",PG:"Papua New Guinea",PH:"Philippines",PK:"Pakistan",PL:"Poland",PM:"Saint Pierre and Miquelon",PN:"Pitcairn Islands",PR:"Puerto Rico",PS:"Palestinian Territories",PT:"Portugal",PU:"U.S. Miscellaneous Pacific Islands",PW:"Palau",PY:"Paraguay",PZ:"Panama Canal Zone",QA:"Qatar",RE:"Réunion",RO:"Romania",RS:"Serbia",RU:"Russia",RW:"Rwanda",SA:"Saudi Arabia",SB:"Solomon Islands",SC:"Seychelles",SD:"Sudan",SE:"Sweden",SG:"Singapore",SH:"Saint Helena",SI:"Slovenia",SJ:"Svalbard and Jan Mayen",SK:"Slovakia",SL:"Sierra Leone",SM:"San Marino",SN:"Senegal",SO:"Somalia",SR:"Suriname",ST:"São Tomé and Príncipe",SU:"Union of Soviet Socialist Republics",SV:"El Salvador",SY:"Syria",SZ:"Swaziland",TC:"Turks and Caicos Islands",TD:"Chad",TF:"French Southern Territories",TG:"Togo",TH:"Thailand",TJ:"Tajikistan",TK:"Tokelau",TL:"Timor-Leste",TM:"Turkmenistan",TN:"Tunisia",TO:"Tonga",TR:"Turkey",TT:"Trinidad and Tobago",TV:"Tuvalu",TW:"Taiwan",TZ:"Tanzania",UA:"Ukraine",UG:"Uganda",UM:"U.S. Minor Outlying Islands",US:"United States",UY:"Uruguay",UZ:"Uzbekistan",VA:"Vatican City",VC:"Saint Vincent and the Grenadines",VD:"North Vietnam",VE:"Venezuela",VG:"British Virgin Islands",VI:"U.S. Virgin Islands",VN:"Vietnam",VU:"Vanuatu",WF:"Wallis and Futuna",WK:"Wake Island",WS:"Samoa",YD:"People's Democratic Republic of Yemen",YE:"Yemen",YT:"Mayotte",ZA:"South Africa",ZM:"Zambia",ZW:"Zimbabwe",ZZ:"Unknown or Invalid Region" };

        var countriesArray = $.map(countries, function(value, key) {
          return {
            value: value,
            data: key
          };
        });

        // initialize autocomplete with custom appendTo
        $('#autocomplete-custom-append').autocomplete({
          lookup: countriesArray
        });
      });
    </script>
    <!-- /jQuery autocomplete -->

    <!-- Starrr -->
    <script>
      $(document).ready(function() {
        $(".stars").starrr();

        $('.stars-existing').starrr({
          rating: 4
        });

        $('.stars').on('starrr:change', function (e, value) {
          $('.stars-count').php(value);
        });

        $('.stars-existing').on('starrr:change', function (e, value) {
          $('.stars-count-existing').php(value);
        });
      });
    </script>
    <!-- /Starrr -->

    <!-- Feedback function start-->
    <script type="text/javascript">
      function chkfeedback()
      {
        var a=confirm("Are you want to Sure to delete FeedBack.....?");
        if(a==true)
          return true;
        else
          return false;
      }
    </script>
    <!-- feedback function over -->



  </body>
</html>
