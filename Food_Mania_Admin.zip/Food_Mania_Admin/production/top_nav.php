

<div class="top_nav" id="top_nav">
      <div class="nav_menu" id="nav_menu">
        <nav>
          <div class="nav toggle">
            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
          </div>

          <ul class="nav navbar-nav navbar-right">
            <li class="">
              <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                <img src="../../img/admin_profile_img/<?php echo $admin_profile; ?>" alt=""><?php echo $admin_name; ?>
                <span class=" fa fa-angle-down"></span>
              </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="admin_profile.php"> Profile</a></li>
                <li><a onclick="return logout_confirm();" href="index.php?m=1"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
              
            </li>
            <li  id="drapdown1"  role="presentation"  class="dropdown">
              <a href="javascript:;" class="dropdown-toggle info-number" id="order_information" onclick="fetch_order_from_customer();" data-toggle="dropdown" aria-expanded="false">
                
                <img src="../../img/icon_img/notification.png" />
                <span id="notification" class="badge bg-green"></span>
              </a>
              
              <ul id="menu1" class="dropdown-menu list-unstyled msg_list auto_update" role="menu">
                <li id="show_order_info">
                </li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
</div>

<script type="text/javascript">
function logout_confirm()
{
  var a=confirm("Are you want to Logout.....?");
  if(a==true)
    return true;
  else
    return false;
}
</script>


<script src="jquery-3.1.1.min.js"></script>
<script>
$(document).ready(function(){
  //show notification number;
  $("#notification").load('notification.php');
  refresh();



  //show full notification
  $("#order_information").fadeIn('fast').click('notification2.php');
  fetch_order_from_customer();
});



function refresh()
{
  setTimeout(function(){
    $("#notification").fadeIn('fast').load('notification.php');
    refresh();
  },200);
}

function fetch_order_from_customer()
{
  setTimeout(function(){
    $("#show_order_info").fadeIn('fast').load('notification2.php')
    fetch_order_from_customer();
  },1000);
}



</script>
