<footer>
	<div align="center">
		Devloped By:- Kishan Dholakiya and team</div>
	<div class="clearfix"></div>
</footer>