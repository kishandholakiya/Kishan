<?php
session_start();
//open connetion file
include_once("connection.php");
$con = new connection();
$con->connect();

//select all information about admin
$res=$con->select_admin();
$ans=mysql_fetch_array($res);
extract($ans);

if(!isset($_SESSION['name']))
{
	header("Location:index.php");
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Food Mania</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <?php include_once("side_bar.php"); ?>
        </div>

        <!-- top navigation -->
        <?php include_once("top_nav.php"); ?>
        <!-- /top navigation -->

        <!-- page content -->
        
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left"></div>
	
              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h1 align="center">Customer Information</h1>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
					<div class="clearfix"></div><br>
                    <table class="table table-bordered" style="font-size:16px;text-align:center;">
                      <thead>
                        <tr class="dark" style="background:#FFC;">
                          <th style="text-align:center;">Customer Name</th>
                          <th style="text-align:center;">Address</th>
                          <th style="text-align:center;">Contect No.</th>
                          <th style="text-align:center;">Email id</th>
                          <th style="text-align:center;">Status</th>
                          <th style="text-align:center;">More Detail</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
					  // Insert, Update, Delete, Select In table tbl_register
					  $tmp="select";
            		  $res=$con->iuds_tbl_redister($tmp,$id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);
					  if($num=mysql_num_rows($res)>0)
					  {
						  while($ans=mysql_fetch_array($res))
						  {
							extract($ans);
							echo "<tr>";  
							  	echo "<td style='text-transform:capitalize;'>$register_fname &nbsp; $register_lname</td>"; 
								echo "<td style='text-transform:capitalize;'>$register_address</td>";
								echo "<td style='text-transform:capitalize;'>$register_contect_no</td>"; 
								echo "<td style='text-transform:capitalize;'>$register_email_id</td>";?>
							  <td align="center" class="a-center ">
								  <?php 
								  if($register_is_status==1) 
								  {?>
								  	<img src="../../img/icon_img/cy.png" height="25" width="25"> <?php
						  	      }
								  else
								  { ?>
                                  	<img src="../../img/icon_img/cn.png" height="25" width="25"> <?php							  }
								   ?>  
                                  </td>
							  <td><a href="customer_more_details.php?register_id=<?php echo $register_id; ?>" style="font-size:25px;"><i class="glyphicon glyphicon-info-sign"></i></a></td>
                              
			   <?php          echo "</tr>";
							$tempary_id++;
						  }
					  }
					  else
					  {
						  echo "<tr>";?>
						  	<td colspan="15" style="color:#C6F;">No Main Dishes are Available</td>
<?php						  echo "</tr>";
					  }
					  ?>
                       </tbody>
                    </table>
                    <div align="center"> <?php
                      $num_rec_per_page=10;
                      //count total record of slider
                      $q="SELECT COUNT(register_id) FROM tbl_register ORDER BY(register_fname)";
                      $r=mysql_query($q);
                      $a=mysql_fetch_array($r);
                      $total_records=$a[0];

                      if($num_rec_per_page>$total_records)
                      {
                        $total_pages=1;  
                      }
                      else
                      {
                        $total_pages = ceil($total_records / $num_rec_per_page); 
                      }

                      if(isset($_GET['page']))
                      {
                        $page=$_GET['page'];
                       if(3 <= $page && $page <= $total_pages-2)
                        {
                          $start=$page-2;
                          $end=$page+2;
                        }
                        elseif(2 == $page && $page <= $total_pages-2)
                        {
                          $start=$page-1;
                          $end=$page+2;
                        }
                        elseif(2 == $page && $page== $total_pages)
                        {
                          $start=$page-1;
                          $end=$page;
                        }
                        elseif(2 == $page && $page <= $total_pages-1)
                        {
                          $start=$page-1;
                          $end=$page+1;
                        }             
                        elseif(1 == $page && $page <= $total_pages-2)
                        {
                          $start=$page;
                          $end=$page+2;
                        }
                        elseif(1 == $page && $page == $total_pages-1)
                        {
                          $start=$page;
                          $end=$page+1;
                        }
                        elseif(1 == $page && $page == $total_pages)
                        {
                          $start=$page;
                          $end=$page;
                        }
                        elseif(2 == $page && $page == $total_pages)
                        {
                          $start=$page-1;
                          $end=$page+1;
                        }
                        elseif(2 == $page && $page == $total_pages-1)
                        {
                          $start=$page;
                          $end=$page+1;
                        }
                        elseif(3<= $page && $total_pages==$page+1)
                        {
                          $start=$page-2;
                          $end=$page+1;
                        }
                        elseif(3<= $page && $total_pages==$page)
                        {
                          $start=$page-2;
                          $end=$page;
                        }
                      }
                      else
                      {
                        $start=1;
                        if($total_pages==$start)
                        {
                          $end=$start;  
                        }
                        elseif($total_pages==$start+1)
                        {
                          $end=$start+1;
                        }
                        elseif($total_pages>=$start+2)
                        {
                          $end=$start+2;
                        }
                      }


                      echo "<a href='customer_details.php?page=1'>".'<< first'."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
                      $j=1;  
                      for ($i=$start; $i<=$end; $i++) 
                      { 
                        if($i==$_GET['page'] || ($j==1 && !isset($_GET['page'])))
                        {
                          echo "&nbsp;&nbsp;<a style='color:red;' href='customer_details.php?page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                        }
                        else
                        {
                          echo "&nbsp;&nbsp;<a href='customer_details.php?page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                        }
                        $j++;
                      }
                      
                      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='customer_details.php?page=$total_pages'>".'last >>'."</a> ";?>
                    </div>
                  </div>
                </div>
              </div>

              <div class="clearfix"></div>

              </div>
          </div>
        </div>
      
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once("footer.php"); ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.php5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
    
    <!--Confirm Message-->
	<script type="text/javascript">
	function chk()
	{
		var a=confirm("Are you want to sure Change this Customer's Status.....?");
		if(a==true)
			return true;
		else
			return false;
	}
	
	</script>
  </body>
</html>