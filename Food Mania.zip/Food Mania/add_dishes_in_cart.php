<?php 
session_start();
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();





if(isset($_POST['id']))
{
    if(!isset($_SESSION['customer']))
    {
        echo "no_login";
    }
    else
    {
        $tmp="insert_sub_dishes";
        $register_id=$_SESSION['customer'];
        $sub_dishes_id=$_POST['id'];
        $res=$con->iuds_tbl_cart($tmp,$cart_id,$register_id,$sub_dishes_id,$payment_id,$taste_id,$order_quantity,$order_total_price);
		if($res=="dish_add_in_cart")
			echo "dish_add_in_cart";
		elseif($res=="cart_is_full")
			echo "cart_is_full";
		elseif($res=="dish_is_already_added")
			echo "dish_is_already_added";
    }
} ?>