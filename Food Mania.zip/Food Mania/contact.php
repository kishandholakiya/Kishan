<?php
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();
?>

<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:44:19 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>-
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Food Mania</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->
        
        <!--All Google Fonts-->
        <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

		<!-- all css here -->
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="css/owl.carousel.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- datepicker css -->
        <link rel="stylesheet" href="css/bootstrap-datepicker.css">
		<!-- timepicker css -->
        <link rel="stylesheet" href="css/jquery.timepicker.css">
        <!-- nivo-slider css -->
        <link rel="stylesheet" href="lib/css/nivo-slider.css">
        <!-- venobox css -->
        <link rel="stylesheet" href="lib/venobox/venobox.css">
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
		<!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
    
	<!-- contact.php Header Start -->
       <?php include_once("header.php"); ?>
	<!-- contact.php Header End -->
	
	<!-- Page Name Start -->
	<div class="page_name" style="">
		<h1><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;Contact</h1>
	</div>   
    
    <!-- Page Name End -->
    
       <!--contact.php Page Content Start-->
                        <?php 
                               // Select admin Information
                                $tmp="select_tbl_admin";
                               $res=$con->select_all_data($tmp,$main_dishes_name);
                               $ans=mysql_fetch_array($res);
                               extract($ans);     
                         ?>
                    <div align="center">
                                  <table align="center">
                                          <tr align="center"><h1 style="font-family:'Times New Roman', Times, serif;font-weight:bold;"> Contact No </h1><h4><?php echo $food_mania_cno_1."<br><br>".$food_mania_cno_2;?></h4></tr>
                                  </table>
                    </div><hr>

                    <div align="center">
                       <h1 style="font-family:'Times New Roman', Times, serif;font-weight:bold;">Time Service</h1>
                           <table align="center">
                             <tr>
                               <h4 style="font-weight:bold;"> Monday To Saturday </h4>
                             </tr>
                             <td align="center" style="font-size:18px;"><?php echo $food_mania_op_mon_sat;?>&nbsp;&nbsp; To &nbsp;&nbsp;<?php echo $food_mania_cl_mon_sat;?></td>
                             <td></td>
                           </table><br>

                          <table align="center">
                           <tr>
                            <h4 style="font-weight:bold;">Sunday and Special day</h4>
                           </tr>    
                            <td align="center" style="font-size:18px;"><?php echo $food_mania_op_sun_spe;?>&nbsp;&nbsp; To &nbsp;&nbsp;<?php echo $food_mania_cl_sun_spe;?></td>
                          </table>  
                    </div><hr>

                    <div align="center">
                         <h1 style="font-family:'Times New Roman', Times, serif;font-weight:bold;">Restaurants Address</h1>
                                    <table align="center">
                                          <tr style="width:300px;text-transform:capitalize;" align="center">
                                              <td style="font-size:18px;"><?php echo $food_mania_address; ?></td         
                                          ></tr>
                                    </table>
					          </div><hr><br>

                    <div>
                      <h1 style="font-family:'Times New Roman', Times, serif;font-weight:bold;text-align:center;"> Instruction </h1><br>
                      <div class="container">
                        <div class="row" style="font-size:18px;">
                          <div class="col-sm-1"> 1.</div>
                          
                          <div class="col-sm-10"> After completion of the order process, you can not cancel an order in any case shall ensure.</div>
                        </div>

                        <div class="row" style="font-size:18px;">
                          <div class="col-sm-1"> 2.</div>
                          
                          <div class="col-sm-10">You will need to login again to grant mandatory orders.</div>
                        </div>

                        <div class="row" style="font-size:18px;">
                          <div class="col-sm-1"> 3.</div>
                          
                          <div class="col-sm-11">If you have watched too many flavors in one dish you can give in the instruction.</div>
                        </div>

                        <div class="row" style="font-size:18px;">
                          <div class="col-sm-1"> 4.</div>
                          
                          <div class="col-sm-11">If you have many problems in the website can give you feedback.</div>
                        </div>

                       <div class="row" style="font-size:18px;">
                          <div class="col-sm-1"> 5.</div>
                          
                          <div class="col-sm-11">If you do choose to be in cash when the thing you can not cancel in any case, after giving the order.</div>
                        </div>
                      </div>
                    </div><br><br><br>
					    
    <!--contact.php Page Content Start-->
    
    <!--Footer Start-->
    <?php include_once("footer.php"); ?>
    <!--Footer Start-->
     
    
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
		<!-- datepicker js -->
        <script src="js/bootstrap-datepicker.js"></script>
		<!-- timepicker js -->
        <script src="js/jquery.timepicker.min.js"></script>
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
        <!-- nivo.slider js -->
        <script src="lib/js/jquery.nivo.slider.pack.js"></script>
        <script src="lib/js/nivo-active.js"></script>
		<!-- wow js -->
        <script src="js/wow.min.js"></script>
		<!-- Sticky JS -->	
        <script src="js/jquery.sticky.js"></script>
		<!-- venobox js -->
        <script src="lib/venobox/venobox.js"></script>
		<!-- Scroll up js -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- google map  js -->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuU_0_uLMnFM-2oWod_fzC0atPZj7dHlU"></script>
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script>
            function initialize() {
                var mapOptions = {
                    zoom: 15,
                    scrollwheel: false,
                    center: new google.maps.LatLng(23.81033, 90.41252)
                };
                var map = new google.maps.Map(document.getElementById('googleMap'),
                    mapOptions);
                var marker = new google.maps.Marker({
                    position: map.getCenter(),
                    animation: google.maps.Animation.BOUNCE,
                    icon: 'img/map-marker.png',
                    map: map
                });
            }
            google.maps.event.addDomListener(window, 'load', initialize);
        </script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
		
    </body>

<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:50:52 GMT -->
</html>
