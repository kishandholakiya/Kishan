<?php 
session_start();
include_once("client_connection.php");

$con = new client_connection();
$con->client_connect();


include_once("food_mania_admin/production/connection.php");

$con2 = new connection();
$con2->connect();


unset($_SESSION['customer_id']);
unset($_SESSION['customer_name']);
unset($_SESSION['cno']);
unset($_SESSION['email']);
unset($_SESSION['otp_num']);
unset($_SESSION['order_id']);



//delete cart informtion from table tbl_cart
if(isset($_GET['cart_id']))
{
	//delete from cart table
	$tmp="delete_dishes_from_cart";
	$cart_id=$_GET['cart_id'];
	$con->iuds_tbl_cart($tmp,$cart_id,$register_id,$sub_dishes_id);
	header("Location:cart.php");
}
if(isset($_REQUEST['btn_send_order']))
{
    if(!isset($_SESSION['customer']))
    {
        header("Location:registration.php?mm=no_login");
    }
    else
    {   
       
        //check total payment of customer 
        if(is_string($_POST['total_quantity']))
        {
            $ans1=explode(",", $_POST['total_quantity']); 
            $a=0;
            foreach($ans1 as $key1=>$value1)
            {

                $ans2=explode("-", $value1); 
                foreach($ans2 as $key2=>$value2);
                {
                    $tmp="select_sub_dishes";
                    $sub_dishes_id=$ans2[1];
                    $main_dishes_id=$name=$price=$discription=$status=$img="";
                    $res2=$con2->iud_in_tbl_sub_dishes($sub_dishes_id,$main_dishes_id,$tmp,$name,$price,$discription,$status,$img);
                    $b=$ans2[0]*$res2['sub_dishes_price']; 
                    $a=$a+$b; 
                }
            }
        }
        

        //if total payment is more then 100 then accept order otherwise gave message and onot acept order 
        if($a>=100 || $_POST['total_price']>=100)
        {
            
            //insert record in table tbl_order ans select order_id
            // echo $_POST['total_price'];
            // return;

            
			// combile all taste in array
			$_POST['taste']="";
			for($i=1;$i<$_POST['total_taste'];$i++)
			{
				$_POST['taste']=$_POST['taste'].$_POST['taste_num_'.$i].",";
			}
			$_POST['taste'];
			
			// Insert, Update, Delete,select in tbl_order
            $tmp="insert";
            $register_id=$_SESSION['customer'];
            
			
			//set delivery time
			$order_delivery_time=$_POST['delivery_time_1']." ".$_POST['delivery_time_2'];
			
			
			//this order is not show by admin
			$res3=$con->iuds_tbl_order($tmp,$order_id,$register_id,$_POST['payment'],$_POST['taste'],$_POST['delivery_address'],$order_delivery_time,$_POST['total_quantity'],$_POST['order_special_instruction']);
            $order_id=$res3;
			if(!empty($res3))
            {
                //select payment details(payment_type)
                $tmp="select";
                $payment_id=$_POST['payment'];
                $res4=$con->iuds_tbl_payment($tmp,$payment_id);
                if($res4[1]=="Paypal" || $res4[1]=="paypal" || $res[1]=="pay pal" || $res[1]=="Pay pal")
                {
                    if(empty($a))
                    {
                        $total_payment=$_POST['payment'];
                    }
                    else
                    {
                        $total_payment=$a;
                    }
                    header("Location:../paypal_integration_php/products.php?total_payment=$total_payment&order_id=$order_id&register_id=$register_id");
                    return;
                }
                else
                {
                    // if payment type is not paypal then payment is show to admin
                    $order_id=$order_id;
                    $tmp="select";

                    $res=$con->iuds_tbl_order($tmp,$order_id,$register_id,$payment_id,$taste_id,$order_delivery_address,$order_delivery_time,$order_total_quantity_and_price,$order_special_instruction);
      			}
                //delete record from customer's cart 
                $tmp="delete_cart_When_order_receive";
                $res=$con->iuds_tbl_cart($tmp,$cart_id,$register_id,$sub_dishes_id);

                //generate bill and select all information of order
                $tmp="insert_for_jenerate_bill";
                $res7=$con->iuds_tbl_bill($tmp,$order_id,$register_id,$payment_id);
                header("Location:send_otp.php?notic=thank");
            }
            else
            {
                header("Location:cart.php?notic=check_connection");
            }
        }
        else
        {
            header("Location:cart.php?notic=price_much_up_100");
        }
    }
}





?>
<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:56:52 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>food mania</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->
        
        <!--All Google Fonts-->
        <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

		<!-- all css here -->
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="css/owl.carousel.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- datepicker css -->
        <link rel="stylesheet" href="css/bootstrap-datepicker.css">
		<!-- timepicker css -->
        <link rel="stylesheet" href="css/jquery.timepicker.css">
        <!-- nivo-slider css -->
        <link rel="stylesheet" href="lib/css/nivo-slider.css">
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
		<!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>

        
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
<div class="cart-wraper">
    <!--header slider area are start-->
     <?php include_once("header.php"); ?>
     <!-- Home slider is end -->


    <!-- Page Name Start -->
    <div class="page_name" style="">
		<h1><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;Cart</h1>
	</div>
    <!-- Page Name End -->
	
    <!-- cart are start-->
    <div class="cart-area pt60 pb60 ">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div align="center">
                <?php 
                if(isset($_GET['notic']))
                {
                    if($_GET['notic']=="thank") 
                    { ?>
                        <h3 class="text-danger" style="border-bottom:thick;">Thank You for Given Order... <br> We Provide Best Services for You</h3><br> <?php 
                    }
                    elseif($_GET['notic']=="check_connection") 
                    { ?>
                        <h3 class="text-danger" style="border-bottom:thick;">Please Check your Connection</h3><br> <?php 
                    }
                    elseif($_GET['notic']=="price_much_up_100") 
                    { ?>
                        <h3 class="text-danger" style="border-bottom:thick;">Please have an Order Minimum ₹100 </h3><br> <?php 
                    }
                    elseif($_GET['notic']=="order_cancle") 
                    { ?>
                        <h3 class="text-danger" style="border-bottom:thick;">Your advance order is Cancelled </h3><br> <?php 
                    }
                } 

                if(isset($_GET['paypal']))
                {
                    if($_GET['paypal']=="paypal_successfull") 
                    { 
                        
                        // select all custoemr cart details
                        $order_id=$_GET['order_id'];
                        $tmp="select";
                        $res=$con->iuds_tbl_order($tmp,$order_id,$register_id,$payment_id,$taste_id,$order_delivery_address,$order_delivery_time,$order_total_quantity_and_price,$order_special_instruction);
                        
                        // delete cart from customer 
                        $tmp1="delete_cart_When_order_receive";
                        $con->iuds_tbl_cart($tmp1,$cart_id,$res['register_id'],$sub_dishes_id);


                        //generate bill for customer
                        $tmp2="insert_for_jenerate_bill";
                        $con->iuds_tbl_bill($tmp2,$res['order_id'],$res['register_id'],$res['payment_id']);

                        ?>
                        <h3 class="text-danger" style="border-bottom:thick;">Thank You for Gave Payment</h3><br> <?php 
                    }
                    elseif($_GET['paypal']=="paypal_cancle") 
                    { ?>
                        <h3 class="text-danger" style="border-bottom:thick;">Your Paypal Payment is Cancel. Please Choose Othre Option For Payment</h3><br> <?php 
                    }
                } ?>
                </div>

                
                <?php
                if(isset($_SESSION['customer']))
                {

                    $que_1="SELECT * FROM tbl_order WHERE order_id=(SELECT MAX(order_id) FROM tbl_order WHERE register_id=".$_SESSION['customer'].")";
                    $r=mysql_query($que_1);  
                    $a=mysql_fetch_array($r);
                    $x=date("Y-m-d");
                    $y=explode(" ",$a['order_delivery_time']);
                    $z=explode(" ",$a['order_modify_date']);
                    if( ($a['order_delivery_time']=="0000-00-00 00:00:00" && $x==$z[0] && $a['order_is_status']!="3") || 
                        ($a['order_delivery_time']!="0000-00-00 00:00:00" && $x<=$y[0] && $a['order_is_status']!="3"))
                    { ?>
                        <div class="row">
                            <div class="col-sm-12" style="text-align:center;font-size:25px;">
                                <a href="Bill_info.php">Show Bill</a><br><br>
                            </div>
                        </div><br> <?php
                    }
                } ?>
				
				
				
				<?php
				if(isset($_SESSION['customer']))
				{ ?>
					<div class="time_close">
					
                	</div> <?php
				} ?>
               
                  
                <form method="post" >
                   <div class="table-responsive">
                    <table class="shop_table cart table">
                        <thead>
                            <tr>
                                <th class="product-remove"></th>
                                <th class="product-thumbnail">Image</th>
                                <th class="product-name">Dish Name</th>
                                <th class="product-quantity">Taste *</th>
                                <th class="product-price">Price</th>
                                <th class="product-quantity">Quantity *</th>
                                <th class="product-subtotal">Total</th>
                            </tr>
                        </thead>
                        <tbody class="cart_info">
                        <?php 
                        if(isset($_SESSION['customer']))
						{
							//tampary variable
							$a=0;
							//Select all information from table tbl_cart
							$tmp="select_customer_cart";
                            $total_qty="";
							
							//select notmal vatiable which is use for get taste id
							$n=1;
										
							$register_id=$_SESSION['customer'];
							$res=$con->iuds_tbl_cart($tmp,$cart_id,$register_id,$sub_dishes_id);
							if(mysql_num_rows($res)>=1)
							{ 
								while($ans=mysql_fetch_array($res))
								{
									//select sub_dishes form sub_dishes_id
									$tmp="select_using_id";
									$sub_dishes_id=$ans['sub_dishes_id'];	
									$res2=$con->select_sub_dishes($tmp,$sub_dishes_id);
									extract($res2);
									//$ans2=mysql_fetch_array($res2);
                                    
									?>
                                    
                                	<tr class="cart_item itemList">
                                        <td class="remove">
                                        <span style="cursor:pointer"><a class="delete_cart_id">X</a></span>
                                        <input type="hidden" class="cart_id" value="<?php echo $ans['cart_id']; ?>">
                                        </td>
                                        <td class="item-img">
                                            <img src="img/food_img/<?php echo $sub_dishes_img; ?>" alt="">
                                        </td>
                                        <td class="item-title" style="text-transform:capitalize;"><?php echo $sub_dishes_name; ?></td>
                                        
                                        <td class="item-taste">
                                        
										<?php 
                                        $q1="SELECT main_dishes_name FROM tbl_main_dishes WHERE main_dishes_id=(SELECT main_dishes_id FROM tbl_sub_dishes WHERE sub_dishes_id=".$sub_dishes_id.")";
                                        $r1=mysql_query($q1);
                                        $a1=mysql_fetch_array($r1);
										$tmp="select";
										$r2=$con->iuds_tbl_taste($tmp,$id);
										while($a2=mysql_fetch_array($r2))
										{
											if($a1[0]!="drinks" && $a1[0]!="drinks" && $a1[0]!="Drinks" && $a1[0]!="Drink" && $a1[0]!="sweets" && $a1[0]!="Sweets" && $a1[0]!="sweet" && $a1[0]!="Sweet" && $a1[0]!="ice cream" && $a1[0]!="Ice cream" && $a1[0]!="Ice Cream" && $a1[0]!="icecream" && $a1[0]!="Icecream") 
											{ ?> 
												<div class="row">
                                                    <div class="col-sm-4" style="float:left">
                                                        <input type="radio" name="<?php echo "taste_num_".$n; ?>"  class="info taste" required value="<?php echo $a2['taste_id'] ?>" title="Select any one Taste Option " />
                                                    </div>
                                                    <div class="col-sm-7" style="text-transform:capitalize;font-size:16px;">
                                                        <?php echo $a2['taste_name']; ?>
                                                    </div>
												</div><?php 
											}
											else
											{ ?>
                                            	<input type="hidden"  name="<?php echo "taste_num_".$n; ?>" value="0"><?php	
											}
										} $n++; ?></td>
                                        
                                        <td class="item-price"><?php echo "₹&nbsp;".$sub_dishes_price; ?> 
                                        	<input type="hidden" name="price" class="price"  value=<?php 
											echo $b=$sub_dishes_price; ?>><?php $a=$a+$b; ?>
                                            <input type="hidden" name="sub_dishes_id_cart" class="sub_dishes_id_cart" value="<?php echo $sub_dishes_id; ?>">
                                        </td>
                                        
                                        <td class="item-qty">
                                            <input type="number" name="quantity" class="quantity" value="1" min="1" max="20" required title="You can not select Quentity more then 20">
                                            <?php $total_qty=$total_qty."1-".$sub_dishes_id.","; ?>
                                        </td>
                                        
                                        <td class="total-price sub_dishes_price"><?php echo "₹&nbsp;".$sub_dishes_price; ?> </td>
                                    </tr><?php 	
								}	?>
                                <tr class="cart_item subdishes_and_quentity">
                                	<td class="row" colspan="6" style="color:#333300;font-weight:bold;font-size:18px;">
                                    	Total Price
                                    </td>
                                    <td class="row all_sub_dishes_price" style="color:#333300;font-weight:bold;font-size:18px;"><?php echo "₹&nbsp;".$a; ?>
                                    </td>
                                    <input type="hidden" name="total_taste" value="<?php echo $n; ?>">
                                    <input type="hidden" name="total_price" id="total_price" value="<?php echo $a; ?>"> 
                                    <input type="hidden" name="total_quantity" id="all_quantity_pass" class="all_quantity_pass" value="<?php echo $total_qty; ?>">
                                </tr> <?php 
							}
							else
							{ ?> 
								<tr class="cart_item">
                                <td class="total-price text-danger" style="border-bottom:thick;text-transform:uppercase;" colspan="15"> No Dishes is available in cart</td>
                            </tr>
								
								<?php 
							}
						}
						else
						{ ?>
                            <tr class="cart_item">
                                <td class="total-price text-danger" style="border-bottom:thick;text-transform:uppercase;" colspan="15"> Please Do Login or Check in</td>
                            </tr> <?php
						}
						?>
                        </tbody> 
                    </table>
                    </div><br>
                <div class="total-cart-wrap">
                    <div class="section-title text-center pt40">
                        <h3 style="font-size:30px;">Other Information</h3>
                    </div><br>
                    <div class="table-responsive">
                    <table class="cart-total-area table">
                        <tbody>
                          
                          <?php 
                          if(isset($_SESSION['customer']))
                          {
                          
                          ?>
                          <tr class="cart_item">
                                <td class="ctg-type" style="font-size:25px;text-transform:capitalize;">Delivery Address</td>
                                </td>

                                <td class="cgt-des">
									<div class="input-box"> <?php 
										$tmp="select_record";
										$register_id=$_SESSION['customer'];
										$r=$con->iuds_tbl_register($tmp,$register_id,$fname,$lname,$address,$gender,$bod,$contact,$email,$pass,$ip_address);?>
										<textarea class="form-control " name="delivery_address" id="delivery_address" rows="3" id="comment" placeholder="Write Here your delivery address&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" style="resize:none;text-transform:capitalize;" required pattern="{1,200}" title="Change your delivery address"><?php echo $r['register_address']; ?></textarea>
									</div>        
                            	</td>
                          </tr>

                          <tr class="cart_item">
                                <td class="ctg-type" style="font-size:25px;text-transform:capitalize;">Delivery Date & Time</td>
                                </td>
                                <td class="cgt-des"><?php 
                                    //select min date
                                    $date=new DateTime(date("Y-m-d"));
                                    $date->modify('+2 day');
                                    $min_date=$date->format('Y-m-d');
                                    
                                    //select max date
                                    $date=new DateTime(date("Y-m-d"));
                                    $date->modify('+7 day');
                                    $max_date=$date->format('Y-m-d');                    
                    
                                    
                                    //select max time
                                    $time=mysql_fetch_array($con2->select_admin());
                                    $min_time=$time['food_mania_op_mon_sat'];
                                    $max_time=$time['food_mania_cl_mon_sat'];   
                                    ?>
                                        
                                    <div class="row">
                                        <p style="text-align:left;margin-left:20px;">For Advance Order Click Here</p>
                                        <div class="col-md-2 col-lg-1 col-sm-2 col-xs-3">
                                            <input type="checkbox" class="checkbox">
                                        </div>
                                        <div class="col-md-9 col-lg-10 col-sm-9 col-xs-7">
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="date" name="delivery_time_1" class="info address_dis" required min="<?php echo $min_date; ?>" max="<?php echo $max_date; ?>" title="Advance Order must between 5 hour to 2 days" style="float:left;">
                                                </div>       
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-box">
                                                    <input type="time" name="delivery_time_2" class="info address_dis" required min="<?php echo $min_time; ?>" max="<?php echo $max_time; ?>" title="you can only gave advance order next 3 days" style="float:left;">
                                                </div>       
                                            </div>
                                        </div>
                                    </div>
                                    <p class="note" style="text-align:left;">Note :- Advance order are taken prior 2 days from the Delivery date & It is only cancelled Before 2 Days Delivery Dime</p> 
                                </td>
                            </tr>
                          
                          <?php }?>


                            <tr class="cart_item">
                                <td class="ctg-type" style="font-size:25px;text-transform:capitalize;">Any Instraction</td>
                                <td class="cgt-des">
                                <p style="text-align:left;margin-left:20px;">One day order is Place In 2 hour & If you want to change time then give instruction</p>
                                  <textarea class="form-control" name="order_special_instruction" rows="3" id="comment" placeholder="Write Here &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Not Neccessary)" style="resize:none;text-transform:capitalize;"></textarea>
                                </td>
                            </tr>
							
							
							
							<?php 
                          if(isset($_SESSION['customer']))
                          {
                          
                          ?>
                          <?php }?>

				          <tr class="cart_item">
                                <td class="ctg-type" style="font-size:25px;text-transform:capitalize;"> Payment *</td>
                                <td class="cgt-des">
                                   <div class="row input-box" align="center">
                                    <?php 
                                    $tmp="select";
                                    $res=$con->iuds_tbl_payment($tmp,$id);
                                    while($ans=mysql_fetch_array($res))
                                    {
                                        extract($ans);  ?>
                                        <div class="row">
                                            <div class="col-md-2 col-lg-1 col-sm-2 col-xs-3" style="margin-left:20px;">
                                                <input type="radio" name="payment" class="info" value="<?php echo $payment_id;?>"  <?php if(isset($_SESSION['customer']))  { echo "required title='Select Payment Option'"; }?> >
                                            </div>
                                            <div class="col-md-9 col-lg-10 col-sm-9 col-xs-7">
                                                <label style="text-align:left;float:left;font-size:18px;"><?php echo $payment_type; ?></label> 
                                            </div> 
                                        </div> <?php 
                                    }?>
                                        
                                </div>              
							  </td>
                          </tr>

                          <tr class="cart_item">
                                <td class="ctg-type" style="font-size:25px;text-transform:capitalize;">Delivery Charge</td>
                                <td class="ctg-type" style="font-size:25px;text-transform:capitalize;"><label style="text-align:left;float:left;font-size:18px;">Free Home Delivery </label></td>           
                          </tr>

                          <tr class="cart_item">
                                <td class="ctg-type" colspan="2" style="font-size:25px;text-transform:capitalize;text-align:center;"><label style="text-align:center;font-size:18px;">Notic :- One Day order is not cancelled. </label></td>           
                          </tr>
                          
                          </tbody>
                    </table>
                 </div><br><br><br>
                  </div>              
                 <div class="row">
                     <div class="col-ms-4 col-md-4 col-xs-4" style="float:left;">
                     </div>
                     
                     <div class="col-ms-4 col-md-4 col-xs-4">
                     </div>

                     <div class="col-ms-4 col-md-4 col-xs-4">
                        <input  type="submit" class="in-btn raj3 dis" name="btn_send_order" id="btn_send_order" value="Send Order">
                     </div>
                 </div>

                 </form>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- cart are end-->

    <!--footer area are start-->
      <?php include_once("footer.php"); ?>
    <!--footer area are end-->

</div>
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
		<!-- datepicker js -->
        <script src="js/bootstrap-datepicker.js"></script>
		<!-- timepicker js -->
        <script src="js/jquery.timepicker.min.js"></script>
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
        <!-- nivo.slider js -->
        <script src="lib/js/jquery.nivo.slider.pack.js"></script>
        <script src="lib/js/nivo-active.js"></script>
		<!-- wow js -->
        <script src="js/wow.min.js"></script>
		<!-- Sticky JS -->	
        <script src="js/jquery.sticky.js"></script>
		<!-- venobox js -->
        <script src="lib/venobox/venobox.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
        
        <!-- Check confirmation from customer to delete subdishes from cart table -->
        
        <script language="javascript">
		
		jQuery(document).ready(function($){


			//use function for show all taste information 
			$('.taste').select(function(){
			$taste=$(this).val();
			//console.log($taste);show_all_taste_of_food
			show_taste();
			});
			function show_taste(){
				$all_taste="";
				$('.itemList').each(function(){
					$taste=$(this).val();
					$all_taste=$all_taste+$taste+","
					
					});
				$('#total_taste').val($all_taste);
				}
			
			//use function for total price of all dishes using quentity and price
			$('.quantity').change(function(){
				$qty = $(this).val();
				$price = $(this).parent().parent().find('.price').val();
                $sub_dishes_id_cart = $(this).parent().parent().find('.sub_dishes_id_cart').val();
				//console.log($qty+"-"+$price);
				$(this).parent().parent().find('.sub_dishes_price').html("₹&nbsp;"+($qty*$price));
				setTotal();
			});
           function setTotal(){
				$Total = 0;
				$total_quantity="";
				$('.itemList').each(function(){
					$qty = $(this).find('.quantity').val();
					$price = $(this).find('.price').val();
					$Total += ($qty*$price);
					$sub_dishes_id_cart = $(this).find('.sub_dishes_id_cart').val();
                    $total_quantity=$total_quantity+$qty+"-"+$sub_dishes_id_cart+",";
					//console.log($total_quantity);
					//console.log($qty+"-"+$sub_dishes_id_cart+","); 
					//console.log("1");
				});
				$('.all_sub_dishes_price').html("₹&nbsp;"+$Total);
				$('.all_quantity_pass').val($total_quantity);
			}
		});		
		</script>
        
		<script src="Food_Mania_Admin/production/jquery-3.1.1.min.js"></script>
        <script>
		$(document).ready(function(){
			
			
            $(".address_dis").attr("disabled","disabled");
            $(".address_dis").css("cursor","not-allowed"); 
            $(".note").hide();
            


            $(".checkbox").click(function(){
                if($(this).is(":checked"))
                {
                    $(this).parent().parent().parent().find(".address_dis").removeAttr("disabled","disabled");
                    $(this).parent().parent().parent().find(".address_dis").css("cursor","text");
                    $(this).parent().parent().parent().find(".note").show();
                }
                else
                {
                    $(this).parent().parent().parent().find(".address_dis").attr("disabled","disabled");
                    $(this).parent().parent().parent().find(".address_dis").css("cursor","not-allowed");
                    $(this).parent().parent().parent().find(".note").hide();
                }
            });


			
            $("button").hover(function(){
				$(this).css("color","#303030");
				$(this).css("background-color","white");
			},
			function(){
				$(this).css("color","white");
				$(this).css("background-color","#303030");
			});
			


            
			refresh();
			//refresh time class
			function refresh()
			{
			  setTimeout(function(){
				$(".time_close").fadeIn('fast').load('check_time.php');
				if($("div").hasClass("restaurant_close"))
				{
					$(".dis").attr("disabled","disabled");
					$(".dis").css("cursor","not-allowed");
				}
				else
				{
					$(".dis").removeAttr("disabled","disabled");
					$(".dis").css("cursor","pointer");
				} 
				refresh();
			  },200);
			}


			
			$(".delete_cart_id").click(function(){
				var confirm_to_delete_cart = confirm("Are You want to Sure Remove this Dish From Cart.....?");
				if(confirm_to_delete_cart==true)
				{
					var cart_id = $(this).parent().parent().find('.cart_id').val();
					$.ajax({
						url: 'del_cart.php',
						method: 'GET',
						data: { "cart_id" : cart_id },
						success: function(data){
							location.reload('.cart_info'); 
						}
					});
				}
			});
		});
		
		
        </script>
       
    </body>

<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:56:52 GMT -->
</html>
