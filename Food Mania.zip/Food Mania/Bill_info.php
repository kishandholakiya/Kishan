<?php 
session_start();
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();



include_once("../Food Mania/food_mania_admin/production/connection.php");
$con2 = new connection();
$con2->connect();


if(!isset($_SESSION['customer']))
{
	header("Location:registration.php?mm=no_login");
}


if(isset($_SESSION['customer']))
{
    if(isset($_GET['cancle_order_id']) && isset($_GET['cancle_bill_id']))
    {
        $query_1="DElETE FROM tbl_order WHERE order_id=".$_GET['cancle_order_id'];
        $res_1=mysql_query($query_1);

        $query_2="DElETE FROM tbl_bill WHERE bill_id=".$_GET['cancle_bill_id'];
        $res_2=mysql_query($query_2);

        if($res_1== TRUE && $res_2== TRUE) 
        {
            header("Location:send_otp.php?order_cancle=advance_order_cancle");
        }
        else
        {
            header("Location:cart.php?notic=check_connection");
        }
    }
}


   




?>
<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:56:52 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>food mania</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->
        
        <!--All Google Fonts-->
        <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

		<!-- all css here -->
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="css/owl.carousel.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- datepicker css -->
        <link rel="stylesheet" href="css/bootstrap-datepicker.css">
		<!-- timepicker css -->
        <link rel="stylesheet" href="css/jquery.timepicker.css">
        <!-- nivo-slider css -->
        <link rel="stylesheet" href="lib/css/nivo-slider.css">
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
		<!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>

        
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
<div class="cart-wraper">
    <!--header slider area are start-->
     <?php include_once("header.php"); ?>
     <!-- Home slider is end -->

      <!-- Page Name Start -->
    
    <div class="page_name" style="">
        <h1><i class="fa fa-money" aria-hidden="true"></i>&nbsp;Bill </h1>
    </div>
    
    <?php 
	
	
	if(isset($_SESSION['customer']))
	{
		$tmp="select_bill_info";
		$register_id=$_SESSION['customer'];
		$res=$con->iuds_tbl_bill($tmp,$order_id,$register_id,$payment_id);

        //select full order of customer
        $q2="SELECT * FROM tbl_order WHERE order_id=".$res['order_id'];
        $r2=mysql_query($q2);
        $a2=mysql_fetch_array($r2);
                        
	}


	
	?>
    
    
    
    
    
    <!-- Page Name End -->
    <!-- cart are start-->
    <div class="cart-area pt60 pb60 ">
    <div class="container">
        <div class="row">
                <div class="total-cart-wrap">
                    <div class="section-title text-center ">
						<h4><a href="cart.php">Back To Cart Page</a></h4>
                    </div><br>
					<div class="row">
                        <div class="col-md-6 col-sm-12">
                            <h4 style="text-transform:capitalize;text-align:left;">Customer : &nbsp; <?php 
							$q="SELECT * FROM tbl_register WHERE register_id=".$_SESSION['customer'];
							$res2=mysql_query($q);
							$ans=mysql_fetch_array($res2);
							echo $ans['register_fname']."&nbsp;".$ans['register_lname']; ?></h4>
							<h4 style="text-transform:capitalize;text-align:left;">Address : &nbsp; <?php echo $a2['order_delivery_address']; ?></h4>
                            <h4 style="text-transform:capitalize;text-align:left;">Email Id : &nbsp; <?php echo $ans['register_email_id']; ?></h4>
                            <h4 style="text-transform:capitalize;text-align:left;">Contect No : &nbsp; <?php echo $ans['register_contect_no']; ?>
                        </div>
                        
                        <div class="col-md-6 col-sm-12">
                            <h4 style="text-align:right;">Bill Date: &nbsp;<?php echo $res['bill_entry_date']; ?></h4>
                            
                            

                            <?php 
                            if($a2['order_delivery_time']!="0000-00-00 00:00:00" )
                            { ?>
                                <h4 style="text-align:right;">Delivery Date: &nbsp;<?php echo $a2['order_delivery_time']; ?></h4>
                                
                                <?php 
                                $date=new DateTime(date("Y-m-d H:i:s"));
                                $date->modify('+48 hour');
                                $min_date=$date->format('Y-m-d H:i:s');
                                if($min_date<=$a2['order_delivery_time'])
                                { 
                                    $cancle_order_id=$a2['order_id']; ?>
                                    <a onclick="return cancle_order_check();" href="bill_info.php?cancle_order_id=<?php echo $cancle_order_id; ?>&cancle_bill_id=<?php echo $res['bill_id']; ?>" style="text-align:right;float:right">Cancel Your Order </a> <?php 
                                }
                            } ?>
                        </div><br><br><br><br>
                        
                        <div class="col-sm-12" style="text-align:center;">
                        	<h3 style="font-weight:900;">Order Dishes</h3>
                        </div>
                        
                    </div><br>

                    
                    <div class="table-responsive">
                    <table class="shop_table cart table">
                        <thead>
                            <tr>
                                <th class="product-name">Dish Name</th>
                                <th class="product-quantity">Taste</th>
                                <th class="product-price">Price</th>
                                <th class="product-quantity">Quantity</th>
                                <th class="product-subtotal">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
						
                      	
                        $ans1=explode(",", $a2['order_total_quantity_and_price']); 
                      	$a=0;


                        $taste=explode(",", $a2['taste_id']); 
                        $i=0; 
                      
                      	foreach($ans1 as $key1=>$value1)
                      	{
                      		$ans2=explode("-", $value1);
                        	foreach($ans2 as $key2=>$value2);
                        	{
                          		$tmp="select_sub_dishes";
	    	    	        	$sub_dishes_id=$ans2[1];
    	    	                $main_dishes_id=$name=$price=$discription=$status=$img="";
             		            $res2=$con2->iud_in_tbl_sub_dishes($sub_dishes_id,$main_dishes_id,$tmp,$name,$price,$discription,$status,$img);
								//$ans2=mysql_fetch_array($res2);
								if(is_array($res2))
								{  ?>
                               		<tr class="cart_item itemList">
                                        <td class="item-title"><?php echo $res2['sub_dishes_name']; ?></td>
                                        <td style='text-transform:capitalize;'><?php 
                                            if($taste[$i]!=0)
                                            {
                                              $q2="SELECT taste_name FROM tbl_taste WHERE taste_id=".$taste[$i];
                                              $r2=mysql_query($q2);
                                              $a2=mysql_fetch_array($r2);
                                              echo $a2[0];
                                            }
                                            else
                                            {
                                              echo "No Taste";
                                            } ?></td>
                                        <td class="item-price"> <?php echo "₹&nbsp;".$res2['sub_dishes_price']; ?> </td>
                                        <td class="item-qty"> <?php echo $ans2[0]; ?> </td>
                                        <td class="total-price sub_dishes_price"><?php 
										$b=$ans2[0]*$res2['sub_dishes_price']; 
										echo "₹&nbsp;".$b;
										$a=$a+$b; 
                                        $i++; ?></td>
                                	</tr> 
                                    <?php
								 }
							}
							   
						}?>
                        <tr class="cart_item">
                                <td class="ctg-type" colspan="4" style="font-size:20px;text-transform:capitalize;">Total Payment</td>
                                <td class="ctg-type" style="font-size:20px;text-transform:capitalize;"><label style="text-align:left;font-size:18px;"><?php echo "₹&nbsp;".$a; ?></label></td> 
                          </tr>
                          	                                
                        </tbody>
                    </table>
            	</div><br>
                
                <div class="total-cart-wrap">
                    <div class="table-responsive">
                    <table class="cart-total-area table">
                        <tbody>
                          
                    	</tbody>
                    </table>
                    
                 </div><br><br><br>
            </div>
        </div>
    </div>
</div>
    <!-- cart are end-->

    <!--footer area are start-->
      <?php include_once("footer.php"); ?>
    <!--footer area are end-->

</div>
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
		<!-- datepicker js -->
        <script src="js/bootstrap-datepicker.js"></script>
		<!-- timepicker js -->
        <script src="js/jquery.timepicker.min.js"></script>
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
        <!-- nivo.slider js -->
        <script src="lib/js/jquery.nivo.slider.pack.js"></script>
        <script src="lib/js/nivo-active.js"></script>
		<!-- wow js -->
        <script src="js/wow.min.js"></script>
		<!-- Sticky JS -->	
        <script src="js/jquery.sticky.js"></script>
		<!-- venobox js -->
        <script src="lib/venobox/venobox.js"></script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>
        
        <!-- Check confirmation from customer to delete subdishes from cart table -->
        <script language="javascript">
        function cancle_order_check()
        {
            var a=confirm("Are you Sure to take Delete this Order....?");
            if(a==true)
                return true;
            else
                return false;
        }
        cancle_order_check
        </script>
        
        <script language="javascript">
		/*function sub_dishes()
		{
			var ajaxRequest;  // The variable that makes Ajax possible!
	
			try{
				// Opera 8.0+, Firefox, Safari
				ajaxRequest = new XMLHttpRequest();
			} catch (e){
				// Internet Explorer Browsers
				try{
					ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try{
						ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e){
						// Something went wrong
						alert("Your browser broke!");
						return false;
					}
				}
			}
			
			// Create a function that will receive data sent from the server
			ajaxRequest.onreadystatechange = function(){
				if(ajaxRequest.readyState == 4){
					//alert("hello"+document.getElementById('sub_dishes_price'));
					var ajaxDisplay = document.getElementById('sub_dishes_price');
					ajaxDisplay.innerHTML = ajaxRequest.responseText;
				}
			}	
			
			
			var quantity=document.getElementById('quantity').value;
			var price=document.getElementById('price').value;
			//show query string
			//alert("?quantity="+quantity+"&price="+price);
			
			//var querystring = "?quantity="+quantity+"&price="+price;
			//ajaxRequest.open("GET","change_price.php"+querystring,true);
			//ajaxRequest.send(null);
	
			var ans=price*quantity;	
				
			$label = '<label name="sub_dishes_price" id="sub_dishes_price">₹&nbsp;' + ans + '</label>';
			
		}*/


		jQuery(document).ready(function($){
			$('.quantity').change(function(){
				$qty = $(this).val();
				$price = $(this).parent().parent().find('.price').val();
                $sub_dishes_id_cart = $(this).parent().parent().find('.sub_dishes_id_cart').val();
				//console.log($qty+"-"+$price);
				$(this).parent().parent().find('.sub_dishes_price').html("₹&nbsp;"+($qty*$price));
				setTotal();
			});
           function setTotal(){
				$Total = 0;
				$total_quantity="";
				$('.itemList').each(function(){
					$qty = $(this).find('.quantity').val();
					$price = $(this).find('.price').val();
					$Total += ($qty*$price);
					$sub_dishes_id_cart = $(this).find('.sub_dishes_id_cart').val();
                    $total_quantity=$total_quantity+$qty+"-"+$sub_dishes_id_cart+",";
					//console.log($total_quantity);
					//console.log($qty+"-"+$sub_dishes_id_cart+","); 
					//console.log("1");
				});
				$('.all_sub_dishes_price').html("₹&nbsp;"+$Total);
				$('.all_quantity_pass').val($total_quantity);
			}
		});		
		</script>
        <script src="Food_Mania_Admin/production/jquery-3.1.1.min.js"></script>
        <script>
		$(document).ready(function(){
			$("button").hover(function(){
				$(this).css("color","#303030");
				$(this).css("background-color","white");
			},
			function(){
				$(this).css("color","white");
				$(this).css("background-color","#303030");
			});
		});
        </script>
        
        

        
    </body>

<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/cart.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:56:52 GMT -->
</html>
