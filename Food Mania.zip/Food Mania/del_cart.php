<?php 
session_start();
include_once("client_connection.php");
include_once("food_mania_admin/production/connection.php");
$con = new client_connection();
$con->client_connect();



if(isset($_GET['cart_id']))
{
	//delete from cart table
	$tmp="delete_dishes_from_cart";
	$cart_id=$_GET['cart_id'];
	$con->iuds_tbl_cart($tmp,$cart_id,$register_id,$sub_dishes_id);
}

?>
