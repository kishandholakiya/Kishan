<?php 
session_start();
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect(); 
?>



<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:44:19 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
        	<title>Food Mania</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
	<!-- Place favicon.ico in the root directory -->
	
	<!--All Google Fonts-->
	<link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

	<!-- all css here -->
	<!-- bootstrap v3.3.6 css -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- animate css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- jquery-ui.min css -->
	<link rel="stylesheet" href="css/jquery-ui.min.css">
	<!-- meanmenu css -->
	<link rel="stylesheet" href="css/meanmenu.min.css">
	<!-- owl.carousel css -->
	<link rel="stylesheet" href="css/owl.carousel.css">
	<!-- font-awesome css -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- datepicker css -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<!-- timepicker css -->
	<link rel="stylesheet" href="css/jquery.timepicker.css">
	<!-- nivo-slider css -->
	<link rel="stylesheet" href="lib/css/nivo-slider.css">
	<!-- venobox css -->
	<link rel="stylesheet" href="lib/venobox/venobox.css">
	<!-- style css -->
	<link rel="stylesheet" href="style.css">
	<!-- responsive css -->
	<link rel="stylesheet" href="css/responsive.css">
	<!-- modernizr css -->
	<script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
    
    <!-- Header Start -->
       <?php include_once("header.php"); ?>
    <!-- Header End -->

	<div class="page_name">
		<h1><i class="fa fa-cutlery" aria-hidden="true"></i>&nbsp;Menu</h1>
	</div>   
    
    <!-- Page Name Start -->
    
    <!-- Page Name End -->
    
    <!--Blog start -->
    <div class="event-area blog-area our-special-menu-area  pt60 pb60 ">
            <div class="container">
                <div class="row">
					<form action="" class="navbar-form navbar-right" method="get">
					  	<div class="input-group">
						  	<input type="Search" name="search" id="search" placeholder="Search By Name..." class="form-control typeahead tt-query" autocomplete="off" spellcheck="false"  />
						  	<div class="input-group-btn">
							  	<button name="submit_search" class="btn btn-info">
								  	<span class="fa fa-search"></span>
							  	</button>
						  	</div>
					  	</div>
					</form><br><br><br>
                
				
				<div align="center">
                </div>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="total-aside">
                         <aside>
                             <div class="single-widget text-center">
                                 <div class="whdget-title">
                                     <h2>Categories</h2>
                                 </div>
                                 <ul>
                                    <li></li>                                            

                                    <?php 
                                    //show main dishes from table tbl_main_dishes
                                    $tmp="select_tbl_main_dishes";
                                    $res=$con->select_all_data($tmp,$main_dishes_name);
                                    if(!empty($res))
                                    {
                                        while($ans=mysql_fetch_array($res))
                                        {
                                            extract($ans); ?>
                                            <li><a href="menu.php?name=<?php echo $main_dishes_name; ?>"><?php echo $main_dishes_name; ?></a></li>                                            
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "Please Check Your Connection....";
                                    }?>    
                                 </ul>
                             </div>
                        </aside>
                        </div>
                     </div>

                    <div class="col-md-8 col-sm-8 col-xs-12">
	                        <div class="special-menu ">
                        <div class="sma-img">
                           <div class="sma-heading">
                               <h3 class="heading_name" style="text-transform:capitalize"><?php 
                                    if(isset($_GET['name']))    
                                        echo $_GET['name'];
									elseif(isset($_GET['search']))
										echo $_GET['search'];
                                    else
                                        echo "Menu"; ?></h3>
                           </div>
                        </div>
                        <div class="total-menu-item carsoule-btn smp-carsoule">
                            <div class="total-menu-single">
                                <div class="single-menu-item">
                                </div> 
                                 <?php 
                                 if(isset($_GET['name']))
                                 {
                                    //show  all information of sub dishes from main dishes name
                                    $tmp="sub_dishes_show_from_main_dishes";
                                    $main_dishes_name=$_GET['name'];
                                    $res=$con->select_all_data($tmp,$main_dishes_name);
                                    if(mysql_num_rows($res)>0)
                                    {
										$sql = "SELECT * FROM tbl_sub_dishes WHERE sub_dishes_is_status='1' AND
                                            main_dishes_id=
                                        (SELECT main_dishes_id 
                                            FROM tbl_main_dishes 
                                        WHERE 
                                            main_dishes_name='".$_GET['name']."') 
                                            ORDER BY(sub_dishes_name)";
                                        $result=mysql_query($sql);
                                        $total_records=mysql_num_rows($result);
                                        while($ans=mysql_fetch_array($res))
                                        {
                                            extract($ans);?>
                                            <div class="single-menu-item sm-image">
                                            <div class="row add_dishes_in_cart">
                                                <div class="col-md-3 col-sm-3 img sm-image">
                                                     <img src="img/food_img/<?php echo $sub_dishes_img; ?>"  class="img-thumbnail img-rounded" alt="">
                                                 </div><br>
                                                <div align="left" class="col-md-9 col-sm-9">
                                                    <div class="smi-heading">
                                                        <h3 style="text-transform:capitalize;"><?php echo $sub_dishes_name; ?></h3>
                                                    </div>
                                                    <div class="smi-des">
                                                        <span><?php echo $sub_dishes_discription; ?></span>
                                                    </div>
                                                    <div class="smi-price">
                                                       <span><?php echo "₹".$sub_dishes_price; ?></span>
                                                    </div>
                                                 
                                                <span style="cursor:pointer"><a class="com-btn add_dishes">Add Dish</a></span>
                                                <input type="hidden" class="sub_dishes_id" name="sub_dishes" value="<?php echo $sub_dishes_id; ?>">
                                                </div>
                                            </div>
                                            </div>
                                             <?php
                                        }
                                          ?><div align="center"> <?php 
                                          $num_rec_per_page=10;
                                          if($num_rec_per_page>$total_records)
                                          {
                                            $total_pages=1;  
                                          }
                                          else
                                          {
                                            $total_pages = ceil($total_records / $num_rec_per_page); 
                                          }
                                            if(isset($_GET['page']))
                                            {
                                              $page=$_GET['page'];
                                               if(3 <= $page && $page <= $total_pages-2)
                                                {
                                                    $start=$page-2;
                                                    $end=$page+2;
                                                }
                                                elseif(2 == $page && $page <= $total_pages-2)
                                                {
                                                    $start=$page-1;
                                                    $end=$page+2;
                                                }
                                                elseif(2 == $page && $page== $total_pages)
                                                {
                                                    $start=$page-1;
                                                    $end=$page;
                                                }
                                                elseif(2 == $page && $page <= $total_pages-1)
                                                {
                                                    $start=$page-1;
                                                    $end=$page+1;
                                                }
                                                
                                                
                                                elseif(1 == $page && $page <= $total_pages-2)
                                                {
                                                    $start=$page;
                                                    $end=$page+2;
                                                }
                                                elseif(1 == $page && $page == $total_pages-1)
                                                {
                                                    $start=$page;
                                                    $end=$page+1;
                                                }
                                                elseif(1 == $page && $page == $total_pages)
                                                {
                                                    $start=$page;
                                                    $end=$page;
                                                }
                                                elseif(2 == $page && $page == $total_pages)
                                                {
                                                    $start=$page-1;
                                                    $end=$page+1;
                                                }
                                                elseif(2 == $page && $page == $total_pages-1)
                                                {
                                                    $start=$page;
                                                    $end=$page+1;
                                                }
                                                elseif(3<= $page && $total_pages==$page+1)
                                                {
                                                    $start=$page-2;
                                                    $end=$page+1;
                                                }
                                                elseif(3<= $page && $total_pages==$page)
                                                {
                                                    $start=$page-2;
                                                    $end=$page;
                                                }

                                            }
                                            else
                                            {
                                              $start=1;
                                              if($total_pages==$start)
                                              {
                                                $end=$start;  
                                              }
                                              elseif($total_pages==$start+1)
                                              {
                                                $end=$start+1;
                                              }
                                              elseif($total_pages>=$start+2)
                                              {
                                                $end=$start+2;
                                              }
                                            }


                                            echo "<a href='menu.php?name=$main_dishes_name&page=1'>".'<< first'."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
                                            $j=1;  
                                            for ($i=$start; $i<=$end; $i++) 
                                            { 
                                                
                                                if($i==$_GET['page'] || ($j==1 && !isset($_GET['page'])))
                                                {
                                                    echo "&nbsp;&nbsp;<a style='color:red;' href='menu.php?name=$main_dishes_name&page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                                                }
                                                else
                                                {
                                                    echo "&nbsp;&nbsp;<a href='menu.php?name=$main_dishes_name&page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                                                
                                                }
                                                $j++;
                                            }
                                          
                                            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='menu.php?name=$main_dishes_name&page=$total_pages'>".'last >>'."</a> ";  
                                            ?></div><?php 
                                    }
                                    else
                                    {?>
                                        <div class="smi-heading">
                                           <h3 style="color:red;">No Dish is available this time.... Please choose other... </h3>
                                        </div> <?php 
                                        
                                    }
                                }
								elseif(isset($_GET['search']))
                                {
                                    //select all sub dishes
                                    $tmp="select_sub_dishes_from_search";
									$main_dishes_name=$_GET['search'];
                                    $res=$con->select_all_data($tmp,$main_dishes_name);
                                    if(mysql_num_rows($res)>0)
                                    {
										$search=$_GET['search'];
                                        $sql = "SELECT * FROM tbl_sub_dishes WHERE sub_dishes_is_status='1'
                                            && sub_dishes_name LIKE '%{$search}%'";
                                        $result=mysql_query($sql);
                                        $total_records=mysql_num_rows($result);
                                        
                                        while($ans=mysql_fetch_array($res))
                                        {
                                            extract($ans);?>
                                            <div class="single-menu-item sm-image">
                                            <div class="row">
                                                <div class="col-md-3 col-sm-3 img sm-image">
                                                     <img src="img/food_img/<?php echo $sub_dishes_img; ?>"  class="img-thumbnail img-rounded" alt="">
                                                 </div><br>
                                                <div align="left" class="col-md-9 col-sm-9">
                                                    <div class="smi-heading">
                                                       <h3 style="text-transform:capitalize;"><?php echo $sub_dishes_name; ?></h3>
                                                    </div>
                                                    <div class="smi-des">
                                                        <span><?php echo $sub_dishes_discription; ?></span>
                                                    </div>
                                                    <div class="smi-price">
                                                       <span><?php echo "₹".$sub_dishes_price; ?></span>
                                                    </div>
                                                <span style="cursor:pointer"><a class="com-btn add_dishes">Add Dish</a></span>
                                                <input type="hidden" class="sub_dishes_id" name="sub_dishes" value="<?php echo $sub_dishes_id; ?>">
                                                </div>
                                            </div>
                                            </div> <?php
                                        }
                                        ?><div align="center"> <?php 
                                          $num_rec_per_page=10;
										  $total_pages = ceil($total_records / $num_rec_per_page);
                                          if(isset($_GET['page']))
                                            {
                                              $page=$_GET['page'];
                                               if(3 <= $page && $page <= $total_pages-2)
                                                {
                                                    $start=$page-2;
                                                    $end=$page+2;
                                                }
                                                elseif(2 == $page && $page <= $total_pages-2)
                                                {
                                                    $start=$page-1;
                                                    $end=$page+2;
                                                }
                                                elseif(2 == $page && $page== $total_pages)
                                                {
                                                    $start=$page-1;
                                                    $end=$page;
                                                }
                                                elseif(2 == $page && $page <= $total_pages-1)
                                                {
                                                    $start=$page-1;
                                                    $end=$page+1;
                                                }
                                                
                                                
                                                elseif(1 == $page && $page <= $total_pages-2)
                                                {
                                                    $start=$page;
                                                    $end=$page+2;
                                                }
                                                elseif(1 == $page && $page == $total_pages-1)
                                                {
                                                    $start=$page;
                                                    $end=$page+1;
                                                }
                                                elseif(1 == $page && $page == $total_pages)
                                                {
                                                    $start=$page;
                                                    $end=$page;
                                                }
                                                elseif(2 == $page && $page == $total_pages)
                                                {
                                                    $start=$page-1;
                                                    $end=$page+1;
                                                }
                                                elseif(2 == $page && $page == $total_pages-1)
                                                {
                                                    $start=$page;
                                                    $end=$page+1;
                                                }
                                                elseif(3<= $page && $total_pages==$page+1)
                                                {
                                                    $start=$page-2;
                                                    $end=$page+1;
                                                }
                                                elseif(3<= $page && $total_pages==$page)
                                                {
                                                    $start=$page-2;
                                                    $end=$page;
                                                }
                                            }
                                            else
                                         	{
                                                $start=1;
                                              if($total_pages==$start)
                                              {
                                                $end=$start;  
                                              }
                                              elseif($total_pages==$start+1)
                                              {
                                                $end=$start+1;
                                              }
                                              elseif($total_pages>=$start+2)
                                              {
                                                $end=$start+2;
                                              }
                                          }
										  	$search=$_GET['search'];
                                            echo "<a href='menu.php?search=$search&page=1'>".'<< first'."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
                                            $j=1;  
                                            for ($i=$start; $i<=$end; $i++) 
                                            { 
                                                
                                                if($i==$_GET['page'] || ($j==1 && !isset($_GET['page'])))
                                                {
                                                    echo "&nbsp;&nbsp;<a style='color:red;' href='menu.php?search=$search&page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                                                }
                                                else
                                                {
                                                    echo "&nbsp;&nbsp;<a href='menu.php?search=$search&page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                                                }
                                                $j++;
                                            };
                                            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='menu.php?search=$search&page=$total_pages'>".'last >>'."</a> ";  
                                            ?></div><?php 
                                    }
                                    else
                                    {?>
                                        <div class="smi-heading">
                                           <h3 style="color:red;">No Dish is available.... Please choose other Dish... </h3>
                                        </div> <?php      
                                    }
                                } 
                                else
                                {
                                    //select all sub dishes
                                    $tmp="select_sub_dishes";
                                    $res=$con->select_all_data($tmp,$main_dishes_name);
                                    if(mysql_num_rows($res)>0)
                                    {
                                        $sql = "SELECT * FROM tbl_sub_dishes WHERE sub_dishes_is_status='1'
                                            ORDER BY(sub_dishes_name)";
                                        $result=mysql_query($sql);
                                        $total_records=mysql_num_rows($result);
                                        
                                        while($ans=mysql_fetch_array($res))
                                        {
                                            extract($ans);?>
                                            <div class="single-menu-item sm-image">
                                            <div class="row">
                                                <div class="col-md-3 col-sm-3 img sm-image">
                                                     <img src="img/food_img/<?php echo $sub_dishes_img; ?>"  class="img-thumbnail img-rounded" alt="">
                                                 </div><br>
                                                <div align="left" class="col-md-9 col-sm-9">
                                                    <div class="smi-heading">
                                                       <h3 style="text-transform:capitalize;"><?php echo $sub_dishes_name; ?></h3>
                                                    </div>
                                                    <div class="smi-des">
                                                        <span><?php echo $sub_dishes_discription; ?></span>
                                                    </div>
                                                    <div class="smi-price">
                                                       <span><?php echo "₹".$sub_dishes_price; ?></span>
                                                    </div>
                                                <span style="cursor:pointer"><a class="com-btn add_dishes">Add Dish</a></span>
                                                <input type="hidden" class="sub_dishes_id" name="sub_dishes" value="<?php echo $sub_dishes_id; ?>">
                                                </div>
                                            </div>
                                            </div> <?php
                                            
                                        }
                                        ?><div align="center"> <?php 
                                          $num_rec_per_page=10;
                                          $total_pages = ceil($total_records / $num_rec_per_page);
                                          if(isset($_GET['page']))
                                          {
                                                $page=$_GET['page'];
                                                if($page==$total_pages)
                                                {
                                                    $start=$page-2;
                                                    $end=$page;
                                                }
                                                elseif($page==$total_pages-1)
                                                {
                                                    $start=$page-2;
                                                    $end=$page+1;    
                                                }
                                                elseif($page==1)
                                                {
                                                    $start=1;
                                                    $end=$page+2;
                                                }
                                                elseif($page==2)
                                                {
                                                    $start=$page-1;
                                                    $end=$page+2;
                                                }
                                                else
                                                {
                                                    $start=$page-2;
                                                    $end=$page+2;
                                                }
                                          }
                                          else
                                          {
                                                $page=1;
                                                $start=1;
                                                $end=$page+2;
                                          }
                                            echo "<a href='menu.php?page=1'>".'<< first'."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
                                            $j=1;  
                                            for ($i=$start; $i<=$end; $i++) 
                                            { 
                                                
                                                if($i==$_GET['page'] || ($j==1 && !isset($_GET['page'])))
                                                {
                                                    echo "&nbsp;&nbsp;<a style='color:red;' href='menu.php?page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                                                }
                                                else
                                                {
                                                    echo "&nbsp;&nbsp;<a href='menu.php?page=".$i."'> ".$i."</a> &nbsp;&nbsp;"; 
                                                
                                                }
                                                $j++;
                                            };
                                            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='menu.php?page=$total_pages'>".'last >>'."</a> ";  
                                            ?></div><?php 
                                    }
                                    else
                                    {?>
                                        <div class="smi-heading">
                                           <h3 style="color:red;">No Dish is available this time.... Please choose other... </h3>
                                        </div> <?php      
                                    }
                                } ?>                          
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!--Blog End -->
    
    <!--Footer Start-->
    <?php include_once("footer.php"); ?>
    <!--Footer Start-->
     
    
        <!-- all js here -->
        <!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
        <!-- datepicker js -->
        <script src="js/bootstrap-datepicker.js"></script>
        <!-- timepicker js -->
        <script src="js/jquery.timepicker.min.js"></script>
        <!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
        <!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
        <!-- nivo.slider js -->
        <script src="lib/js/jquery.nivo.slider.pack.js"></script>
        <script src="lib/js/nivo-active.js"></script>
        <!-- wow js -->
        <script src="js/wow.min.js"></script>
        <!-- Sticky JS -->  
        <script src="js/jquery.sticky.js"></script>
        <!-- venobox js -->
        <script src="lib/venobox/venobox.js"></script>
        <!-- Scroll up js -->
        <script src="js/jquery.scrollUp.min.js"></script>
        <!-- google map  js -->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuU_0_uLMnFM-2oWod_fzC0atPZj7dHlU"></script>
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script>
            function initialize() {
                var mapOptions = {
                    zoom: 15,
                    scrollwheel: false,
                    center: new google.maps.LatLng(23.81033, 90.41252)
                };
                var map = new google.maps.Map(document.getElementById('googleMap'),
                    mapOptions);
                var marker = new google.maps.Marker({
                    position: map.getCenter(),
                    animation: google.maps.Animation.BOUNCE,
                    icon: 'img/map-marker.png',
                    map: map
                });
            }
            google.maps.event.addDomListener(window, 'load', initialize);
        </script>
        <!-- plugins js -->
        <script src="js/plugins.js"></script>
        <!-- main js -->
        <script src="js/main.js"></script>
        
        
        <script src="Food_Mania_Admin/production/jquery-3.1.1.min.js"></script>
        <script>
		$(document).ready(function(){
			$(".add_dishes").click(function(){
				var confirm_message=confirm("Do you want to sure add this dish into cart.....?");
				if(confirm_message==true)
				{
					var sub_dishes_id=$(this).parent().parent().find(".sub_dishes_id").val();

					$.ajax({
						url : "add_dishes_in_cart.php", 
						type: "POST",
						data: { "id" : sub_dishes_id },
						success: function(data){ 
							if(data=="no_login")
							{
								// alert("Please Do Login in Website");
                                window.location.href = "registration.php?mm=no_login";
							}
							else if(data=="dish_is_already_added")
							{
								alert("This Dish is Already Add in Cart");
							}
							else if(data=="cart_is_full")
							{
								alert("Your Cart is Full so You can not add More Dish in Cart");
							}
							else if(data=="dish_add_in_cart")
							{
								alert("Dish is Added in Cart");
							}
							else
							{
								alert("Please Check Your Connection");
							}
							//error: function(data){alert(data);
						}
					});
				}
			});
			
			
		});
        </script>
		<script src="Food_Mania_Admin/production/jquery-3.1.1.min.js"></script>
        <script>
			
		
		</script>
		
		
		
		
    </body>

<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:50:52 GMT -->
</html>
