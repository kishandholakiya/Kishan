<?php
session_start(); 
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();


//check session is set or not
if(isset($_SESSION['customer']))
{
    header("Location:index.php");
}


//check that session is already register or not....
if(isset($_SESSION['customer_id']) && isset($_SESSION['customer_name']) && isset($_SESSION['cno']) && isset($_SESSION['email']))
{
    header("Location:forget_pass_2.php");
}



//check/ user information form table tbl_register &check iser is valid  or not
if(isset($_POST['btn_reg']))
{
    //chceck register user informatiion
    $tmp="check_forget";
    $id=$address=$gender=$ip_address="";
    $res=$con->iuds_tbl_register($tmp,$id,$_POST['fname'],$_POST['lname'],$address,$gender,$_POST['bod'],$_POST['contact'],$_POST['user_email'],$pass,$ip_address);
    
	$name=$_POST['fname']." ".$_POST['lname'];
	
	if(is_numeric($res))
	{
		$_SESSION['customer_id']=$res;
		$_SESSION['customer_name']=$name;
		$_SESSION['cno']=$_POST['contact'];
        $_SESSION['email']=$_POST['user_email'];
		header("Location:send_otp.php");
	}
	else
	{
		if($res=="true2")
			header("location:forget_pass.php?n=block");
		else
			header("Location:forget_pass.php?n=no_valid");
	}
	
                
}

if(isset($_POST['up_passwd']))
{
  if($_SESSION['otp_num']==$_POST['otp_num'])
  {
    $query="UPDATE tbl_register SET register_ip_address='".$_SERVER['REMOTE_ADDR']."' register_passwd='".$_POST['new_passwd']."', register_modify_date='".date("Y/m/d H:i:s")."'  WHERE register_id=".$_SESSION['customer_id'];
    mysql_query($query);
    header("Location:registration.php?mm=change_pass");
  }
  else
  {
    header("Location:forget_pass.php?notic=opt_wrong");
  }
  
}
?>


<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:44:19 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Food Mania</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->
        
        <!--All Google Fonts-->
        <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

        <!-- all css here -->
        <!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- jquery-ui.min css -->
        <link rel="stylesheet" href="css/jquery-ui.min.css">
        <!-- meanmenu css -->
        <link rel="stylesheet" href="css/meanmenu.min.css">
        <!-- owl.carousel css -->
        <link rel="stylesheet" href="css/owl.carousel.css">
        <!-- font-awesome css -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- datepicker css -->
        <link rel="stylesheet" href="css/bootstrap-datepicker.css">
        <!-- timepicker css -->
        <link rel="stylesheet" href="css/jquery.timepicker.css">
        <!-- nivo-slider css -->
        <link rel="stylesheet" href="lib/css/nivo-slider.css">
        <!-- venobox css -->
        <link rel="stylesheet" href="lib/venobox/venobox.css">
        <!-- style css -->
        <link rel="stylesheet" href="style.css">
        <!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
        <!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
       
    </head>
    <body>
    
    <!-- Header Start -->
       <?php include_once("header.php"); ?>
    <!-- Header End -->
	
    
	
	
    
    <!-- Page Name Start -->
	<div class="page_name" style="">
		<h1><i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Forget In</h1>
	</div>   

    <!-- Page Content Start -->
    <div class="cart-area pt60 pb60 ">
        <div class="container">
            <div class="row">
            <div class="section-title text-center ">
                <h4><a href="registration.php">Back To Chack In Page</a></h4>
            </div><br><br>

            <div class="col-md-2 col-sm-1">
            </div>
            <div class="col-md-8 col-sm-10 col-xs-12">
                <div class="billing-details">
                    <div class="contact-text right-side">
						<div class="row" align="center">
				<?php 
                        if(isset($_GET['n']))
                        { 
                            if($_GET['n']=="block")
                            { ?>
                              <h3 class="text-danger" style="border-bottom:thick;">Our Accout is Blocked By Admin</h3><br>  <?php 
                            } 
                            elseif(isset($_GET['n'])=="no_valid")
                            {?>
                                 <h3 class="text-danger" style="border-bottom:thick;">Please Enter Valid Information</h3><br> <?php
                            }
                        }
						
						if(isset($_GET['notic']))
                        { 
                            if($_GET['notic']=="msg_send")
                            { ?>
                              <h3 class="text-success" style="border-bottom:thick;">Your OTP send in Your number</h3><br><?php
                            }
                            elseif($_GET['notic']=="opt_wrong")
                            { ?>
                              <h3 class="text-danger" style="border-bottom:thick;">Your OTP Number is wrong. So Password is not Change. <br>Please Enter Write OTP number </h3><br><?php
                            } 
                            elseif(isset($_GET['notic'])=="connection_error")
                            {?>
                                 <h3 class="text-danger" style="border-bottom:thick;">Please Check Your Connection</h3><br> <?php
                            }
                        } ?>
						</div>
				
				
				
				<form method="post">
                   <div class="first-last-name">
                        <div class="input-box name1">
                            <label>First Name *</label>
                            <input type="text" name="fname" id="fname" class="info" placeholder="First Name" required pattern="([a-zA-Z][a-zA-Z0-9\s]*){1,30}">
                        </div>
                        <div class="input-box name2">
                            <label>Last Name *</label>
                            <input type="text" name="lname" id="lname" class="info" placeholder="Last Name" required pattern="([a-zA-Z][a-zA-Z0-9\s]*){1,30}">
                        </div>
                   </div>


                   <div class="input-box">
                    <?php    //select min date
                    $date=new DateTime(date("Y-m-d"));
                    $date->modify('-60 year');
                    $min_date=$date->format('Y-m-d');
                    
                    //select max date
                    $date=new DateTime(date("Y-m-d"));
                    $date->modify('-15 year');
                    $max_date=$date->format('Y-m-d');                    
                    ?>
                    <div class="input-box">
                        <label>Birth Date *</label>
                        <input type="date" name="bod" class="info" required min="<?php echo $min_date; ?>" max="<?php echo $max_date; ?>" title="Birthdate is must higher then 18 year & Lower then 60 year">
                    
                    </div>


                    <div class="row">
                        <label style="text-align:center;">Select any one Option</label><br>
                        <div class="col-sm-2 col-xs-2">
                            <input type="radio" name="select_option" id="select_option_1" required  >
                        </div>

                        <div class="col-sm-10 col-xs-10">
                            <div class="input-box">
                                <label>Phone Number *</label>
                                <input type="text" name="contact" id="contact" class="info" placeholder="Phone Number" required pattern="[0-9]{10,13}">
                            </div>        
                        </div>
                        

                        <div class="col-sm-2 col-xs-2">
                            <input type="radio" name="select_option" id="select_option_2" required>
                        </div>

                        <div class="col-sm-10 col-xs-10">
                            <div class="input-box">
                                <label>Email Address *</label>
                                <input type="email" name="user_email" id="user_email" class="info" placeholder="Your Email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="input-box pt20 mt20">
                        <input type="submit" class="in-btn" name="btn_reg" id="btn_reg" value="Check Customer Details">
                    </div> 

                </form>
				
                </div>
            </div>
        </div>
    </div>
    </div>
    </div><br><br>
    
    <!--Page Content Start-->
    
    <!-- Footer Start-->
    <?php include_once("footer.php"); ?>
    <!--Footer Start-->
     
    
     
    
        <!-- all js here -->
        <!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
        <!-- datepicker js -->
        <script src="js/bootstrap-datepicker.js"></script>
        <!-- timepicker js -->
        <script src="js/jquery.timepicker.min.js"></script>
        <!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
        <!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
        <!-- nivo.slider js -->
        <script src="lib/js/jquery.nivo.slider.pack.js"></script>
        <script src="lib/js/nivo-active.js"></script>
        <!-- wow js -->
        <script src="js/wow.min.js"></script>
        <!-- Sticky JS -->  
        <script src="js/jquery.sticky.js"></script>
        <!-- venobox js -->
        <script src="lib/venobox/venobox.js"></script>
        <!-- Scroll up js -->
        <script src="js/jquery.scrollUp.min.js"></script>
        <!-- google map  js -->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuU_0_uLMnFM-2oWod_fzC0atPZj7dHlU"></script>
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script>
            function initialize() {
                var mapOptions = {
                    zoom: 15,
                    scrollwheel: false,
                    center: new google.maps.LatLng(23.81033, 90.41252)
                };
                var map = new google.maps.Map(document.getElementById('googleMap'),
                    mapOptions);
                var marker = new google.maps.Marker({
                    position: map.getCenter(),
                    animation: google.maps.Animation.BOUNCE,
                    icon: 'img/map-marker.png',
                    map: map
                });
            }
            google.maps.event.addDomListener(window, 'load', initialize);
        </script>
        <!-- plugins js -->
        <script src="js/plugins.js"></script>
        <!-- main js -->
        <script src="js/main.js"></script>



<!-- send message again start -->
<script type="text/javascript">
function send_msg_again()
{
    var a=confirm("Are you want to sure for Send OTP code again.....?")
}
</script>

<!-- send message again End -->

<script src="Food_Mania_Admin/production/jquery-3.1.1.min.js"></script>
<script>
$(document).ready(function(){

    $("#contact").attr("disabled","disabled");
    $("#contact").css("cursor","not-allowed");
    $("#user_email").attr("disabled","disabled");
    $("#user_email").css("cursor","not-allowed");


    $("#select_option_1").change(function(){
        $("#contact").removeAttr("disabled","disabled");
        $("#contact").css("cursor","text");
        $("#user_email").attr("disabled","disabled");
        $("#user_email").css("cursor","not-allowed");
    });
    $("#select_option_2").change(function(){
        $("#user_email").removeAttr("disabled","disabled");
        $("#user_email").css("cursor","text");
        $("#contact").attr("disabled","disabled");
        $("#contact").css("cursor","not-allowed");
    });
});
</script>




    </body>

<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:50:52 GMT -->
</html>
