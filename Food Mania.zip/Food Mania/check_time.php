<?php 
include_once("food_mania_admin/production/connection.php");

$con2 = new connection();
$con2->connect();

                    //check that customer is gave order on restaurant or not 
					$time=mysql_fetch_array($con2->select_admin());
					$day=date('l');
					$this_time=date("H:i:s");
					
					
					if($day!="sunday")
					{
						if($time['food_mania_op_mon_sat'] >= $this_time || $time['food_mania_cl_mon_sat'] <= $this_time)
						{ ?>
							<div align="center" class="restaurant_close">
								<h3 class="text-danger" style="border-bottom:thick;">Restaurant is Close</h3><br>
								<input type="hidden" id="time_set" name="time_set" value="1"><br>
							</div> <?php
						}
					}
					elseif($day=="sunday")
					{
						if($time['food_mania_op_mon_sat'] >= $this_time || $time['food_mania_cl_mon_sat'] <= $this_time)
						{ ?>
							<div align="center" class="restaurant_close">
								<h3 class="text-danger" style="border-bottom:thick;">Restaurant is Close</h3><br> 
								<input type="hidden" id="time_set" name="time_set" value="1"><br>
								</div> <?php 
						}
					} ?>
			   
			   
			   
	   
