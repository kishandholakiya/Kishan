<?php
session_start();
error_reporting(E_ALL);
ob_implicit_flush(true);

include_once "class.curl.php";
include_once "class.sms.php";
include_once "cprint.php";


$smsapp=new sms();
$smsapp->setGateway('way2sms');



if(isset($_GET['notic']))
{
	if($_GET['notic']=="order_accepted")
	{
		$message="Thank you ".$_SESSION['customer_name']." for given Order. \nWe are provide our Best Service. \n \nSend By :- Food Mania";
		$myno="7990902544";
		$p="1234567890";
		$tonum=$_SESSION['cno'];
		$mess=$message;
		$ret=$smsapp->login($myno,$p);

		if (!$ret) {
		   header("Location:../cart.php?notic=thank");
		   return;
		}
		$ret=$smsapp->send($tonum,$mess);

		if (!$ret) {
		   header("Location:../cart.php?notic=thank");
		   return;
		}
		header("Location:../cart.php?notic=thank");

	}
	elseif($_GET['notic']=="order_cancle")
	{
		$message="Thank you ".$_SESSION['customer_name']." for Connect with Us. \n We have Cancelled Your Advance Order. We hope You will give order Again. \n \nSend By :- Food Mania";
		$myno="7990902544";
		$p="1234567890";
		$tonum=$_SESSION['cno'];
		$mess=$message;
		$ret=$smsapp->login($myno,$p);

		if (!$ret) {
		   header("Location:../cart.php?notic=order_cancle");
		   return;
		}
		$ret=$smsapp->send($tonum,$mess);

		if (!$ret) {
		   header("Location:../cart.php?notic=order_cancle");
		   return;
		}
		header("Location:../cart.php?notic=order_cancle");

	}
	elseif($_GET['notic']=="thank_paypal")
	{
		$message="Thank you ".$_SESSION['customer_name']." for given Order. \nAnd also Thank you for give payment. \nWe are provide our Best Service.  \n \nSend By :- Food Mania";
		$myno="7990902544";
		$p="1234567890";
		$tonum=$_SESSION['cno'];
		$mess=$message;
		$order_id=$_GET['order_id'];
		$ret=$smsapp->login($myno,$p);

		if (!$ret) {
		   header("Location:../cart.php?paypal=paypal_successfull&order_id=$order_id&notic=thank");
		   return;
		}
		$ret=$smsapp->send($tonum,$mess);

		if (!$ret) {
		   header("Location:../cart.php?paypal=paypal_successfull&order_id=$order_id&notic=thank");
		   return;
		}
		header("Location:../cart.php?paypal=paypal_successfull&order_id=$order_id&notic=thank");

	}
}
else
{
	$message="Thank you ".$_SESSION['customer_name']." for connect with us. \nYour OTP code is hear. \n". $_SESSION['otp_num']." \n \nSend By :- Food Mania";
	$myno="7990902544";
	$p="1234567890";
	$tonum=$_SESSION['cno'];
	$mess=$message;
	$ret=$smsapp->login($myno,$p);

	if (!$ret) {
	   header("Location:../forget_pass.php?notic=connection_error");
	   return;
	}


	$ret=$smsapp->send($tonum,$mess);

	if (!$ret) {
	   header("Location:../forget_pass.php?notic=connection_error");
	   return;
	}

	header("Location:../forget_pass_2.php?notic=msg_send");


	}




?>