<?php 
session_start();
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();


if(isset($_POST['btn_submit']))
{
    if(!isset($_SESSION['customer']))
    {
        header("Location:registration.php?mm=no_login");    
    }
    else
    {
        $register_id=$_SESSION['customer'];
        $tmp="insert";
        $res=$con->send_feedback($tmp,$register_id,$_POST['message']);
        if($res==true)
          header("Location:feedback.php?mm=1");
        else
           header("Location:feedback.php?mm=2");
    }
}



?>



<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/contact.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:56:53 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>food mania</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->
        
        <!--All Google Fonts-->
        <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

		<!-- all css here -->
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="css/owl.carousel.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- datepicker css -->
        <link rel="stylesheet" href="css/bootstrap-datepicker.css">
		<!-- timepicker css -->
        <link rel="stylesheet" href="css/jquery.timepicker.css">
        <!-- nivo-slider css -->
        <link rel="stylesheet" href="lib/css/nivo-slider.css">
        <!-- venobox css -->
        <link rel="stylesheet" href="lib/venobox/venobox.css">
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
		<!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <div class="contact-wraper">
    
      <!--header slider area are start-->
     <?php include_once("header.php"); ?>
     <!-- Home slider is end -->
     
     <!-- Page Name Start -->
	 	<div class="page_name" style="">
			<h1><i class="fa fa-comments" aria-hidden="true"></i>&nbsp;FeedBack</h1>
		</div>   

	 <!-- Page Name End -->



    <!--contact area area start-->
    <div class="contact-area pt60 pb150">
        <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-sm-12">
                        <div class="contact-text right-side">
                            <h2>Give Your FeedBack</h2>
                            <?php 
                            if(!isset($_SESSION['customer']))
                            { ?>
                                <h4 class="text-danger" style="border-bottom:thick;">PLEASE DO LOGIN IN WEBSITE </h4><br> <?php 
                            } 
                            if(isset($_GET['mm']))
                            {
                                if($_GET['mm']=="1") 
                                { ?>
                                    <h3 class="text-danger" style="border-bottom:thick;">Thank You for Give FeedBack</h3><br> <?php 
                                }
                                elseif($_GET['mm']=="2") 
                                { ?>
                                    <h3 class="text-danger" style="border-bottom:thick;">Please Check your Connection</h3><br> <?php 
                                }
                            } ?>
                            <form method="post">
                              
                                <div class="input-box">
                                    <label><i class="fa fa-comments" aria-hidden="true"></i>Message</label>
                                    <textarea name="message" class="area-tex info" placeholder="Your Message" required pattern="([a-zA-Z][a-zA-Z0-9\s]*)"  title="only Space not allow">
                                    </textarea>
                                </div>
                                <div class="input-box submt">
								 <input type="submit" class="com-btn blg-btn" name="btn_submit" id="btn_submit" value="Send ">
                                </div>
                            </form>
                          </div>
                      </div>
                </div>
        </div>
    </div>
    <!--contact area are end-->
      
    <!--footer area are start-->
      <?php include_once("footer.php"); ?>
    <!--footer area are end-->
</div>
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
		<!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
		<!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
		<!-- datepicker js -->
        <script src="js/bootstrap-datepicker.js"></script>
		<!-- timepicker js -->
        <script src="js/jquery.timepicker.min.js"></script>
		<!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
		<!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
        <!-- nivo.slider js -->
        <script src="lib/js/jquery.nivo.slider.pack.js"></script>
        <script src="lib/js/nivo-active.js"></script>
		<!-- wow js -->
        <script src="js/wow.min.js"></script>
		<!-- Sticky JS -->	
        <script src="js/jquery.sticky.js"></script>
		<!-- venobox js -->
        <script src="lib/venobox/venobox.js"></script>
		<!-- google map  js -->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuU_0_uLMnFM-2oWod_fzC0atPZj7dHlU"></script>
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script>
            function initialize() {
                var mapOptions = {
                    zoom: 15,
                    scrollwheel: false,
                    center: new google.maps.LatLng(23.81033, 90.41252)
                };
                var map = new google.maps.Map(document.getElementById('googleMap'),
                    mapOptions);
                var marker = new google.maps.Marker({
                    position: map.getCenter(),
                    animation: google.maps.Animation.BOUNCE,
                    icon: 'img/map-marker.png',
                    map: map
                });
            }
            google.maps.event.addDomListener(window, 'load', initialize);
        </script>
		<!-- plugins js -->
        <script src="js/plugins.js"></script>
		<!-- main js -->
        <script src="js/main.js"></script>


    </body>

<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/contact.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:56:54 GMT -->
</html>
