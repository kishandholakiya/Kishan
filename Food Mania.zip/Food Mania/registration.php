<?php
session_start(); 
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();


//check session is set or not
if(isset($_SESSION['customer']))
{
    header("Location:index.php");
}

unset($_SESSION['customer_id']);
unset($_SESSION['customer_name']);
unset($_SESSION['cno']);
unset($_SESSION['email']);
unset($_SESSION['otp_num']);
       


//check/ user information form table tbl_register &check iser is valid  or not
if(isset($_POST['btn_login']))
{
    //check user information for login
    $tmp="check_user";
    $id=$fname=$lname=$address=$gender=$bod=$contact=$ip_address="";
    $res=$con->iuds_tbl_register($tmp,$id,$fname,$lname,$address,$gender,$bod,$contact,$_POST['user_email'],$_POST['user_passwd'],$ip_address);
    if($res=="true1")
    {  
        $tmp="user_is_online";  
        $id=$fname=$lname=$address=$gender=$bod=$contact=$ip_address="";
        $_SESSION['customer']=$con->iuds_tbl_register($tmp,$id,$fname,$lname,$address,$gender,$bod,$contact,$_POST['user_email'],$_POST['user_passwd'],$ip_address);
        
        header("Location:menu.php");
    }
    elseif($res=="true2")
       header("Location:registration.php?n=block");
    elseif($res=="false")
        header("Location:registration.php?n=no_valid");
}
elseif(isset($_POST['btn_reg']))
{
    //chceck register user informatiion
    $tmp="insert";
    $register_id="";
	$address=$_POST['address'].", ".$_POST['address2'];
    $ans=$con->iuds_tbl_register($tmp,$id,$_POST['fname'],$_POST['lname'],$address,$_POST['gender'],$_POST['bod'],$_POST['contact'],$_POST['user_email'],$_POST['user_passwd'],$_SERVER['REMOTE_ADDR']);
    if($ans==true)
    {
        $tmp="user_is_online";  
        $id=$fname=$lname=$address=$gender=$bod=$contact=$ip_address="";
        $_SESSION['customer']=$con->iuds_tbl_register($tmp,$id,$fname,$lname,$address,$gender,$bod,$contact,$_POST['user_email'],$_POST['user_passwd'],$ip_address);
        header("Location:menu.php"); 
    }
    else
    {     
       header("location:registration.php?n=2");
    }
                
}
?>


<!doctype html>
<html class="no-js" lang="">
    
<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:44:19 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Food Mania</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->
        
        <!--All Google Fonts-->
        <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>

        <!-- all css here -->
        <!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- jquery-ui.min css -->
        <link rel="stylesheet" href="css/jquery-ui.min.css">
        <!-- meanmenu css -->
        <link rel="stylesheet" href="css/meanmenu.min.css">
        <!-- owl.carousel css -->
        <link rel="stylesheet" href="css/owl.carousel.css">
        <!-- font-awesome css -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- datepicker css -->
        <link rel="stylesheet" href="css/bootstrap-datepicker.css">
        <!-- timepicker css -->
        <link rel="stylesheet" href="css/jquery.timepicker.css">
        <!-- nivo-slider css -->
        <link rel="stylesheet" href="lib/css/nivo-slider.css">
        <!-- venobox css -->
        <link rel="stylesheet" href="lib/venobox/venobox.css">
        <!-- style css -->
        <link rel="stylesheet" href="style.css">
        <!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
        <!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
       
    </head>
    <body>
    
    <!-- Header Start -->
       <?php include_once("header.php"); ?>
    <!-- Header End -->
    
	
	<!-- Page Name Start -->
	<div class="page_name" style="">
		<h1><i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Check In</h1>
	</div>   

    <!-- Page Name End -->
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-1">
            </div>
            
            <div class="col-sm-10 col-md-8 col-xs-12" >
                <form name="form" method="post" class="login-side">
              <div class="login-reg">
              <?php 
                        if(isset($_GET['mm']))
                        {
                            if($_GET['mm']=="logout_customer") 
                            { ?>
                                <h3 class="text-danger" style="border-bottom:thick;">Customer is Logout</h3><br> <?php 
                            }
                            elseif($_GET['mm']=="no_login") 
                            { ?>
                                <h3 class="text-danger" style="border-bottom:thick;">Please do Login in Website</h3><br> <?php 
                            }
                            elseif($_GET['mm']=="change_pass") 
                            { ?>
                                <h3 class="text-success" style="border-bottom:thick;">Now  You can Login with New Password</h3><br> <?php 
                            }
                        }
						if(isset($_GET['n']))
                        { 
                            if($_GET['n']=="block")
                            { ?>
                              <h3 class="text-danger" style="border-bottom:thick;">Our Accout is Blocked By Admin</h3><br>  <?php 
                            } 
                            elseif(isset($_GET['n'])=="no_valid")
                            {?>
                                 <h3 class="text-danger" style="border-bottom:thick;">Please Enter Valid User Name & Password</h3><br> <?php
                            }
                        }?>
                <h3>Login</h3>
                <div class="form-group">
                    <label class="control-label">E-Mail *</label>
                    <input type="email" class="form-control" placeholder="E-Mail" name="user_email" required pattern="[a-z]+[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Ex:-abc@gmail.com">
                </div>
                <div class="form-group">
                    <label class="control-label">Password *</label>
                    <input type="password" class="form-control" placeholder="Password"  name="user_passwd" required pattern=".{8,30}" title="Password length is must Between 8 to 30 ">
                </div>
                </div>
                <div class="frm-action">
                    <div class="input-box tci-box">
                      <input type="submit" value="Login" name="btn_login" class="in-btn">
                   </div>
                 <a href="forget_pass.php" class="forgotten forg">Forget Password</a>
                </div>
                </form>
            </div>
            <div class="col-md-2 col-sm-1">
            </div>
            
        </div>
    </div>
    <!-- Page Content Start -->
    <div class="cart-area pt60 pb60 ">
        <div class="container">
            <div class="row">
            <div class="col-md-2 col-sm-1">
            </div>
            <div class="col-md-8 col-sm-10 col-xs-12">
                <div class="billing-details">
                    <div class="contact-text right-side">
                          <h2>Registration Form</h2>
                <form method="post">
                   <div class="first-last-name">
                        <div class="input-box name1">
                            <label>First Name *</label>
                            <input type="text" name="fname" id="fname" class="info" placeholder="First Name" required pattern="([a-zA-Z][a-zA-Z\s]*){1,30}" title="Last Name is not Contain Number And only Space">
                        </div>
                        <div class="input-box name2">
                            <label>Last Name *</label>
                            <input type="text" name="lname" id="lname" class="info" placeholder="Last Name" required pattern="([a-zA-Z][a-zA-Z\s]*){1,30}" title="Last Name is not Contain Number And only Space">
                        </div>
                   </div>
                   
                    <div class="input-box">
                        <label>Address *</label>
                        <input type="text" name="address" id="address" class="info" placeholder="Street Address" required pattern="([0-9a-zA-Z][a-zA-Z0-9\s,./-]*){1,150}" title="Street Address 's Maximun Length is 150. only space not allow">
                    </div>
                    
                    <div class="input-box">
                        <input type="text" name="address2" id="address2" class="info" placeholder="Area Name" required pattern="([a-zA-Z][a-zA-Z\s,.]*){1,50}" title="Area Address 's Maximun Length is 50 only space not allow">
                    </div>
                    

                    <div class="input-box">
                        <label style="text-align:left;">Gender *</label>
                        <div class="row input-box" >
                            <div class="col-sm-1 col-xs-2 col-md-1 col-lg-1">
                                <label style="text-align:left;">Male</label>
                            </div>
                            <div class="col-sm-1 col-xs-2 col-md-1 col-lg-1 ">
                                <input type="radio" name="gender" class="info" value="Male" checked required>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                            </div>
                            <div class="col-sm-1 col-xs-2 col-md-1 col-lg-1" style="float:left;">
                                <label style="text-align:left;">Female</label>
                            </div>
                            <div class="col-sm-1 col-xs-2 col-md-1 col-lg-1">
                                <input type="radio" name="gender" class="info" value="Female" required>
                            </div>
                        </div>
                    </div>
                    


                    <?php 
                    //select min date
                    $date=new DateTime(date("Y-m-d"));
                    $date->modify('-60 year');
                    $min_date=$date->format('Y-m-d');
                    
                    //select max date
                    $date=new DateTime(date("Y-m-d"));
                    $date->modify('-15 year');
                    $max_date=$date->format('Y-m-d');                    
                    ?>
                    <div class="input-box">
                        <label>Birth Date *</label>
                        <input type="date" name="bod" class="info" required min="<?php echo $min_date; ?>" max="<?php echo $max_date; ?>" title="Birthdate is must higher then 18 year & Lower then 60 year">
                    </div>

                    <div class="input-box">
                        <label>Phone Number *</label>
                        <input type="text" name="contact" class="info" placeholder="Phone Number" required pattern="[0-9]{10}" title="Only Number are Use">
                    </div>

                    <div class="input-box">
                        <label>Email Address *</label>
                        <input type="email" name="user_email" class="info" placeholder="Your Email" required pattern="[a-z]+[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="Ex:- abc@gmail.com">
                    </div>
                
                    <div class="input-box">
                        <label>Account password *</label>
                        <input type="password" name="user_passwd" class="info" placeholder="Password" required pattern=".{8,30}" title="Password length is must Between 8 to 30 ">
                    </div>
                    
                    <div class="input-box pt20 mt20">
                        <input type="submit" class="in-btn" name="btn_reg" id="btn_reg" value="Register Your Account">
                    </div> 

                </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div><br><br>
    
    <!--Page Content End-->
    


    <!-- Footer Start -->
    <?php include_once("footer.php"); ?>
    <!--Footer End-->
     
    
     
    
        <!-- all js here -->
        <!-- jquery latest version -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="js/owl.carousel.min.js"></script>
        <!-- datepicker js -->
        <script src="js/bootstrap-datepicker.js"></script>
        <!-- timepicker js -->
        <script src="js/jquery.timepicker.min.js"></script>
        <!-- meanmenu js -->
        <script src="js/jquery.meanmenu.js"></script>
        <!-- jquery-ui js -->
        <script src="js/jquery-ui.min.js"></script>
        <!-- nivo.slider js -->
        <script src="lib/js/jquery.nivo.slider.pack.js"></script>
        <script src="lib/js/nivo-active.js"></script>
        <!-- wow js -->
        <script src="js/wow.min.js"></script>
        <!-- Sticky JS -->  
        <script src="js/jquery.sticky.js"></script>
        <!-- venobox js -->
        <script src="lib/venobox/venobox.js"></script>
        <!-- Scroll up js -->
        <script src="js/jquery.scrollUp.min.js"></script>
        <!-- google map  js -->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuU_0_uLMnFM-2oWod_fzC0atPZj7dHlU"></script>
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script>
            function initialize() {
                var mapOptions = {
                    zoom: 15,
                    scrollwheel: false,
                    center: new google.maps.LatLng(23.81033, 90.41252)
                };
                var map = new google.maps.Map(document.getElementById('googleMap'),
                    mapOptions);
                var marker = new google.maps.Marker({
                    position: map.getCenter(),
                    animation: google.maps.Animation.BOUNCE,
                    icon: 'img/map-marker.png',
                    map: map
                });
            }
            google.maps.event.addDomListener(window, 'load', initialize);
        </script>
        <!-- plugins js -->
        <script src="js/plugins.js"></script>
        <!-- main js -->
        <script src="js/main.js"></script>
		
    </body>

<!-- Mirrored from demo.designshopify.com/html_lavie/lavie_resturant/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 05 Feb 2017 03:50:52 GMT -->
</html>
