<?php

class client_connection
{	

  	public function client_connect()
	{
       $con=mysql_connect("localhost","root","") or die("connection is not open");
       	mysql_select_db("db_foodmania",$con);
	}
	
	
	// Select admin Information & Select all this site information
	public function select_all_data($tmp,$main_dishes_name)
	{
		//show admin information
		if($tmp=="select_tbl_admin")
		{
			$select_admin="SELECT * FROM tbl_admin";
			$res=mysql_query($select_admin);
			return $res;
		}
		//show main dishes from table tbl_main_dishes
		elseif($tmp=="select_tbl_main_dishes")
		{
			$query="SELECT * FROM tbl_main_dishes WHERE main_dishes_is_status='1' ORDER BY(main_dishes_name)";
			$res=mysql_query($query);
			if($res==true)
				return $res;
			else
				return false;
		}
		//select all sub dishes
		elseif($tmp=="select_sub_dishes")
		{
			$num_rec_per_page=10;
			if(isset($_GET['page']))
			{
				$page  = $_GET["page"];
				$start_from = ($page-1) * $num_rec_per_page; 
				$query="SELECT * FROM tbl_sub_dishes WHERE sub_dishes_is_status='1' ORDER BY(sub_dishes_name) LIMIT $start_from,$num_rec_per_page";
				$res=mysql_query($query);
				if($res==true)
					return $res;
				else
					return false;
				
			}
			else
			{
				$start_from = (0) * $num_rec_per_page;
				$query="SELECT * FROM tbl_sub_dishes WHERE sub_dishes_is_status='1' ORDER BY(sub_dishes_name) LIMIT $start_from,$num_rec_per_page";
				$res=mysql_query($query);
				if($res==true)
					return $res;
				else
					return false; 
			}
		}
		
		//show  all information of sub dishes from main dishes name
		elseif($tmp=="sub_dishes_show_from_main_dishes")
		{
			$q = "SELECT COUNT(sub_dishes_id) FROM tbl_sub_dishes WHERE sub_dishes_is_status='1' AND
						main_dishes_id=
					(SELECT main_dishes_id 
						FROM tbl_main_dishes 
					WHERE 
			 			main_dishes_name='".$_GET['name']."')"; 
			$r=mysql_query($q);
			$a=mysql_fetch_array($r);
			
			if($a[0]>=10)
				$num_rec_per_page=10;
			else
			{
				$num_rec_per_page=$a[0];
			}
			
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"];
				$start_from = ($page-1) * $num_rec_per_page; 
				$query = "SELECT * FROM tbl_sub_dishes WHERE sub_dishes_is_status='1' AND
						main_dishes_id=
					(SELECT main_dishes_id 
						FROM tbl_main_dishes 
					WHERE 
			 			main_dishes_name='".$_GET['name']."') 
			 			ORDER BY(sub_dishes_name) LIMIT $start_from, $num_rec_per_page "; 
				if($res = mysql_query ($query))
					return $res;
			  	else
					return false; 
			} 
			else 
			{ 
				$start_from = 0;
				$query = "SELECT * FROM tbl_sub_dishes WHERE sub_dishes_is_status='1' AND
						main_dishes_id=
					(SELECT main_dishes_id 
						FROM tbl_main_dishes 
					WHERE 
			 			main_dishes_name='".$_GET['name']."') 
			 			ORDER BY(sub_dishes_name) LIMIT $start_from, $num_rec_per_page "; 
				if($res = mysql_query ($query))
					return $res;
			  	else
					return false; 
			} 
			
		}
		//search sub dishes search button
		elseif($tmp=="select_sub_dishes_from_search")
		{
			$search=$main_dishes_name;
			$q="SELECT COUNT(sub_dishes_id) FROM tbl_sub_dishes WHERE sub_dishes_name LIKE '%{$search}%' && sub_dishes_is_status='1'";
			$r=mysql_query($q);
			$a=mysql_fetch_array($r);
			
			if($a[0]>=10)
				$num_rec_per_page=10;
			else
				$num_rec_per_page=$a[0];
			
			if(isset($_GET['page']))
			{
				$page  = $_GET['page'];
				$start_from = ($page-1) * $num_rec_per_page; 
				$query="SELECT * FROM tbl_sub_dishes WHERE  sub_dishes_is_status='1' && sub_dishes_name LIKE '%{$search}%' ORDER BY(sub_dishes_name) LIMIT $start_from, $num_rec_per_page";
				$res=mysql_query($query);
				if($res==true)
					return $res;
				else
					return false;	
			}
			else				
			{
				$start_from = (0) * $num_rec_per_page;
				$query="SELECT * FROM tbl_sub_dishes WHERE  sub_dishes_is_status='1' && sub_dishes_name LIKE '%{$search}%' ORDER BY(sub_dishes_name) LIMIT $start_from, $num_rec_per_page";
				$res=mysql_query($query);
				if($res==true)
					return $res;
				else
					return false; 
			}
		}
		
		elseif($tmp=="show_all_sliders")
		{
			$query="SELECT * FROM tbl_slider WHERE slider_is_status='1'";
			if($res=mysql_query($query))
				return $res;
			else
				return false;

		}
		elseif($tmp=="select_all_event")
		{
			$query="SELECT * FROM tbl_event WHERE event_is_status='1' AND event_end_date>='".date("Y/m/d H:i:s")."' ORDER BY (event_start_date) ";
			if($res=mysql_query($query))
				return $res;
			else
				return false;
		}
		
	}
	

	// Insert, Update, Delete, Select In table tbl_register
	public function iuds_tbl_register($tmp,$id,$fname,$lname,$address,$gender,$bod,$contact,$email,$pass,$ip_address)
	{		
		//check/ user information form table tbl_register &check iser is valid  or not
	   if($tmp=="check_user")
		{
			$check_user="SELECT * FROM tbl_register WHERE register_email_id='".$email."' AND register_passwd='".$pass."'";
			$res=mysql_query($check_user);
			$a=mysql_fetch_array($res);
			if($a[0] >= 1 && $a['register_is_status']=='1')
				return "true1";
			elseif($a[0] >= 1 && $a['register_is_status']=='0')
				return "true2";
			else
				return "false";
			
		}
		elseif($tmp=="user_is_online")
		{
			$query="UPDATE tbl_register SET register_session='1' WHERE register_email_id='".$email."' AND register_passwd='".$pass."'";
			$res=mysql_query($query);
			$query="SELECT register_id FROM tbl_register WHERE  register_email_id='".$email."' AND register_passwd='".$pass."'";
			$res=mysql_query($query);
			$ans=mysql_fetch_array($res);
			return $ans['register_id'];
		}
		elseif($tmp=="insert")
		{
		   $query="INSERT INTO tbl_register VALUES (NULL,
													'".$fname."',
													'".$lname."',
													'".$address."',
													'".$gender."',
													'".$bod."',
													'".$contact."',
													'".$email."',
													'".$pass."',
													'".date("Y/m/d H:i:s")."',
													'".date("Y/m/d H:i:s")."',
													'1',
													'1',
													'".$ip_address."'
													)";

		     if(mysql_query($query))
		     	return true;
		     else
				return false;
		}
		elseif($tmp=="session_distroy")
		{
			$query="UPDATE tbl_register SET register_session='0' WHERE register_id=".$id;
			mysql_query($query);
		}
		elseif($tmp=="check_forget")
		{
			$check_forget="SELECT COUNT(register_id) FROM tbl_register WHERE register_fname='".$fname."' && register_lname='".$lname."'  && register_bod='".$bod."' && (register_email_id='".$email."' || register_contect_no='".$contact."')";
			$res=mysql_query($check_forget);
			$a=mysql_fetch_array($res);
			if($a[0]=='1')
			{
				$q="SELECT register_id,register_is_status FROM tbl_register WHERE register_fname='".$fname."' && register_lname='".$lname."' && (register_contect_no='".$contact."' || register_email_id='".$email."')";
				$r=mysql_query($q);
				$a=mysql_fetch_array($r);
				if($a['register_is_status']=='1')
					return $a['register_id'];
				else
					return "true2";
			}
			else
				return "false";
		}
		elseif($tmp=="select_record")
		{
			$query="SELECT * FROM tbl_register WHERE register_id=".$id;
			$res=mysql_query($query);
			if($ans=mysql_fetch_array($res))
				return $ans;
		}
		elseif($tmp=="update_address")
		{
			$query="UPDATE tbl_register SET register_address='".$address."' WHERE register_id=".$id;
			$res=mysql_query($query);	   
		}
	}



	//Send Feed back to admin 
	public function send_feedback($tmp,$register_id,$feedback_discription)
	{
		$query="INSERT INTO tbl_feedback VALUES(NULL,
												".$register_id.",
												'".$feedback_discription."',
												'".date("Y/m/d H:i:s")."')";
		if($res=mysql_query($query))
			return true;
		else
			return false;

	}

	//insert, update delete and select cart infotmation from tbl_cart
	public function iuds_tbl_cart($tmp,$cart_id,$register_id,$sub_dishes_id)
	{
		if($tmp=="insert_sub_dishes")
		{
			$q="SELECT COUNT(sub_dishes_id) FROM tbl_cart WHERE register_id=".$register_id;
			$r=mysql_query($q);
			$a=mysql_fetch_array($r);

			if($a[0]<20)
			{
				$q2="SELECT COUNT(cart_id) FROM tbl_cart WHERE register_id=".$register_id ." && sub_dishes_id=".$sub_dishes_id;
				$r2=mysql_query($q2);
				$a2=mysql_fetch_array($r2);
				if($a2[0]=="0")
				{
					$query="INSERT INTO tbl_cart VALUES (NULL,
													".$register_id.",
													".$sub_dishes_id.",
													'".date("Y/m/d H:i:s")."',
													'".date("Y/m/d H:i:s")."')";
					mysql_query($query);
					return "dish_add_in_cart";
				}
				else
					return "dish_is_already_added";
			}
			else
				return "cart_is_full";			
		}
		elseif($tmp=="select_customer_cart")
		{
			$query="SELECT * FROM tbl_cart WHERE register_id=".$register_id;
			if($res=mysql_query($query))
				return $res;
			else
				return false;
		}
		elseif($tmp=="delete_dishes_from_cart")
		{
			$query="DELETE FROM tbl_cart WHERE cart_id=".$cart_id;
			mysql_query($query);
		}
		elseif($tmp=="delete_cart_When_order_receive")
		{
			$query="DELETE FROM tbl_cart WHERE register_id=".$register_id;
			mysql_query($query);
		}
	}	
	
	//select subdishes useing sub_dishes_id from tbl_sub_dishes
	public function select_sub_dishes($tmp,$sub_dishes_id)
	{
		if($tmp=="select_using_id")
		{
			$query="SELECT * FROM tbl_sub_dishes WHERE sub_dishes_id=".$sub_dishes_id;
			$res=mysql_query($query);
			if($ans=mysql_fetch_array($res))
				return $ans;
			else
				return false;
		}
	}

	//select all taste from tbl_taste
	public function iuds_tbl_taste($tmp,$id)
	{
		if($tmp=="select")
		{
			if(empty($id))
			{
				$query="SELECT * FROM tbl_taste WHERE taste_is_status='1' ORDER BY(taste_name)";
				$res=mysql_query($query);
				return $res;
			}
			else
			{
				$query="SELECT * FROM tbl_taste WHERE taste_id=".$id; 
				$res=mysql_query($query);
				if($ans=mysql_fetch_array($res))
					return $ans;
				else
					return false;
					
			}
		}
	}
	
	//select all taste from tbl_payment
	public function iuds_tbl_payment($tmp,$id)
	{
		if($tmp=="select")
		{
			if(empty($id))
			{
				$query="SELECT * FROM tbl_payment WHERE payment_is_status='1' ORDER BY(payment_type)";
				$res=mysql_query($query);
				return $res;
			}
			else
			{
				$query="SELECT * FROM tbl_payment WHERE payment_is_status='1' && payment_id=".$id." ORDER BY(payment_type) ";
				$res=mysql_query($query);
				$ans=mysql_fetch_array($res);
				return $ans;
			}
		}
	}


	//insert into table tbl_order
	public function iuds_tbl_order($tmp,$order_id,$register_id,$payment_id,$taste_id,$order_delivery_address,$order_delivery_time,$order_total_quantity_and_price,$order_special_instruction)
	{
		if($tmp=="insert")
		{
			$query="INSERT INTO tbl_order VALUES(NULL,
												".$register_id.",
												".$payment_id.",
												'".$taste_id."',
												'".$order_delivery_address."',
												'".$order_delivery_time."',
												'".$order_total_quantity_and_price."',
												'".$order_special_instruction."',
												'".date("Y/m/d H:i:s")."',
												'".date("Y/m/d H:i:s")."',
												'3')";
			if(mysql_query($query))
			{
				//select oder id
				$q="SELECT order_id FROM tbl_order WHERE register_id=".$register_id." AND payment_id=".$payment_id." AND taste_id='".$taste_id."' AND  order_delivery_address='".$order_delivery_address."'  AND order_total_quantity_and_price='".$order_total_quantity_and_price."' AND order_special_instruction='".$order_special_instruction."'";
				$res2=mysql_query($q);
				$ans=mysql_fetch_array($res2);
				return $ans[0];
			}
			else
				return false;
		}
		elseif($tmp=="select")
		{	
			
			//update order status which is show to admin
			$q="UPDATE tbl_order SET order_is_status='2' WHERE order_id=".$order_id;
			mysql_query($q);

			$query="SELECT * FROM tbl_order WHERE order_id=".$order_id;
			$res=mysql_query($query);

			if($ans=mysql_fetch_array($res))
				return $ans;
			else
				return false;	
		}
	}


	//insert into table tbl_bill
	// Generate bill for customer
	public function iuds_tbl_bill($tmp,$order_id,$register_id,$payment_id)
	{
		if($tmp=="insert_for_jenerate_bill")
		{
			$q="SELECT COUNT(order_id) FROM tbl_bill";
			$r=mysql_query($q);
			$a=mysql_fetch_array($r);

			if($a[0]>0)
			{
				$q2="DELETE FROM tbl_bill WHERE order_id=".$order_id;
				mysql_query($q2);
			}
			$query="INSERT INTO tbl_bill VALUES(NULL,
												".$order_id.",
												".$register_id.",
												".$payment_id.",
												'".date("Y/m/d H:i:s")."')";
			mysql_query($query);
		}
		elseif($tmp="select_bill_info")
		{
			$query="SELECT * FROM tbl_bill WHERE bill_id=(SELECT MAX(bill_id) FROM tbl_bill WHERE register_id=".$register_id.")";
			$res=mysql_query($query);
			if($ans=mysql_fetch_array($res))
				return $ans;
			else
				return false;
		}
		
		
	}

}