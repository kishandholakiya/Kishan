<?php 
session_start(); 
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();
?>


<!--header slider area are start-->
    <div class="header-slider-area">   
    <!-- mobile-menu-area start -->
    <div class="mobile-menu-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <nav id="dropdown">
                            <ul>
                                <li><a href="index.php">HOME</a></li>
                                <li><a href="menu.php">Menu</a>
                                    <ul>
                                        <li><a href="menu.php?name=Chinese">Chinese</a></li>
                                        <li><a href="menu.php?name=Gujarati">Gujarati</a></li>
                                        <li><a href="menu.php?name=Panjabi">Panjabi</a></li>   
                                        <li><a href="menu.php?name=Street Food">Street Food</a></li>
                                        <li><a href="menu.php?name=Ice Cream">Ice Cream</a></li>
                                    </ul>
                                </li>
                                <li><a href="events.php">Events</a></li>
                                <li><a href="cart.php">Cart</a></li>
                                <li><a href="feedback.php">FeedBack</a></li>
                                <li><a href="contect.php">Contect</a></li>
                                <?php 
                                if(isset($_SESSION['customer']))
                                { ?>
                                  <li><a onclick='return logout();' href="index.php?m=1">Check Out</a></li> <?php
                                }
                                else
                                { ?>
                                  <li><a href="registration.php">Check In</a></li> <?php
                                }
                                ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
</div> 
    <!--mobile menu area end-->
       
    <!--header menu area are start-->
    <div class="header-menu-area">
    <!--header-area are start-->
    <div class="header">
            <div class="container">
            <?php 
                    // Select admin Information
                            $tmp="select_tbl_admin";
                   $res=$con->select_all_data($tmp,$main_dishes_name);
                   $ans=mysql_fetch_array($res);
                   extract($ans);   
                 ?>
                <div class="row">
                    <div class="col-md-4 col-sm-4 hidden-xs">
                        <div class="search-phone">
                            <ul>
                                <li style="color:#FFF;"><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;+91<?php echo $food_mania_cno_1; ?></li>
                            </ul>
                        </div>
                    </div>
                    <div align="center" class="col-md-4 col-sm-4">
                        <div class="raj-img"> 
                            <a href="index.php"><img src="img/icon_img/logo_white.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    <!--header-area are end-->
    
    <!-- Main menu area are start  -->
    <div id="sticker" class="menu-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="main-menu">
                       <nav>
                        <ul>
                            <li><a href="index.php" style="padding-left:35px;padding-right:35px;"><i class="fa fa-home" aria-hidden="true">
                            &nbsp;Home</i></a></li>

                            <li><a href="menu.php" style="padding-left:35px;padding-right:35px;">Menu<i class="fa fa-angle-down" aria-hidden="true"></i>
</a>
                              <div class="mega-menu mega-2">
                                 <span>
                                    <a href="menu.php?name=Chinese">
                                       <span>Chinese</span>
                                        <img src="img/1.jpg" alt="" class="img img-rounded" style="height:210px;width:300px;">
                                    </a>
                                 </span>
                                 <span>
                                    <a href="menu.php?name=Gujarati">
                                       <span>Gujarati</span>
                                        <img src="img/2.jpg" alt="" class="img img-rounded" style="height:210px;width:300px;">                                      
                                    </a>
                                 </span>
                                  <span>
                                    <a href="menu.php?name=Panjabi">
                                       <span>Panjabi</span>
                                        <img src="img/3.jpg" alt="" class="img img-rounded" style="height:210px;width:300px;">
                                    </a>
                                 </span>
                                 <span>
                                    <a href="menu.php?name=Street Food">
                                       <span>Street Food</span>
                                        <img src="img/4.jpg" alt="" class="img img-rounded" style="height:210px;width:300px;">
                                    </a>
                                 </span>
                                 <span>
                                    <a href="menu.php?name=Ice Cream">
                                       <span>Ice Cream </span>
                                        <img src="img/5.jpg" alt="" class="img img-rounded" style="height:210px;width:300px;">
                                    </a>
                                 </span>
                             </div>
                           </li>
                            <li><a href="events.php" style="padding-left:35px;padding-right:35px;">Events</a></li>
                            <li><a href="cart.php" style="padding-left:35px;padding-right:35px;">Cart</a></li>
                            <li><a href="feedback.php" style="padding-left:35px;padding-right:35px;">FeedBack</a></li>
                            <li><a href="contact.php" style="padding-left:35px;padding-right:35px;">Contact</a></li>
                            <?php 
                            if(isset($_SESSION['customer']))
                            { ?>
                              <li><a onclick='return logout();' href="index.php?m=1">Check Out</a></li> <?php
                            }
                            else
                            { ?>
                              <li><a href="registration.php">Check In</a></li> <?php
                            }
                            ?>
                            
                        </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main menu area are end  -->    
    </div>
    <!--header menu area are end-->
    
	<!-- home slider start -->
    <div class="slider-container">
        <!-- Slider Image -->
        <div id="mainSlider" class="nivoSlider slider-image">
            <?php 
            $tmp="show_all_sliders";
            $res=$con->select_all_data($tmp,$main_dishes_name);
            while($ans=mysql_fetch_array($res))
            { 
                extract($ans); ?>
                <img src="img/slider_img/<?php echo $slider_img; ?>"  title="#htmlcaption" />  <?php 
            }
            ?>
        </div>
        <!-- Slider Caption 1 -->
        <div id="htmlcaption" class="nivo-html-caption slider-caption-1">
            <div class="slider-progress"></div>
            <div class="slide1-text">
               <div class="top-icon sl-icon">
                   <img src="img/icon_img/star-icon.png" alt="">
               </div>
                <div class="middle-text">
                    <div class="cap-title wow bounceInRight" data-wow-duration="1.2s" data-wow-delay="0.2s">
                        <h1>Food Mania</h1>
                    </div>
                    <div class="cap-dec wow bounceInDown" data-wow-duration="0.9s" data-wow-delay="0s">
                        <h3><!-- LUXURYRESTRUNTLOOKBOOK --></h3>
                    </div>
                    <div class="bottom-icon sl-icon raj">
                        <img src="img/slider/rou.png" alt="">
                    </div>
                </div>
            </div>
    </div>
    <!-- home slider end -->
    
    </div> 
    </div>
	
	<!-- Check for logout -->
        <script type="text/javascript">
          function logout()
          {
            var a=confirm("Are you want to sure Logout.....?");
            if(a==true)
              return true;
            else
              return false;
          }
        </script>

    
    