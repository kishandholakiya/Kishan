<?php 
include_once("client_connection.php");

$con = new client_connection();
$con->client_connect();



session_start();


$rand=rand(10000,999999);
$_SESSION['otp_num']=$rand;
if(isset($_SESSION['email']) && !empty($_SESSION['email']))
{
	header("Location:MAIL/phpmailer.php");
}
elseif(isset($_SESSION['cno']) && !empty($_SESSION['cno']))
{
	header("Location:SMS/example.php");
}
elseif(isset($_GET['notic']))
{
	if($_GET['notic']=="thank")
	{
		$tmp="select_record";	
		$id=$_SESSION['customer'];
		$res=$con->iuds_tbl_register($tmp,$id,$fname,$lname,$address,$gender,$bod,$contact,$email,$pass,$ip_address);
		$_SESSION['customer_name']=$res['register_fname']." ".$res['register_lname'];
		$_SESSION['cno']=$res['register_contect_no'];
		header("Location:SMS/example.php?notic=order_accepted&order_id=$order_id");	
	}
}
elseif($_GET['paypal']=="paypal_successfull")
{
	$tmp="select_record";	
	$id=$_SESSION['customer'];
	$order_id=$_GET['order_id'];
	$res=$con->iuds_tbl_register($tmp,$id,$fname,$lname,$address,$gender,$bod,$contact,$email,$pass,$ip_address);
	$_SESSION['customer_name']=$res['register_fname']." ".$res['register_lname'];
	$_SESSION['cno']=$res['register_contect_no'];
	header("Location:SMS/example.php?notic=thank_paypal&order_id=$order_id");	
}
elseif($_GET['order_cancle']=="advance_order_cancle")
{
	$tmp="select_record";	
	$id=$_SESSION['customer'];
	$res=$con->iuds_tbl_register($tmp,$id,$fname,$lname,$address,$gender,$bod,$contact,$email,$pass,$ip_address);
	$_SESSION['customer_name']=$res['register_fname']." ".$res['register_lname'];
	$_SESSION['cno']=$res['register_contect_no'];
	header("Location:SMS/example.php?notic=order_cancle");	

}


	






?>