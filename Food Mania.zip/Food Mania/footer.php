<?php 
include_once("client_connection.php");
$con = new client_connection();
$con->client_connect();
?>
<!--footer area are start-->
     <div class="footer-area pt60 pb60">
         <div class="container">
             <div class="row">
                 <div class="col-md-4 col-sm-4 col-xs-12">
                     <div class="single-footer text-center">
                        <div class="sosa-icon">
                            <img src="img/icon/icon-service.png" alt="">
                        </div>
                         <h1>Delivery Service</h1>
                         <div class="address">
						 <?php 
				               // Select admin Information
                                $tmp="select_tbl_admin";
					           $res=$con->select_all_data($tmp,$main_dishes_name);
					           $ans=mysql_fetch_array($res);
					           extract($ans);	  
				         ?>
                            <span>
							<table align="center">
                                <tr style="height:70px;">
                                  <td style="width:300px;text-transform:capitalize;">
								      <?php echo $food_mania_address;?>          
								  </td>
                            </tr>
							</table>
                            </span>
                            <div class="phone-no">
                                <span>
								  <table align="center">
								   <tr>
									<td align="center">Contect No<br /><?php echo $food_mania_cno_1."<br>".$food_mania_cno_2;?></td>
								   </tr>
								  </table>
								</span>
                            </div>
                         </div>
                     </div>
                 </div>
                 <div class="col-md-4 col-sm-4 col-xs-12">
                     <div class="single-footer footer-middle text-center">
                        <div class="sosa-icon">
                            <img src="img/icon/icon-time.png" alt="">
                        </div>
                         <h1>Time Service</h1>
                        <div class="service-time">
						   <table align="center">
						     <tr>
							   <h2>Monday To Saturday </h2>
							 </tr>
							 <td align="center"><?php echo $food_mania_op_mon_sat;?>&nbsp;&nbsp; To &nbsp;&nbsp;<?php echo $food_mania_cl_mon_sat;?></td>
							 <td></td>
						   </table>
                           
                        </div>
                        <div class="service-time">
						  <table align="center">
						   <tr>
                            <h2>Sunday and Special day</h2>
						   </tr>	
                            <td align="center"><?php echo $food_mania_op_sun_spe;?>&nbsp;&nbsp; To &nbsp;&nbsp;<?php echo $food_mania_cl_sun_spe;?></td>
						  </table>	
                        </div>
                     </div>
                 </div>
                 <div class="col-md-4 col-sm-4 col-xs-12">
                     <div class="single-footer text-center">
                        <div class="sosa-icon">
                            <img src="img/icon/icon-letter.png" alt="">
                        </div>
                         <h1>Subscribe Us</h1>
                        <div class="detail-subs">
						    <div align="center" style="font-size:20px;">  
                              <ul>
                                <li><a href="https://www.facebook.com/Food-Mania-279890255768619/"><i class="fa fa-facebook" aria-hidden="true" style="color:white;margin-top:10px;"></i>
</a></li>  
                                <li><a href="https://www.instagram.com/food_mania101/"><i class="fa fa-instagram" aria-hidden="true" style="color:white;margin-top:20px;"></i>
</a></li>
                            </ul>
                        </div><br>
                        <p style="font-size:16px;">We don't Need to Tip<br>Your Satisfaction is Our Duty</p>
                        </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
    <!--footer area are end-->
        
    <!--Copyright area are start--> 
      <div class="copyright-info pt60 pb60">
        <div class="container">
            <div class="row">
                <img src="img/slider/buttom.png" alt="">
			<p style="color:black;">Devloped By :- Kishan Dholakiya and team</p>
            </div>
        </div>
    </div>
    <!--Copyright area are end--> 
