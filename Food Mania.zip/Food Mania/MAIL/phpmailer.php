<?php
session_start();

require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'k.dholakiya1027@gmail.com';                 // SMTP username
$mail->Password = 'kishan 143 anjal';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$mail->setFrom('k.dholakiya1027@gmail.com', 'Food Mania');
//$mail->addAddress('dhavalradadiya40@gmail.com', 'Dhaval');     // Add a recipient
echo $_SESSION['email']."<br>".$_SESSION['customer_name'];
$mail->addAddress($_SESSION['email'],$_SESSION['customer_name']);               // Name is optional
/*$mail->addReplyTo('info@example.com', 'Information');
$mail->addCC('cc@example.com');
$mail->addBCC('bcc@example.com');

$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
$mail->addAttachment('/tmp/image.jpg', 'new.jpg');  */  // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Take OTP code';
$mail->Body    = "Thank you ".$_SESSION['customer_name']." for connect with us. <br> Your OTP code is hear. <span style='color:red;font-size:20px;'>".$_SESSION['otp_num']."</span> <br>Send By:- Food Mania" ;
$mail->AltBody = 'This code is only use one time';
if(!$mail->send()) {
    header("Location:../forget_pass.php?notic=connection_error");
} else {
    header("Location:../forget_pass_2.php?notic=msg_send");
}