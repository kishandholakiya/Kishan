-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 05, 2017 at 10:18 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `db_foodmania`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `payments`
-- 

CREATE TABLE `payments` (
  `paypal_payment_id` int(11) NOT NULL auto_increment,
  `total_product_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `txn_id` varchar(255) collate utf8_unicode_ci NOT NULL,
  `paypal_payment_gross` float(10,2) NOT NULL,
  `paypal_payment_status` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`paypal_payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `payments`
-- 

INSERT INTO `payments` (`paypal_payment_id`, `total_product_name`, `txn_id`, `paypal_payment_gross`, `paypal_payment_status`) VALUES 
(1, '572', '1160', 0.00, '1'),
(2, '2523', '1120', 0.00, '1'),
(3, '189', '520', 0.00, '1'),
(4, '8619', '160', 0.00, '1'),
(5, '3498', '280', 0.00, '1'),
(6, '2981', '280', 0.00, '1'),
(7, '281', '280', 0.00, '1'),
(8, '3755', '315', 0.00, '1'),
(9, '3729', '830', 0.00, '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `products`
-- 

CREATE TABLE `products` (
  `paypal_product_id` int(11) NOT NULL auto_increment,
  `register_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `total_product_name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `total_product_price` int(11) NOT NULL default '1',
  `is_status` char(3) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`paypal_product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `products`
-- 

INSERT INTO `products` (`paypal_product_id`, `register_id`, `order_id`, `total_product_name`, `total_product_price`, `is_status`) VALUES 
(1, 1, 1, '5-233,6-243,6-61,', 1160, '1'),
(2, 1, 1, '5-233,6-243,6-61,', 1160, '1'),
(3, 2, 4, '16-29,', 1120, '1'),
(4, 1, 5, '1-308,1-71,1-240,1-230,', 520, '1'),
(5, 2, 9, '8-30,', 160, '1'),
(6, 2, 10, '1-270,1-102,1-108,1-30,', 330, '1'),
(7, 2, 12, '1-209,1-102,1-215,1-111,', 280, '1'),
(8, 2, 12, '1-209,1-102,1-215,1-111,', 280, '1'),
(9, 7, 14, '5-102,1-119,', 315, '1'),
(10, 7, 14, '5-102,1-119,', 315, '1'),
(11, 7, 14, '5-102,1-119,', 315, '1'),
(12, 7, 16, '5-108,1-105,', 830, '1'),
(13, 7, 17, '4-215,3-98,', 630, '1'),
(14, 7, 17, '4-215,3-98,', 630, '1'),
(15, 7, 17, '4-215,3-98,', 630, '1'),
(16, 7, 17, '4-215,3-98,', 630, '1'),
(17, 7, 17, '4-215,3-98,', 630, '1'),
(18, 7, 17, '4-215,3-98,', 630, '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_admin`
-- 

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL auto_increment,
  `admin_name` varchar(50) NOT NULL,
  `admin_bod` date NOT NULL,
  `admin_gender` varchar(7) NOT NULL,
  `admin_email_id` varchar(50) NOT NULL,
  `admin_passwd` varchar(30) NOT NULL,
  `admin_profile` varchar(50) NOT NULL,
  `food_mania_address` varchar(200) NOT NULL,
  `food_mania_op_mon_sat` time NOT NULL,
  `food_mania_cl_mon_sat` time NOT NULL,
  `food_mania_op_sun_spe` time NOT NULL,
  `food_mania_cl_sun_spe` time NOT NULL,
  `food_mania_cno_1` varchar(15) NOT NULL,
  `food_mania_cno_2` varchar(15) NOT NULL,
  `admin_is_status` char(3) NOT NULL default '1',
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `tbl_admin`
-- 

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_bod`, `admin_gender`, `admin_email_id`, `admin_passwd`, `admin_profile`, `food_mania_address`, `food_mania_op_mon_sat`, `food_mania_cl_mon_sat`, `food_mania_op_sun_spe`, `food_mania_cl_sun_spe`, `food_mania_cno_1`, `food_mania_cno_2`, `admin_is_status`) VALUES 
(1, 'kishan', '1997-08-27', 'Male', 'k.dholkiya@gmail.com', '123456789', 'admin_profile.jpg', '165, sarita darshan soc., chikiuwadi, varachha road, surat', '07:00:00', '23:00:00', '08:00:00', '23:59:00', '9714886991', '7990902544', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_bill`
-- 

CREATE TABLE `tbl_bill` (
  `bill_id` int(11) NOT NULL auto_increment,
  `order_id` int(11) NOT NULL,
  `register_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `bill_entry_date` datetime NOT NULL,
  PRIMARY KEY  (`bill_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `tbl_bill`
-- 

INSERT INTO `tbl_bill` (`bill_id`, `order_id`, `register_id`, `payment_id`, `bill_entry_date`) VALUES 
(2, 1, 1, 2, '2017-04-18 06:29:42'),
(4, 3, 2, 1, '2017-04-18 06:46:16'),
(6, 4, 2, 2, '2017-04-18 06:50:39'),
(7, 5, 1, 2, '2017-04-18 06:54:57'),
(9, 7, 3, 1, '2017-04-19 10:37:49'),
(10, 8, 3, 1, '2017-04-19 17:11:49'),
(12, 11, 2, 1, '2017-04-20 06:57:27'),
(13, 13, 2, 1, '2017-04-20 10:01:40');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_cart`
-- 

CREATE TABLE `tbl_cart` (
  `cart_id` int(11) NOT NULL auto_increment,
  `register_id` int(11) NOT NULL,
  `sub_dishes_id` int(11) NOT NULL,
  `cart_entry_date` datetime NOT NULL,
  `cart_modify_date` datetime NOT NULL,
  PRIMARY KEY  (`cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `tbl_cart`
-- 

INSERT INTO `tbl_cart` (`cart_id`, `register_id`, `sub_dishes_id`, `cart_entry_date`, `cart_modify_date`) VALUES 
(1, 3, 30, '2017-05-02 06:44:35', '2017-05-02 06:44:35'),
(2, 3, 238, '2017-05-02 06:45:45', '2017-05-02 06:45:45');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_event`
-- 

CREATE TABLE `tbl_event` (
  `event_id` int(11) NOT NULL auto_increment,
  `event_name` varchar(30) NOT NULL,
  `event_start_date` datetime NOT NULL,
  `event_end_date` datetime NOT NULL,
  `event_discription` varchar(1000) NOT NULL,
  `event_img` varchar(50) NOT NULL,
  `event_entry_date` datetime NOT NULL,
  `event_modify_date` datetime NOT NULL,
  `event_is_status` char(3) NOT NULL default '1',
  PRIMARY KEY  (`event_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `tbl_event`
-- 

INSERT INTO `tbl_event` (`event_id`, `event_name`, `event_start_date`, `event_end_date`, `event_discription`, `event_img`, `event_entry_date`, `event_modify_date`, `event_is_status`) VALUES 
(8, 'Summer vecation special', '2017-05-10 10:10:00', '2017-06-09 10:10:00', 'Ice Cream,Drinks,Panjabi,Street Food dishes in we can give 7% discount', 'Thai_20170321114250.jpg', '2017-02-07 04:08:15', '2017-03-29 10:12:28', '1'),
(9, 'janmashtami special', '2017-08-09 10:10:00', '2017-08-09 10:10:00', 'Breakfast,Chinese,French dishes in we can give 2% discount', 'Thai_20170321114404.jpg', '2017-02-07 09:21:49', '2017-03-29 11:03:25', '1'),
(10, 'April  special', '2017-04-01 10:10:00', '2017-05-10 11:20:00', 'Chinese,Drinks,Gujarati,Ice Cream  dishes in we can give 5%  discount ', 'Thai_20170321114139.jpg', '2017-02-23 08:29:13', '2017-04-21 04:52:54', '1'),
(11, 'navratri special', '2017-08-19 20:15:00', '2018-09-09 20:10:00', 'Thai,Italian,Indomaxican dishes in we can give 5% discount', 'Thai_20170321114541.jpg', '2017-02-23 09:10:00', '2017-03-29 10:15:10', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_feedback`
-- 

CREATE TABLE `tbl_feedback` (
  `feedback_id` int(11) NOT NULL auto_increment,
  `registration_id` int(11) NOT NULL,
  `feedback_info` varchar(2000) NOT NULL,
  `feedback_entry_date` datetime NOT NULL,
  PRIMARY KEY  (`feedback_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `tbl_feedback`
-- 

INSERT INTO `tbl_feedback` (`feedback_id`, `registration_id`, `feedback_info`, `feedback_entry_date`) VALUES 
(8, 1, 'i can like this food', '2017-03-29 11:38:24'),
(9, 3, 'this food is very testy products and helthy and discount offer fastival then best home delivery ', '2017-03-29 11:45:24'),
(10, 1, 'this is very nice website', '2017-04-11 05:10:49');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_main_dishes`
-- 

CREATE TABLE `tbl_main_dishes` (
  `main_dishes_id` int(11) NOT NULL auto_increment,
  `main_dishes_name` varchar(25) NOT NULL,
  `main_dishes_entry_date` datetime NOT NULL,
  `main_dishes_modify_date` datetime NOT NULL,
  `main_dishes_is_status` char(3) NOT NULL default '1',
  PRIMARY KEY  (`main_dishes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `tbl_main_dishes`
-- 

INSERT INTO `tbl_main_dishes` (`main_dishes_id`, `main_dishes_name`, `main_dishes_entry_date`, `main_dishes_modify_date`, `main_dishes_is_status`) VALUES 
(1, 'Chinese', '2017-02-05 16:06:48', '2017-05-02 12:16:35', '1'),
(3, 'French', '2017-02-05 16:07:13', '2017-02-05 16:07:13', '1'),
(4, 'Gujarati', '2017-02-05 16:07:22', '2017-02-17 05:11:42', '1'),
(5, 'Ice Cream', '2017-02-05 16:07:34', '2017-02-16 11:42:42', '1'),
(6, 'Indomaxican', '2017-02-05 16:07:42', '2017-02-05 16:07:42', '1'),
(7, 'Italian', '2017-02-05 16:07:50', '2017-02-05 16:07:50', '1'),
(8, 'Panjabi', '2017-02-05 16:07:57', '2017-02-05 16:07:57', '1'),
(9, 'Street Food', '2017-02-05 16:08:07', '2017-02-05 16:08:07', '1'),
(10, 'Thai', '2017-02-05 16:08:14', '2017-02-05 16:08:14', '1'),
(12, 'drinks', '2017-02-25 07:50:00', '2017-02-25 07:50:00', '1'),
(13, 'Breakfast', '2017-03-04 10:20:09', '2017-05-02 07:27:46', '1'),
(16, 'sweets', '2017-03-29 10:25:09', '2017-03-30 04:58:02', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_order`
-- 

CREATE TABLE `tbl_order` (
  `order_id` int(11) NOT NULL auto_increment,
  `register_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `taste_id` varchar(50) NOT NULL,
  `order_delivery_address` varchar(200) NOT NULL,
  `order_delivery_time` datetime NOT NULL,
  `order_total_quantity_and_price` varchar(200) NOT NULL,
  `order_special_instruction` varchar(1000) NOT NULL,
  `order_entry_date` datetime NOT NULL,
  `order_modify_date` datetime NOT NULL,
  `order_is_status` char(3) NOT NULL,
  PRIMARY KEY  (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- 
-- Dumping data for table `tbl_order`
-- 

INSERT INTO `tbl_order` (`order_id`, `register_id`, `payment_id`, `taste_id`, `order_delivery_address`, `order_delivery_time`, `order_total_quantity_and_price`, `order_special_instruction`, `order_entry_date`, `order_modify_date`, `order_is_status`) VALUES 
(1, 1, 2, '2,2,0,', 'b 7 jelram soc  surat, nanaverchha', '0000-00-00 00:00:00', '5-233,6-243,6-61,', 'time 5:45 pm', '2017-04-18 06:20:05', '2017-04-18 06:20:05', '0'),
(2, 2, 1, '3,', '165, sarita darshan soc., chikuwadi, varachha road, surat', '0000-00-00 00:00:00', '12-111,', '', '2017-04-18 06:44:59', '2017-04-18 06:44:59', '0'),
(3, 2, 1, '3,', '165, sarita darshan soc., chikuwadi, varachha road, surat', '0000-00-00 00:00:00', '9-215,', '', '2017-04-18 06:46:16', '2017-04-18 06:46:16', '0'),
(4, 2, 2, '1,', '165, sarita darshan soc., chikuwadi, varachha road, surat', '0000-00-00 00:00:00', '16-29,', '', '2017-04-18 06:47:24', '2017-04-18 06:47:24', '1'),
(5, 1, 2, '0,0,2,1,', 'b 7 jelram soc  surat, nanaverchha', '0000-00-00 00:00:00', '1-308,1-71,1-240,1-230,', '', '2017-04-18 06:54:28', '2017-04-18 06:54:28', '1'),
(7, 3, 1, '3,1,', '89,tapidarshan soc,nanavarachha, near savji korat bridge, surat', '2017-04-25 07:01:00', '6-102,3-112,', '', '2017-04-19 10:37:48', '2017-04-19 10:37:48', '1'),
(8, 3, 1, '0,', '89,tapidarshan soc,nanavarachha, near savji korat bridge, surat', '0000-00-00 00:00:00', '4-139,', '', '2017-04-19 17:11:49', '2017-04-19 17:11:49', '1'),
(10, 2, 2, '3,1,2,0,', '165, sarita darshan soc., chikuwadi, varachha road, surat', '0000-00-00 00:00:00', '1-270,1-102,1-108,1-30,', '', '2017-04-20 06:28:03', '2017-04-20 06:28:03', '3'),
(11, 2, 1, '3,1,2,0,', '165, sarita darshan soc., chikuwadi, varachha road, surat', '0000-00-00 00:00:00', '1-270,1-102,1-108,1-30,', '', '2017-04-20 06:57:27', '2017-04-20 06:57:27', '0'),
(12, 2, 2, '3,1,3,1,', '165, sarita darshan soc., chikuwadi, varachha road, surat', '0000-00-00 00:00:00', '1-209,1-102,1-215,1-111,', '', '2017-04-20 08:53:39', '2017-04-20 08:53:39', '3'),
(13, 2, 1, '1,1,3,', '165, sarita darshan soc., chikuwadi, varachha road, surat', '0000-00-00 00:00:00', '5-209,4-215,4-111,', '', '2017-04-20 10:01:40', '2017-04-20 10:01:40', '2'),
(17, 7, 2, '2,1,', '165, sarita darshan soc., , chikuwadi, nana varachha road, surat', '2017-05-09 07:00:00', '4-215,3-98,', '', '2017-05-02 12:11:45', '2017-05-02 12:11:45', '3');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_payment`
-- 

CREATE TABLE `tbl_payment` (
  `payment_id` int(11) NOT NULL auto_increment,
  `payment_type` varchar(30) NOT NULL,
  `payment_entry_date` datetime NOT NULL,
  `payment_modify_date` datetime NOT NULL,
  `payment_is_status` char(3) NOT NULL,
  PRIMARY KEY  (`payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `tbl_payment`
-- 

INSERT INTO `tbl_payment` (`payment_id`, `payment_type`, `payment_entry_date`, `payment_modify_date`, `payment_is_status`) VALUES 
(1, 'cash on delivery', '2017-03-06 12:33:52', '2017-03-06 12:33:52', '1'),
(2, 'paypal', '2017-03-06 12:34:00', '2017-03-06 12:34:00', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_register`
-- 

CREATE TABLE `tbl_register` (
  `register_id` int(11) NOT NULL auto_increment,
  `register_fname` varchar(25) NOT NULL,
  `register_lname` varchar(25) NOT NULL,
  `register_address` varchar(200) NOT NULL,
  `register_gender` varchar(7) NOT NULL,
  `register_bod` date NOT NULL,
  `register_contect_no` varchar(40) NOT NULL,
  `register_email_id` varchar(30) NOT NULL,
  `register_passwd` varchar(30) NOT NULL,
  `register_entry_date` datetime NOT NULL,
  `register_modify_date` datetime NOT NULL,
  `register_is_status` char(3) NOT NULL default '1',
  `register_session` char(3) NOT NULL default '1',
  `register_ip_address` varchar(20) NOT NULL,
  PRIMARY KEY  (`register_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `tbl_register`
-- 

INSERT INTO `tbl_register` (`register_id`, `register_fname`, `register_lname`, `register_address`, `register_gender`, `register_bod`, `register_contect_no`, `register_email_id`, `register_passwd`, `register_entry_date`, `register_modify_date`, `register_is_status`, `register_session`, `register_ip_address`) VALUES 
(1, 'kajal', 'kamani', 'b 7 jelram soc  surat, nanaverchha', 'Female', '1996-08-10', '9512731031', 'kajalkamani@gmail.com', '123456789', '2017-04-18 06:16:32', '2017-04-18 08:54:20', '1', '0', '127.0.0.1'),
(2, 'kishan', 'dholakiya', '165, sarita darshan soc., chikuwadi, varachha road, surat', 'Male', '1997-08-27', '9714886991', 'k.dholakiya1027@gmail.com', '123456789', '2017-04-18 06:43:29', '2017-04-20 04:43:02', '1', '0', '127.0.0.1'),
(3, 'ajay', 'bodar', '89,tapidarshan soc,nanavarachha, near savji korat bridge, surat', 'Male', '1996-11-03', '9727635945', 'ajaybodar@yahoo.com', '123456789', '2017-04-18 07:18:48', '2017-04-18 08:52:38', '1', '0', '127.0.0.1'),
(4, 'dhruvi', 'gosai', '303,shrirecidancy puna simda, surat', 'Female', '1997-12-30', '8140095166', 'dhruvigosi3006@gmail.com', '789456123', '2017-04-18 07:26:25', '2017-04-18 07:26:25', '1', '0', '127.0.0.1'),
(5, 'bhumi', 'vora', '124,pramukhchhya soc puna simda rod, surat ', 'Female', '1997-06-04', '9427713191', 'bumivora@gemil.com', '789456123', '2017-04-18 07:29:09', '2017-04-18 07:29:09', '1', '0', '127.0.0.1'),
(7, 'kishan', 'dholakiya', '165, sarita darshan soc., , chikuwadi, nana varachha road, surat', 'Male', '2000-05-02', '9714886991', 'k.dholakiya1027@gmail.com', '987456321', '2017-05-02 06:53:30', '2017-05-02 06:53:30', '1', '0', '127.0.0.1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_slider`
-- 

CREATE TABLE `tbl_slider` (
  `slider_id` int(11) NOT NULL auto_increment,
  `slider_img` varchar(30) NOT NULL,
  `slider_entry_date` datetime NOT NULL,
  `slider_modify_date` datetime NOT NULL,
  `slider_is_status` char(3) NOT NULL,
  PRIMARY KEY  (`slider_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `tbl_slider`
-- 

INSERT INTO `tbl_slider` (`slider_id`, `slider_img`, `slider_entry_date`, `slider_modify_date`, `slider_is_status`) VALUES 
(1, 'slider_20170307053344.jpg', '2017-03-07 05:33:44', '2017-03-07 05:33:44', '1'),
(2, 'slider_20170307053436.jpg', '2017-03-07 05:34:36', '2017-03-07 05:39:38', '1'),
(3, 'slider_20170307053449.jpg', '2017-03-07 05:34:49', '2017-03-07 05:34:49', '1'),
(4, 'slider_20170307053506.jpg', '2017-03-07 05:35:06', '2017-03-07 05:35:06', '1'),
(5, 'slider_20170307053542.jpg', '2017-03-07 05:35:42', '2017-03-07 05:35:42', '1'),
(6, 'slider_20170307053552.jpg', '2017-03-07 05:35:52', '2017-03-07 05:35:52', '1'),
(7, 'slider_20170307053602.jpg', '2017-03-07 05:36:02', '2017-03-07 05:36:02', '1'),
(8, 'slider_20170307053613.jpg', '2017-03-07 05:36:13', '2017-03-07 05:36:13', '1'),
(9, 'slider_20170307053634.jpg', '2017-03-07 05:36:34', '2017-03-07 05:36:34', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_sub_dishes`
-- 

CREATE TABLE `tbl_sub_dishes` (
  `sub_dishes_id` int(11) NOT NULL auto_increment,
  `main_dishes_id` int(11) NOT NULL,
  `sub_dishes_name` varchar(50) NOT NULL,
  `sub_dishes_price` int(11) NOT NULL,
  `sub_dishes_img` varchar(50) NOT NULL,
  `sub_dishes_discription` varchar(1000) NOT NULL,
  `sub_dishes_entry_date` datetime NOT NULL,
  `sub_dishes_modify_date` datetime NOT NULL,
  `sub_dishes_is_status` char(3) NOT NULL,
  PRIMARY KEY  (`sub_dishes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=314 ;

-- 
-- Dumping data for table `tbl_sub_dishes`
-- 

INSERT INTO `tbl_sub_dishes` (`sub_dishes_id`, `main_dishes_id`, `sub_dishes_name`, `sub_dishes_price`, `sub_dishes_img`, `sub_dishes_discription`, `sub_dishes_entry_date`, `sub_dishes_modify_date`, `sub_dishes_is_status`) VALUES 
(7, 1, 'manchurian', 95, 'Chinese_20170228073411.jpg', 'manchurian dry and gravy', '2017-02-25 11:07:55', '2017-02-28 07:34:11', '1'),
(14, 1, 'Vegetarian Hakka Noodles.', 90, 'Chinese_20170228074548.jpg', 'Vegetarian Hakka Noodles', '2017-02-25 12:07:50', '2017-02-28 07:45:48', '1'),
(15, 1, 'veg schezwan noodles', 95, 'Chinese_20170228074405.jpg', 'veg schezwan noodles', '2017-02-25 12:12:16', '2017-02-28 07:44:05', '1'),
(16, 1, 'Chinese Bhel', 95, 'Chinese_20170228073303.jpg', 'Chinese Bhel', '2017-02-25 12:15:45', '2017-02-28 07:33:03', '1'),
(17, 1, 'manchurian noodles', 95, 'Chinese_20170228073540.jpg', 'manchurian noodles', '2017-02-25 12:20:58', '2017-02-28 07:35:40', '1'),
(18, 1, 'Triple schezwan fried ric', 110, 'Chinese_20170228073904.jpg', 'Triple schezwan fried rice', '2017-02-25 12:28:52', '2017-02-28 07:39:04', '1'),
(19, 1, 'veg Schezwan Fried Rice', 85, 'Chinese_20170228114330.jpg', 'veg Schezwan Fried Rice', '2017-02-25 12:30:49', '2017-02-28 11:43:30', '1'),
(20, 1, 'veg  fried rice', 80, 'Chinese_20170228074043.jpg', 'veg  fried rice', '2017-02-25 12:32:38', '2017-02-28 07:40:43', '1'),
(21, 1, 'veg  chilli', 95, 'Chinese_20170228073957.jpg', 'veg  chilli dry and gravy', '2017-02-25 12:36:03', '2017-02-28 07:39:57', '1'),
(22, 1, 'veg Schezwan', 95, 'Chinese_20170228074320.jpg', 'veg Schezwan dry and gravy', '2017-02-25 12:38:18', '2017-02-28 07:43:20', '1'),
(23, 1, 'panir  Schezwan', 110, 'Chinese_20170228073717.jpg', 'panir  Schezwan dry and gravy', '2017-02-25 12:39:58', '2017-02-28 07:37:17', '1'),
(24, 1, 'Sweet Corn Vegetable Soup', 70, 'Chinese_20170228073755.jpg', 'Sweet Corn Vegetable Soup ', '2017-02-26 06:16:01', '2017-02-28 07:37:55', '1'),
(25, 1, 'Chilli Baby Corn', 100, 'Chinese_20170228073234.jpg', 'Chilli Baby Corn', '2017-02-26 06:20:46', '2017-05-03 07:13:24', '1'),
(26, 1, 'Veg Ginger-Garlic With Se', 100, 'Chinese_20170228074153.jpg', 'Veg Ginger-Garlic with Sesame seeds', '2017-02-26 06:25:57', '2017-02-28 07:41:53', '1'),
(27, 1, 'Vegetable Noodles & Veget', 95, 'Chinese_20170228074500.jpg', 'Vegetable Noodles & Vegetables in Spicy Garlic ', '2017-02-26 06:29:35', '2017-02-28 07:45:00', '1'),
(28, 1, 'Stir Fried Vegetables ', 90, 'Chinese_20170228073033.jpg', ' Stir Fried Vegetables In Peanut-Chilli Sauce ', '2017-02-26 06:32:29', '2017-03-01 09:18:23', '1'),
(29, 1, 'manchow soup', 70, 'Chinese_20170228073348.jpg', 'manchow soup', '2017-02-26 06:38:27', '2017-03-21 10:49:33', '1'),
(30, 12, 'Aam panna', 20, 'drinks_20170228075232.jpg', 'Aam panna', '2017-02-26 07:32:24', '2017-02-28 07:52:32', '1'),
(31, 12, 'Sugarcane juice', 20, 'drinks_20170228085409.jpg', 'Sugarcane juice', '2017-02-26 07:34:24', '2017-02-28 08:54:09', '1'),
(32, 12, 'Nimbu pani ', 15, 'drinks_20170228084621.jpg', 'Nimbu pani ', '2017-02-26 07:51:46', '2017-02-28 08:46:21', '1'),
(33, 12, 'Creamy Limeade', 80, 'drinks_20170228081148.jpg', 'Creamy Limeade', '2017-02-26 08:03:53', '2017-02-28 08:11:48', '1'),
(34, 12, 'Iced Coffee', 80, 'drinks_20170228084128.jpg', 'Iced Coffee', '2017-02-26 08:20:49', '2017-02-28 08:41:28', '1'),
(35, 12, 'orange juice ', 30, 'drinks_20170228084913.jpg', 'orange juice ', '2017-02-26 08:25:02', '2017-02-28 08:49:13', '1'),
(36, 12, 'Strawberry Lemonade', 50, 'drinks_20170228085353.jpg', 'Strawberry Lemonade', '2017-02-26 08:28:13', '2017-02-28 08:53:53', '1'),
(37, 12, 'Banana and Strawberry Smoothie', 80, 'drinks_20170228075341.jpg', 'Banana and Strawberry Smoothie', '2017-02-26 08:31:41', '2017-03-11 10:33:26', '1'),
(38, 12, 'Vegan Coconut Banana Smoo', 80, 'drinks_20170228085609.jpg', 'Vegan Coconut Banana Smoothie', '2017-02-26 08:33:28', '2017-02-28 08:56:09', '1'),
(39, 12, 'Orange Banana Smoothie ', 75, 'drinks_20170228084716.jpg', 'Orange Banana Smoothie ', '2017-02-26 08:36:21', '2017-02-28 08:47:16', '1'),
(40, 12, 'Vietnamese Style Iced Cof', 85, 'drinks_20170228085904.jpg', 'Vietnamese Style Iced Coffee ', '2017-02-26 08:39:27', '2017-02-28 08:59:04', '1'),
(41, 12, 'Chocolate Banana Smoothie', 80, 'drinks_20170228080021.jpg', 'Chocolate Banana Smoothie', '2017-02-26 08:43:08', '2017-02-28 08:00:21', '1'),
(44, 12, 'Basic Pineapple Lemonade ', 80, 'drinks_20170228075531.jpg', 'Basic Pineapple Lemonade ', '2017-02-26 08:49:59', '2017-02-28 07:55:31', '1'),
(45, 12, 'Banana Milkshake', 110, 'drinks_20170228075351.jpg', 'Banana Milkshake', '2017-02-26 08:51:35', '2017-02-28 07:53:51', '1'),
(47, 12, 'Watermelon and MintAgua ', 70, 'drinks_20170228090140.jpg', 'Watermelon and Mint Agua Fresca', '2017-02-26 08:55:53', '2017-02-28 09:01:40', '1'),
(48, 12, 'Banana and Chocolate Milkshake ', 120, 'drinks_20170228075239.jpg', 'Banana and Chocolate Milkshake ', '2017-02-26 08:57:32', '2017-03-11 10:32:53', '1'),
(49, 12, 'efreshing Ginger Lemonade', 40, 'drinks_20170228083518.jpg', 'efreshing Ginger Lemonade ', '2017-02-26 08:58:44', '2017-02-28 08:35:18', '1'),
(51, 12, 'Spiced Orange Tea', 40, 'drinks_20170228085233.jpg', 'Spiced Orange Tea', '2017-02-26 09:05:00', '2017-02-28 08:52:33', '1'),
(52, 12, 'Cinnamon Hot Chocolate', 100, 'drinks_20170228080054.jpg', 'Cinnamon Hot Chocolate', '2017-02-26 09:07:14', '2017-02-28 08:00:54', '1'),
(54, 12, 'Kahlua hot chocolate ', 180, 'drinks_20170228084219.jpg', 'Kahlua hot chocolate ', '2017-02-26 09:13:38', '2017-02-28 08:42:19', '1'),
(55, 12, 'Cappuccino ', 140, 'drinks_20170228075746.jpg', 'Cappuccino ', '2017-02-26 09:15:42', '2017-02-28 07:57:46', '1'),
(57, 12, 'Fruit ice mocktail ', 50, 'drinks_20170228083548.jpg', 'Fruit ice mocktail ', '2017-02-26 09:21:52', '2017-02-28 08:35:48', '1'),
(59, 12, 'Mango Cardamom Smoothie ', 120, 'drinks_20170228084443.jpg', 'Mango Cardamom Smoothie ', '2017-02-26 09:25:08', '2017-02-28 08:44:43', '1'),
(60, 12, 'Honey and Lime Drink ', 70, 'drinks_20170228084003.jpg', 'Honey and Lime Drink ', '2017-02-26 09:26:42', '2017-02-28 08:40:03', '1'),
(61, 12, 'Berry and Yoghurt Smoothie', 140, 'drinks_20170228075545.jpg', 'Berry and Yoghurt Smoothie ', '2017-02-26 09:29:00', '2017-03-11 10:33:44', '1'),
(62, 12, 'Summer punch ', 80, 'drinks_20170228085554.jpg', 'Summer punch ', '2017-02-26 09:31:25', '2017-02-28 08:55:54', '1'),
(63, 12, 'Grapefruit Granita Cocktail', 70, 'drinks_20170228083715.jpg', 'Grapefruit Granita Cocktail ', '2017-02-26 09:33:24', '2017-03-11 10:34:58', '1'),
(65, 12, 'Mango Lassi ', 70, 'drinks_20170228084525.jpg', 'Mango Lassi ', '2017-02-26 09:37:34', '2017-02-28 08:45:25', '1'),
(66, 12, 'Homemade Lemon Drink ', 40, 'drinks_20170228083754.jpg', 'Homemade Lemon Drink ', '2017-02-26 09:39:14', '2017-02-28 08:37:54', '1'),
(67, 12, 'Refreshing Melon Smoothie', 70, 'drinks_20170228085006.jpg', 'Refreshing Melon Smoothie ', '2017-02-26 09:41:07', '2017-02-28 08:50:06', '1'),
(68, 12, 'Easy Orange and Lime Slushie ', 60, 'drinks_20170228081209.jpg', 'Easy Orange and Lime Slushie ', '2017-02-26 09:42:05', '2017-03-11 10:34:20', '1'),
(70, 12, 'Watermelon and Honey Slus', 70, 'drinks_20170228085925.jpg', 'Watermelon and Honey Slushie ', '2017-02-26 09:50:17', '2017-02-28 08:59:25', '1'),
(71, 12, 'Berry Delicious Smoothie ', 100, 'drinks_20170228075737.jpg', 'Berry Delicious Smoothie ', '2017-02-26 09:55:50', '2017-02-28 07:57:37', '1'),
(73, 12, 'soft drinks', 30, 'drinks_20170228085101.jpg', 'soft drinks any one\r\n', '2017-02-26 10:08:12', '2017-02-28 08:51:01', '1'),
(74, 3, 'CrÃªpes with Blackberry ', 200, 'French_20170228092206.jpg', 'CrÃªpes with Blackberry Sauce and Orange-Scented Ricotta', '2017-02-26 10:26:32', '2017-02-28 09:22:06', '1'),
(75, 3, 'Carrot-Ricotta Quiche', 150, 'French_20170228091731.jpg', 'Carrot-Ricotta Quiche', '2017-02-26 10:30:47', '2017-02-28 09:17:31', '1'),
(76, 3, 'English Muffin Toast', 180, 'French_20170228092238.jpg', 'English Muffin French Toast', '2017-02-26 10:33:47', '2017-02-28 09:22:38', '1'),
(77, 3, 'Garlicky French Fries', 150, 'French_20170228094130.jpg', 'Garlicky French Fries', '2017-02-26 10:35:03', '2017-02-28 09:41:30', '1'),
(79, 3, 'French Toast Extraordinai', 170, 'French_20170228093955.jpg', 'French Toast Extraordinaire', '2017-02-26 10:38:44', '2017-02-28 09:39:55', '1'),
(82, 3, 'French-style Peas', 90, 'French_20170228094017.jpg', 'French-style Peas', '2017-02-27 06:29:29', '2017-02-28 09:40:17', '1'),
(83, 3, 'Celeriac coleslaw', 70, 'French_20170228091741.jpg', 'Celeriac coleslaw', '2017-02-27 06:33:53', '2017-02-28 09:17:41', '1'),
(84, 3, 'Veggie French Bread Pizza', 120, 'French_20170228094555.jpg', 'Veggie French Bread Pizza', '2017-02-27 06:39:55', '2017-02-28 09:45:55', '1'),
(85, 3, 'Fantastique JamFrench', 120, 'French_20170228093121.jpg', 'Fantastique Jam Jar French Dressing', '2017-02-27 06:43:24', '2017-02-28 09:31:21', '1'),
(86, 3, 'Orange French Toast', 70, 'French_20170228094320.jpg', 'Orange French Toast', '2017-02-27 06:45:25', '2017-02-28 09:43:20', '1'),
(88, 3, 'French Stuffed Red Bell ', 150, 'French_20170228093540.jpg', 'French Stuffed Red Bell Peppers', '2017-02-27 06:50:30', '2017-02-28 09:35:58', '1'),
(89, 3, 'Classic French Vinaigrett', 80, 'French_20170228091933.jpg', 'Classic French Vinaigrette', '2017-02-27 06:58:50', '2017-02-28 09:19:33', '1'),
(90, 3, 'Classic French Ratatouill', 50, 'French_20170228091918.jpg', 'Classic French Ratatouille', '2017-02-27 07:01:29', '2017-02-28 09:19:18', '1'),
(91, 3, 'French Potato Salad ', 50, 'French_20170228093517.jpg', 'French Potato Salad ', '2017-02-27 07:03:00', '2017-02-28 09:35:17', '1'),
(92, 3, 'French Cherry Clafouti ', 130, 'French_20170228093143.jpg', 'French Cherry Clafouti Pudding', '2017-02-27 07:08:00', '2017-02-28 09:31:43', '1'),
(93, 3, 'Roasted French Vegetables', 50, 'French_20170228094402.jpg', 'Roasted French Vegetables in Hot Balsami', '2017-02-27 07:10:02', '2017-02-28 09:44:02', '1'),
(94, 3, 'Garden Party Cucumber', 40, 'French_20170228091611.jpg', 'Buckingham Palace Garden Party Cucumber', '2017-02-27 07:20:18', '2017-03-01 09:18:42', '1'),
(95, 3, 'Traditional Cyprus Sandwi', 80, 'French_20170228094520.jpg', 'The Traditional Cyprus Sandwich', '2017-02-27 07:23:15', '2017-02-28 09:45:20', '1'),
(96, 4, 'Gujarati Undhiyu', 200, 'Gujarati_20170228095856.jpg', ' Gujarati Undhiyu , greenUndhiyu', '2017-02-27 07:31:15', '2017-02-28 09:58:56', '1'),
(97, 4, 'Kadhi', 80, 'Gujarati_20170228095910.jpg', 'Kadhi, Bhatia Kadhi ', '2017-02-27 07:33:35', '2017-02-28 09:59:10', '1'),
(98, 4, 'khaman dhokla', 90, 'Gujarati_20170228100035.jpg', 'khaman dhokla( Nylon khaman)', '2017-02-27 07:37:02', '2017-02-28 10:00:35', '1'),
(100, 4, 'Dal Dhokli ', 100, 'Gujarati_20170228094855.jpg', 'Dal Dhokli \r\n', '2017-02-27 07:39:39', '2017-03-01 09:17:48', '1'),
(101, 4, 'Thepla', 100, 'Gujarati_20170228100634.jpg', 'Thepla(no of pice12)', '2017-02-27 07:42:06', '2017-02-28 10:06:34', '1'),
(102, 4, 'Batata Nu Shaak', 60, 'Gujarati_20170228095043.jpg', 'Batata Nu Shaak', '2017-02-27 07:43:06', '2017-02-28 09:50:43', '1'),
(103, 4, 'Tomato broth', 80, 'Gujarati_20170228100717.jpg', 'Tomato broth', '2017-02-27 07:49:53', '2017-02-28 10:07:17', '1'),
(105, 4, 'cutlets', 80, 'Gujarati_20170228095437.jpg', 'cutlets (4pice)', '2017-02-27 07:57:58', '2017-02-28 09:54:37', '1'),
(106, 4, 'malpuas', 80, 'Gujarati_20170228100236.jpg', 'malpuas', '2017-02-27 08:04:00', '2017-02-28 10:02:36', '1'),
(108, 4, 'Bhajiya', 150, 'Gujarati_20170228095149.jpg', 'Bhajiya(all types)', '2017-02-27 09:34:54', '2017-02-28 09:51:49', '1'),
(112, 4, 'Dahi vada', 25, 'Gujarati_20170228095616.jpg', 'Dahi vada', '2017-02-27 09:45:16', '2017-02-28 09:56:16', '1'),
(116, 4, 'Sev Tameta nu Shaak', 60, 'Gujarati_20170228100419.jpg', 'Sev Tameta nu Shaak', '2017-02-27 09:59:26', '2017-02-28 10:04:19', '1'),
(117, 4, 'Khichdi', 80, 'Gujarati_20170228094904.jpg', ' Khichdi', '2017-02-27 10:02:30', '2017-03-01 09:18:01', '1'),
(119, 4, 'Dabeli', 15, 'Gujarati_20170228095450.jpg', 'Dabeli', '2017-02-27 10:07:51', '2017-02-28 09:54:50', '1'),
(120, 4, 'Sev Khamni', 120, 'Gujarati_20170228100405.jpg', 'Sev Khamni', '2017-02-27 10:09:21', '2017-02-28 10:04:05', '1'),
(124, 5, 'Bacon ice cream', 100, 'Ice Cream_20170228101213.jpg', 'Bacon ice cream', '2017-02-27 10:33:33', '2017-02-28 10:12:13', '1'),
(125, 5, 'Bastani Sonnati', 120, 'Ice Cream_20170228101229.jpg', 'Bastani Sonnati', '2017-02-27 10:39:17', '2017-02-28 10:12:29', '1'),
(126, 5, 'blue moon ice cream', 125, 'Ice Cream_20170228101739.jpg', 'blue moon ice cream', '2017-02-27 10:41:35', '2017-02-28 10:17:39', '1'),
(128, 5, 'black currant ice cream', 150, 'Ice Cream_20170228101447.jpg', 'black currant ice cream', '2017-02-27 10:48:45', '2017-02-28 10:14:47', '1'),
(129, 5, 'Khandala Special  ice cre', 120, 'Ice Cream_20170228103249.jpg', 'Khandala Special  ice cream', '2017-02-27 10:50:11', '2017-02-28 10:32:49', '1'),
(130, 5, 'Vanilla  ice cream', 100, 'Ice Cream_20170228105259.jpg', 'Vanilla  ice cream', '2017-02-27 10:51:38', '2017-02-28 10:52:59', '1'),
(131, 5, 'american nuts ice cream', 140, 'Ice Cream_20170228101151.jpg', 'american nuts ice cream', '2017-02-27 10:53:02', '2017-02-28 10:11:51', '1'),
(132, 5, 'Kaju Draksh ice cream', 100, 'Ice Cream_20170228103139.jpg', 'Kaju Draksh ice cream', '2017-02-27 10:54:32', '2017-02-28 10:31:39', '1'),
(133, 5, 'Butter Scotch  ice cream', 180, 'Ice Cream_20170228101754.jpg', 'Butter Scotch  ice cream', '2017-02-27 10:55:35', '2017-02-28 10:17:54', '1'),
(134, 5, 'Kesar Pista', 170, 'Ice Cream_20170228103155.jpg', 'Kesar Pista', '2017-02-27 10:59:55', '2017-02-28 10:31:55', '1'),
(135, 5, 'Strawberry Classic ice-cr', 180, 'Ice Cream_20170228104543.jpg', 'Strawberry Classic ice-cream', '2017-02-27 11:01:33', '2017-02-28 10:45:43', '1'),
(136, 5, 'Chocolate Chip', 200, 'Ice Cream_20170228102117.jpg', 'Chocolate Chip', '2017-02-27 11:08:54', '2017-02-28 10:21:17', '1'),
(137, 5, 'Mango ice cream', 120, 'Ice Cream_20170228103738.jpg', 'Mango ice cream', '2017-02-27 11:10:58', '2017-02-28 10:37:38', '1'),
(138, 5, 'Golden Pearl ice cream', 140, 'Ice Cream_20170228102859.jpg', 'Golden Pearl ice cream', '2017-02-27 11:16:22', '2017-02-28 10:28:59', '1'),
(139, 5, 'Anjeer ice cream', 220, 'Ice Cream_20170228101202.jpg', 'Anjeer ice cream', '2017-02-27 11:18:07', '2017-02-28 10:12:02', '1'),
(140, 5, 'Big Treat Royal Buttersco', 50, 'Ice Cream_20170228101436.jpg', 'Big Treat Royal Butterscotch', '2017-02-27 11:20:27', '2017-02-28 10:14:36', '1'),
(141, 5, 'Chocolate Drip Cone', 50, 'Ice Cream_20170228102133.jpg', 'Chocolate Drip Cone', '2017-02-27 11:22:26', '2017-02-28 10:21:33', '1'),
(142, 5, 'Prime Kesar Pista Cone', 70, 'Ice Cream_20170228103803.jpg', 'Prime Kesar Pista Cone', '2017-02-27 11:23:23', '2017-02-28 10:38:03', '1'),
(143, 5, 'Yummy Butter Scotch Cone', 60, 'Ice Cream_20170228105413.jpg', 'Yummy Butter Scotch Cone', '2017-02-27 11:24:40', '2017-02-28 10:54:13', '1'),
(145, 5, 'STRAWBERRY SWIRL CAKE ice', 250, 'Ice Cream_20170228105242.jpg', 'STRAWBERRY SWIRL CAKE ice cream', '2017-02-27 11:26:43', '2017-02-28 10:52:42', '1'),
(146, 4, 'pav bhaji', 80, 'Gujarati_20170228100255.jpg', 'pav bhaji', '2017-02-28 05:15:20', '2017-03-01 06:55:12', '1'),
(147, 5, 'Double Sundae Mango Straw', 200, 'Ice Cream_20170228102722.jpg', 'Double Sundae Mango Strawberry', '2017-02-28 05:19:26', '2017-02-28 10:27:22', '1'),
(148, 5, 'Double Sundae Choco Almon', 220, 'Ice Cream_20170228102708.jpg', 'Double Sundae Choco Almond Kesar Badam ', '2017-02-28 05:20:13', '2017-02-28 10:27:08', '1'),
(149, 5, 'Black Currant Spin Sundae', 170, 'Ice Cream_20170228101505.jpg', 'Black Currant Spin Sundae', '2017-02-28 05:21:08', '2017-02-28 10:15:05', '1'),
(150, 5, 'Chocolate Spin Sundae', 240, 'Ice Cream_20170228102258.jpg', 'Chocolate Spin Sundae', '2017-02-28 05:22:11', '2017-02-28 10:22:58', '1'),
(151, 5, 'Strawberry Sundae', 180, 'Ice Cream_20170228104744.jpg', 'Strawberry Sundae', '2017-02-28 05:22:52', '2017-02-28 10:47:44', '1'),
(152, 5, 'Strawberry Spin Sundae', 120, 'Ice Cream_20170228104731.jpg', 'Strawberry Spin Sundae', '2017-02-28 05:24:06', '2017-02-28 10:47:31', '1'),
(154, 5, 'Khatta Meetha Spin Sundae', 130, 'Ice Cream_20170228103510.jpg', 'Khatta Meetha Spin Sundae', '2017-02-28 05:26:29', '2017-02-28 10:35:10', '1'),
(155, 5, 'Chocolate Sundae Royale', 180, 'Ice Cream_20170228102356.jpg', 'Chocolate Sundae Royale', '2017-02-28 05:27:42', '2017-02-28 10:23:56', '1'),
(156, 5, 'Choco Sundae', 200, 'Ice Cream_20170228101822.jpg', 'Choco Sundae', '2017-02-28 05:28:40', '2017-02-28 10:18:22', '1'),
(157, 5, 'Easy Sundae', 150, 'Ice Cream_20170228102840.jpg', 'Easy Sundae', '2017-02-28 05:29:24', '2017-02-28 10:28:40', '1'),
(158, 5, 'PISTACHIO ALMOND FUDGE ic', 140, 'Ice Cream_20170228103821.jpg', 'PISTACHIO ALMOND FUDGE ice cream', '2017-02-28 05:30:45', '2017-02-28 10:38:21', '1'),
(159, 5, 'belgian chocolate ice cre', 250, 'Ice Cream_20170228101410.jpg', 'belgian chocolate ice cream', '2017-02-28 05:32:21', '2017-02-28 10:14:10', '1'),
(161, 5, 'SILK CHOCOLATE ice cream', 200, 'Ice Cream_20170228104526.jpg', 'SILK CHOCOLATE ice cream', '2017-02-28 05:35:51', '2017-02-28 10:45:26', '1'),
(163, 5, 'CHOCO BROWNIE DIP', 250, 'Ice Cream_20170228101806.jpg', 'CHOCO BROWNIE DIP', '2017-02-28 05:38:06', '2017-02-28 10:18:06', '1'),
(164, 6, 'Whole Wheat Pasta ', 120, 'Indomaxican_20170228111957.jpg', 'Whole Wheat Pasta ', '2017-02-28 05:51:18', '2017-02-28 11:19:57', '1'),
(165, 6, 'Aloo Tamatar Ka Jhol', 120, 'Indomaxican_20170228110334.jpg', 'Aloo Tamatar Ka Jhol', '2017-02-28 05:58:13', '2017-02-28 11:03:34', '1'),
(166, 6, 'Tamarind Rice', 100, 'Indomaxican_20170228111622.jpg', 'Tamarind Rice', '2017-02-28 06:00:09', '2017-02-28 11:16:22', '1'),
(167, 6, 'Jeera Vegetables', 80, 'Indomaxican_20170228110359.jpg', 'Jeera Vegetables', '2017-02-28 06:01:42', '2017-02-28 11:03:59', '1'),
(168, 6, 'Southern Style Okra', 50, 'Indomaxican_20170228111605.jpg', 'Southern Style Okra', '2017-02-28 06:04:23', '2017-02-28 11:16:05', '1'),
(169, 6, 'Mediterranean Watermelon ', 70, 'Indomaxican_20170228111327.jpg', 'Mediterranean Watermelon Salad', '2017-02-28 06:05:05', '2017-02-28 11:13:27', '1'),
(170, 6, 'Indian Stir Fry', 80, 'Indomaxican_20170228110314.jpg', ' Indian Stir Fry', '2017-02-28 06:06:14', '2017-03-01 09:19:14', '1'),
(171, 6, 'Butter Paneer', 140, 'Indomaxican_20170228110303.jpg', ' Butter Paneer', '2017-02-28 06:07:50', '2017-03-01 09:19:07', '1'),
(172, 6, 'VGV Vegetable Sandwich', 75, 'Indomaxican_20170228111945.jpg', 'VGV Vegetable Sandwich', '2017-02-28 06:08:29', '2017-02-28 11:19:45', '1'),
(173, 6, 'veg Pommes Gratin', 100, 'Indomaxican_20170228111931.jpg', 'veg Pommes Gratin', '2017-02-28 06:09:45', '2017-02-28 11:19:31', '1'),
(174, 6, 'veg Nachos with Cheese', 150, 'Indomaxican_20170228111907.jpg', 'veg Nachos with Cheese', '2017-02-28 06:12:18', '2017-02-28 11:19:07', '1'),
(175, 6, 'Veg Burrito', 70, 'Indomaxican_20170228111643.jpg', 'Veg Burrito(2pice)', '2017-02-28 06:14:37', '2017-02-28 11:16:43', '1'),
(176, 6, 'Mexican Fried Rice', 70, 'Indomaxican_20170228111338.jpg', 'Mexican Fried Rice(1dish)', '2017-02-28 06:16:44', '2017-02-28 11:13:38', '1'),
(177, 6, 'Mexican Veg Chimichangas', 80, 'Indomaxican_20170228111404.jpg', 'Mexican Veg Chimichangas', '2017-02-28 06:18:38', '2017-02-28 11:14:04', '1'),
(178, 6, 'Mexican Tacos', 100, 'Indomaxican_20170228111353.jpg', 'Mexican Tacos', '2017-02-28 06:20:34', '2017-02-28 11:13:53', '1'),
(179, 6, 'veg Chilli Bean Quesadill', 120, 'Indomaxican_20170228111718.jpg', 'veg Chilli Bean Quesadillas(2pice)', '2017-02-28 06:22:18', '2017-02-28 11:17:18', '1'),
(180, 7, 'Caprese Salad with Pesto ', 40, 'Italian_20170228112642.jpg', 'Caprese Salad with Pesto Sauce', '2017-02-28 06:28:24', '2017-02-28 11:26:42', '1'),
(181, 7, 'Eggplant Parmigiana', 100, 'Italian_20170228112310.jpg', ' Eggplant Parmigiana', '2017-02-28 06:29:59', '2017-03-01 09:19:27', '1'),
(182, 7, 'veg Panzanella', 80, 'Italian_20170228112842.jpg', 'veg Panzanella', '2017-02-28 06:31:19', '2017-02-28 11:28:42', '1'),
(183, 7, 'Bruschetta', 100, 'Italian_20170228112433.jpg', 'Bruschetta(4pice)', '2017-02-28 06:32:25', '2017-02-28 11:24:33', '1'),
(185, 7, 'Home Style Baked Pasta', 80, 'Italian_20170228112322.jpg', ' Home Style Baked Pasta', '2017-02-28 06:34:43', '2017-03-01 09:23:34', '1'),
(186, 7, 'Pasta Con Pomodoro e Basi', 80, 'Italian_20170228112724.jpg', 'Pasta Con Pomodoro e Basilico', '2017-02-28 06:36:11', '2017-02-28 11:27:24', '1'),
(187, 7, 'Soya Calzone', 80, 'Italian_20170228112335.jpg', 'Soya Calzone\r\n', '2017-02-28 06:37:44', '2017-03-01 09:23:42', '1'),
(188, 7, 'Spring Pasta With Blister', 80, 'Italian_20170228112831.jpg', 'Spring Pasta With Blistered Cherry Tomatoes ', '2017-02-28 06:39:01', '2017-02-28 11:28:31', '1'),
(189, 7, 'Charred Tomato, Pepper, a', 100, 'Italian_20170228112700.jpg', 'Charred Tomato, Pepper, and Onion Crostini', '2017-02-28 06:40:35', '2017-02-28 11:27:00', '1'),
(190, 8, 'Chana Masala ', 120, 'Panjabi_20170228113223.jpg', 'Chana Masala ', '2017-02-28 06:52:07', '2017-02-28 11:32:23', '1'),
(191, 8, 'Punjabi Kadhi Pakora', 150, 'Panjabi_20170228114134.jpg', 'Punjabi Kadhi Pakora', '2017-02-28 06:53:24', '2017-02-28 11:41:34', '1'),
(192, 8, 'Punjabi Aloo Amritsari ', 80, 'Panjabi_20170228114123.jpg', 'Punjabi Aloo Amritsari ', '2017-02-28 06:54:51', '2017-02-28 11:41:23', '1'),
(193, 8, 'Jeera Rice ', 70, 'Panjabi_20170228113455.jpg', 'Jeera Rice ', '2017-02-28 06:55:39', '2017-02-28 11:34:55', '1'),
(194, 8, 'Lobia', 70, 'Panjabi_20170228114010.jpg', 'Lobia', '2017-02-28 06:57:59', '2017-02-28 11:40:10', '1'),
(195, 8, 'Dal Maharani ', 80, 'Panjabi_20170228113447.jpg', 'Dal Maharani ', '2017-02-28 06:59:04', '2017-02-28 11:34:47', '1'),
(196, 8, 'Mooli Paratha ', 80, 'Panjabi_20170228114041.jpg', 'Mooli Paratha ', '2017-02-28 07:00:02', '2017-02-28 11:40:41', '1'),
(197, 8, 'Kadhi Chawal ', 100, 'Panjabi_20170228113505.jpg', 'Kadhi Chawal ', '2017-02-28 07:00:54', '2017-02-28 11:35:05', '1'),
(199, 8, 'Chilli Paneer', 100, 'Panjabi_20170228113143.jpg', ' Chilli Paneer', '2017-02-28 07:04:34', '2017-03-01 09:19:58', '1'),
(200, 8, 'Methi Matar Malai', 90, 'Panjabi_20170228114031.jpg', 'Methi Matar Malai', '2017-02-28 07:05:32', '2017-02-28 11:40:31', '1'),
(201, 8, 'Paneer Butter Masala', 120, 'Panjabi_20170228114103.jpg', 'Paneer Butter Masala', '2017-02-28 07:06:19', '2017-02-28 11:41:03', '1'),
(202, 8, 'Malai Paneer', 130, 'Panjabi_20170228114021.jpg', 'Malai Paneer', '2017-02-28 07:09:16', '2017-02-28 11:40:21', '1'),
(203, 8, 'Chhole Bhature', 150, 'Panjabi_20170228113434.jpg', 'Chhole Bhature', '2017-02-28 07:10:17', '2017-02-28 11:34:34', '1'),
(204, 8, 'Palak Rotis', 100, 'Panjabi_20170228114053.jpg', 'Palak Rotis(10pice)', '2017-02-28 07:12:23', '2017-02-28 11:40:53', '1'),
(205, 8, 'Shahi Paneer', 140, 'Panjabi_20170228114145.jpg', 'Shahi Paneer', '2017-02-28 07:13:17', '2017-02-28 11:41:45', '1'),
(206, 8, 'Paneer Tikka', 150, 'Panjabi_20170228114112.jpg', 'Paneer Tikka', '2017-02-28 07:14:12', '2017-02-28 11:41:12', '1'),
(207, 8, 'kaju kari', 150, 'Panjabi_20170228113515.jpg', 'kaju kari', '2017-02-28 07:15:44', '2017-02-28 11:35:15', '1'),
(208, 8, 'Aloo Paratha', 100, 'Panjabi_20170228113204.jpg', 'Aloo Paratha', '2017-02-28 07:18:55', '2017-03-11 10:42:58', '1'),
(209, 8, 'Aloo Gobi', 80, 'Panjabi_20170228113152.jpg', 'Aloo Gobi', '2017-02-28 07:19:56', '2017-02-28 11:31:52', '1'),
(210, 8, 'Baingan Bharta', 80, 'Panjabi_20170228113214.jpg', 'Baingan Bharta', '2017-02-28 07:20:57', '2017-02-28 11:32:14', '1'),
(211, 3, 'mix veg masala french fry', 70, 'French_20170301064036.jpg', 'mix veg masala french fry', '2017-03-01 06:40:36', '2017-03-01 06:40:36', '1'),
(212, 3, 'French Fry', 50, 'French_20170301064108.jpg', 'French Fry', '2017-03-01 06:41:08', '2017-03-01 06:41:08', '1'),
(213, 3, 'cheese  franch fry', 80, 'French_20170301064721.jpg', 'cheese  franch fry', '2017-03-01 06:47:21', '2017-03-01 06:47:21', '1'),
(214, 3, 'Mix Veg cheese franch fry', 100, 'French_20170301064949.jpg', 'Mix Veg cheese franch fry', '2017-03-01 06:49:49', '2017-03-01 06:49:49', '1'),
(215, 4, 'Butter  pavbhaji', 90, 'Gujarati_20170301065400.jpg', 'butter  pavbhaji , butter jain pavbhaji', '2017-03-01 06:54:00', '2017-03-01 06:54:00', '1'),
(216, 1, 'paneer manchurian', 110, 'Chinese_20170301065909.jpg', 'paneer manchurian, jain ,dry and gravy', '2017-03-01 06:59:09', '2017-03-01 06:59:09', '1'),
(217, 9, 'Locho', 120, 'Street Food_20170301070518.jpg', 'Locho', '2017-03-01 07:05:18', '2017-03-01 07:05:18', '1'),
(218, 9, 'Ponk Wada', 120, 'Street Food_20170301070647.jpg', 'Ponk Wada', '2017-03-01 07:06:47', '2017-03-01 07:06:47', '1'),
(219, 9, 'Khichyu', 50, 'Street Food_20170301070829.jpg', 'Khichyu(1dishe)', '2017-03-01 07:08:29', '2017-03-01 07:08:29', '1'),
(220, 9, 'Aloo Puri', 15, 'Street Food_20170301071105.jpg', 'Aloo Puri', '2017-03-01 07:11:05', '2017-03-01 07:11:05', '1'),
(221, 9, 'Batata vada', 20, 'Street Food_20170301071439.jpg', 'Batata vada(5pice)', '2017-03-01 07:14:39', '2017-03-11 10:26:36', '1'),
(222, 9, 'Bhel', 40, 'Street Food_20170301071842.jpg', 'Bhel,jain bhal,farali bhel', '2017-03-01 07:18:42', '2017-03-01 07:20:37', '1'),
(223, 9, 'cheese Bhel', 60, 'Street Food_20170301072008.jpg', 'cheese Bhel and cheese farali bhel', '2017-03-01 07:20:08', '2017-03-01 07:20:08', '1'),
(224, 9, 'bombay bhel', 90, 'Street Food_20170301072217.jpg', 'bombay bhel', '2017-03-01 07:22:17', '2017-03-01 07:22:17', '1'),
(225, 9, 'bread pakora', 50, 'Street Food_20170301072608.jpg', 'bread pakora(2pice)', '2017-03-01 07:26:08', '2017-03-01 07:26:08', '1'),
(226, 9, 'masala puff', 20, 'Street Food_20170301072859.jpg', 'masala puff and butter grill puff', '2017-03-01 07:28:59', '2017-03-01 07:28:59', '1'),
(227, 9, 'cheese jam  dabeli', 40, 'Street Food_20170301073335.jpg', ' cheese jam dabeli,jain  cheese jam  dabeli', '2017-03-01 07:33:35', '2017-03-01 09:20:10', '1'),
(228, 9, 'cheese vadapav', 40, 'Street Food_20170301073607.jpg', 'cheese vadapav', '2017-03-01 07:36:07', '2017-03-01 07:36:07', '1'),
(229, 9, 'schezwan vada pav', 35, 'Street Food_20170301073902.jpg', 'schezwan vada pav,butter onion vedapav', '2017-03-01 07:39:02', '2017-03-01 07:39:02', '1'),
(230, 9, 'veg frankie ', 35, 'Street Food_20170301074030.jpg', 'veg frankie ', '2017-03-01 07:40:30', '2017-03-01 07:40:30', '1'),
(231, 9, 'veg cheese  frankie ', 50, 'Street Food_20170301074221.jpg', 'veg cheese  frankie and jain veg cheese  frankie', '2017-03-01 07:42:21', '2017-03-01 07:42:21', '1'),
(232, 9, 'Sevpuri', 30, 'Street Food_20170301074628.jpg', 'Sevpuri', '2017-03-01 07:45:05', '2017-03-01 07:46:28', '1'),
(233, 9, 'Dhaipuri', 40, 'Street Food_20170301074610.jpg', 'Dhaipuri', '2017-03-01 07:46:10', '2017-03-01 07:46:10', '1'),
(234, 9, 'chaat', 50, 'Street Food_20170301075056.jpg', 'chaat', '2017-03-01 07:49:28', '2017-05-02 07:00:15', '1'),
(235, 9, 'masala pasta ', 55, 'Street Food_20170301075221.jpg', 'masala pasta ', '2017-03-01 07:52:21', '2017-03-01 07:52:21', '1'),
(236, 9, 'Veg burger', 45, 'Street Food_20170301075437.jpg', 'Veg burger', '2017-03-01 07:54:37', '2017-03-01 07:54:37', '1'),
(237, 9, 'Veg  cheese burger', 75, 'Street Food_20170301075528.jpg', 'Veg  cheese burger', '2017-03-01 07:55:28', '2017-03-01 07:55:28', '1'),
(238, 9, 'veg cheese grilled ', 80, 'Street Food_20170301075923.jpg', 'veg cheese grilled sandwich', '2017-03-01 07:59:23', '2017-03-11 10:28:37', '1'),
(239, 9, 'Veg grill sandwich', 75, 'Street Food_20170301080101.jpg', 'Veg grill sandwich', '2017-03-01 08:01:01', '2017-03-01 08:01:01', '1'),
(240, 9, 'Veg cheese grill sandwich', 85, 'Street Food_20170301080226.jpg', 'Veg cheese grill sandwich', '2017-03-01 08:02:26', '2017-03-01 08:02:26', '1'),
(241, 9, 'Veg hot dog', 40, 'Street Food_20170301080459.jpg', 'Veg hot dog', '2017-03-01 08:04:59', '2017-03-01 08:04:59', '1'),
(242, 9, 'Veg Cheese hot dog', 60, 'Street Food_20170301080646.jpg', 'Cheese veg hot dog', '2017-03-01 08:06:46', '2017-03-11 10:28:00', '1'),
(243, 9, 'pani puri', 20, 'Street Food_20170301080916.jpg', 'pani puri(6pice)', '2017-03-01 08:09:16', '2017-03-01 08:09:16', '1'),
(244, 10, 'peanut empowered noodle ', 120, 'Thai_20170301084835.jpg', 'Thai peanut empowered noodle bowl', '2017-03-01 08:48:35', '2017-03-01 09:22:45', '1'),
(245, 10, 'Thai panang vegetable cur', 100, 'Thai_20170301084909.jpg', 'thai panang vegetable curry', '2017-03-01 08:49:09', '2017-03-01 08:49:09', '1'),
(246, 10, 'Thai pomelo salad', 80, 'Thai_20170301084939.jpg', 'Thai pomelo salad', '2017-03-01 08:49:39', '2017-03-01 08:49:39', '1'),
(247, 10, 'Thai red curry soup', 95, 'Thai_20170301085021.jpg', 'Thai red curry soup', '2017-03-01 08:50:21', '2017-03-01 08:50:21', '1'),
(248, 10, 'Style sweet corn fritters', 100, 'Thai_20170301085100.jpg', 'Style sweet corn fritters', '2017-03-01 08:51:00', '2017-03-01 08:51:00', '1'),
(249, 10, 'Thai veggie burgers', 80, 'Thai_20170301085131.jpg', 'Thai veggie burgers', '2017-03-01 08:51:31', '2017-03-01 08:51:31', '1'),
(250, 10, 'Rainbow carrot summer rol', 100, 'Thai_20170301085214.jpg', 'Rainbow carrot summer rolls(2pice)', '2017-03-01 08:52:14', '2017-03-01 08:52:14', '1'),
(251, 10, 'Peanut udon noodles', 80, 'Thai_20170301085256.jpg', 'peanut udon noodles with snow peas', '2017-03-01 08:52:56', '2017-03-01 08:52:56', '1'),
(252, 10, 'Tom yum coconut noodles', 100, 'Thai_20170301085346.jpg', 'Tom yum coconut noodles', '2017-03-01 08:53:46', '2017-03-01 08:53:46', '1'),
(253, 10, 'Veggie pad thai', 70, 'Thai_20170301085429.jpg', 'veggie pad thai', '2017-03-01 08:54:29', '2017-03-01 08:54:29', '1'),
(254, 10, 'Veg massaman curry', 90, 'Thai_20170301085610.jpg', 'veg massaman curry', '2017-03-01 08:56:10', '2017-03-01 08:56:10', '1'),
(255, 10, 'sweet potato nachos', 100, 'Thai_20170301085745.jpg', 'Veg thai sweet potato nachos', '2017-03-01 08:57:45', '2017-03-01 09:23:17', '1'),
(256, 10, 'Thai barley salad', 70, 'Thai_20170301085843.jpg', 'Thai barley salad', '2017-03-01 08:58:43', '2017-03-01 08:58:43', '1'),
(257, 10, 'kabocha curry with caulif', 90, 'Thai_20170301090022.jpg', 'thai kabocha squash curry with kale and cauliflower', '2017-03-01 09:00:22', '2017-03-01 09:00:22', '1'),
(258, 10, 'sweet  &sour pasta salad', 80, 'Thai_20170301090207.jpg', 'sweet and sour thai cucumber pasta salad', '2017-03-01 09:02:07', '2017-03-01 09:02:07', '1'),
(259, 10, 'red curry with asparagus&', 100, 'Thai_20170301090342.jpg', 'veg thai red curry with asparagus and tofu', '2017-03-01 09:03:42', '2017-03-01 09:03:42', '1'),
(260, 10, 'Thai peanut soup', 90, 'Thai_20170301090600.jpg', 'Thai peanut soup', '2017-03-01 09:06:00', '2017-03-01 09:06:00', '1'),
(261, 10, 'Tofu and noodle salad', 90, 'Thai_20170301090711.jpg', 'thai tofu and noodle salad', '2017-03-01 09:07:11', '2017-03-01 09:23:09', '1'),
(262, 10, 'Green Papaya Salad ', 70, 'Thai_20170301091059.jpg', ' Green Papaya Salad ', '2017-03-01 09:10:59', '2017-03-01 09:22:10', '1'),
(263, 10, 'Stir Fried Greens', 70, 'Thai_20170301091347.jpg', 'Stir Fried Greens', '2017-03-01 09:13:47', '2017-03-01 09:13:47', '1'),
(264, 10, 'Chilli Broccoli Salad ', 80, 'Thai_20170301091451.jpg', 'Thai Chilli Broccoli Salad ', '2017-03-01 09:14:51', '2017-03-01 09:14:51', '1'),
(265, 13, 'Rava Dosa', 80, 'Breakfast_20170304102118.jpg', 'Rava Dosa', '2017-03-04 10:21:18', '2017-03-04 10:21:18', '1'),
(266, 13, 'poha Batata', 70, 'Breakfast_20170304102343.jpg', 'poha Batata', '2017-03-04 10:23:43', '2017-03-04 10:23:43', '1'),
(267, 13, 'Upma', 70, 'Breakfast_20170304102427.jpg', 'Upma', '2017-03-04 10:24:27', '2017-03-04 10:24:27', '1'),
(268, 13, 'Sprouts Jalfrezi', 80, 'Breakfast_20170304102557.jpg', 'Sprouts Jalfrezi', '2017-03-04 10:25:57', '2017-03-04 10:25:57', '1'),
(269, 13, 'Steamed Dhokla', 50, 'Breakfast_20170304102643.jpg', 'Steamed Dhokla(6pice)', '2017-03-04 10:26:43', '2017-03-04 10:26:43', '1'),
(270, 13, 'Aloo Paratha', 100, 'Breakfast_20170304102807.jpg', 'Aloo Paratha(4pice)', '2017-03-04 10:28:07', '2017-03-11 10:25:29', '1'),
(271, 13, 'Oats Idli', 80, 'Breakfast_20170304102910.jpg', 'Oats Idli', '2017-03-04 10:29:10', '2017-03-04 10:29:10', '1'),
(272, 13, 'Uttapam', 70, 'Breakfast_20170304102951.jpg', 'Uttapam', '2017-03-04 10:29:51', '2017-03-04 10:29:51', '1'),
(273, 13, 'Cheesy Grilled Onion Sandwich', 70, 'Breakfast_20170304103256.jpg', 'Cheesy Grilled Onion Sandwich', '2017-03-04 10:32:56', '2017-03-11 10:31:49', '1'),
(285, 13, 'Methi Muthias', 70, 'Breakfast_20170304111001.jpg', ' Methi Muthias(7pice)', '2017-03-04 11:10:01', '2017-03-04 11:10:01', '1'),
(286, 13, 'Thepla', 50, 'Breakfast_20170304111059.jpg', 'Thepla(3pice)', '2017-03-04 11:10:59', '2017-03-04 11:10:59', '1'),
(287, 13, 'Handva', 60, 'Breakfast_20170304111257.jpg', 'Handva', '2017-03-04 11:12:57', '2017-03-04 11:12:57', '1'),
(288, 13, 'khaman ', 100, 'Breakfast_20170304113114.jpg', 'khaman ', '2017-03-04 11:31:14', '2017-03-04 11:31:14', '1'),
(289, 13, 'Condiments(patuli)', 80, 'Breakfast_20170304113627.jpg', 'Condiments(patuli', '2017-03-04 11:36:27', '2017-03-04 11:36:27', '1'),
(291, 12, 'Bedouin Tea', 40, 'drinks_20170329103006.jpg', 'Bedouin Tea', '2017-03-29 10:30:06', '2017-03-29 10:30:06', '1'),
(292, 12, 'Black Tea', 30, 'drinks_20170329103056.jpg', 'Black Tea', '2017-03-29 10:30:56', '2017-03-29 10:30:56', '1'),
(293, 12, 'Choco Coffee', 80, 'drinks_20170329103126.jpg', 'Choco Coffee', '2017-03-29 10:31:26', '2017-03-29 10:31:26', '1'),
(294, 12, 'Green Tea', 40, 'drinks_20170329103149.jpg', 'Green Tea', '2017-03-29 10:31:49', '2017-03-29 10:31:49', '1'),
(295, 12, 'Herbal And Fruit Teas', 50, 'drinks_20170329103213.jpg', 'Herbal And Fruit Teas', '2017-03-29 10:32:13', '2017-03-29 10:32:13', '1'),
(296, 12, 'Iced Coffee Homemade', 60, 'drinks_20170329103314.jpg', 'Iced Coffee (Homemade)', '2017-03-29 10:33:14', '2017-03-29 10:33:14', '1'),
(297, 12, 'Normal Tea', 20, 'drinks_20170329103349.jpg', 'Normal Tea', '2017-03-29 10:33:49', '2017-03-29 10:33:49', '1'),
(298, 12, 'Oolong', 30, 'drinks_20170329103440.jpg', 'Oolong', '2017-03-29 10:34:40', '2017-03-29 10:34:40', '1'),
(299, 12, 'Real Pan Brewed Coffee', 60, 'drinks_20170329103533.jpg', 'Real Pan-Brewed Coffee', '2017-03-29 10:35:33', '2017-03-29 10:35:33', '1'),
(300, 12, 'Vietnamese Iced Coffee', 80, 'drinks_20170329103558.jpg', 'Vietnamese Iced Coffee', '2017-03-29 10:35:58', '2017-03-29 10:35:58', '1'),
(301, 12, 'Vietnamese Style Iced Coffee', 80, 'drinks_20170329103624.jpg', 'Vietnamese Style Iced Coffee', '2017-03-29 10:36:24', '2017-03-29 10:36:24', '1'),
(302, 16, 'Doodhpak', 180, 'sweets _20170329104138.jpg', 'Doodhpak', '2017-03-29 10:41:38', '2017-03-29 10:41:38', '1'),
(303, 16, 'Lapsi', 150, 'sweets _20170329104235.jpg', 'Lapsi (surti)', '2017-03-29 10:42:35', '2017-03-29 10:42:35', '1'),
(304, 16, 'Shrikhand', 200, 'sweets _20170329104404.jpg', 'Shrikhand', '2017-03-29 10:44:04', '2017-03-29 10:44:04', '1'),
(305, 16, 'Kesar Shrikhand ', 180, 'sweets _20170329104912.jpg', 'Kesar Shrikhand ', '2017-03-29 10:49:12', '2017-03-29 10:49:12', '1'),
(306, 16, 'Mango shrikhand ', 200, 'sweets _20170329105335.jpg', 'Mango shrikhand ', '2017-03-29 10:53:35', '2017-03-29 10:53:35', '1'),
(307, 16, 'Kesar Pista', 220, 'sweets _20170329105644.jpg', 'Kesar Pista', '2017-03-29 10:56:44', '2017-03-29 10:56:44', '1'),
(308, 16, 'chocolate shrikhand', 300, 'sweets _20170329111044.jpg', 'chocolate shrikhand', '2017-03-29 11:10:44', '2017-03-29 11:10:44', '1'),
(309, 16, 'rajbhog shrikhand', 250, 'sweets _20170329111224.jpg', 'rajbhog shrikhand', '2017-03-29 11:12:24', '2017-03-29 11:12:24', '1'),
(310, 16, 'american dry fruit shrikhand', 270, 'sweets _20170329111422.jpg', 'american dry fruit shrikhand', '2017-03-29 11:14:22', '2017-03-29 11:14:22', '1'),
(311, 16, 'Badam pista shrikhand', 200, 'sweets _20170329111512.jpg', 'badam pista shrikhand', '2017-03-29 11:15:12', '2017-03-29 11:15:12', '1'),
(312, 16, 'Elaichi shrikhand', 190, 'sweets _20170329111605.jpg', 'elaichi shrikhand', '2017-03-29 11:16:05', '2017-03-29 11:16:05', '1'),
(313, 16, 'rabdi shrikhand', 200, 'sweets _20170329111731.jpg', 'rabdi shrikhand', '2017-03-29 11:17:31', '2017-03-29 11:17:31', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_taste`
-- 

CREATE TABLE `tbl_taste` (
  `taste_id` int(11) NOT NULL auto_increment,
  `taste_name` varchar(20) NOT NULL,
  `taste_entry_date` datetime NOT NULL,
  `taste_modify_date` datetime NOT NULL,
  `taste_is_status` char(3) NOT NULL default '1',
  PRIMARY KEY  (`taste_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `tbl_taste`
-- 

INSERT INTO `tbl_taste` (`taste_id`, `taste_name`, `taste_entry_date`, `taste_modify_date`, `taste_is_status`) VALUES 
(1, 'normal', '2017-04-18 00:00:00', '2017-04-18 00:00:00', '1'),
(2, 'spicy', '2017-04-18 00:00:00', '2017-04-18 00:00:00', '1'),
(3, 'jain', '2017-04-18 00:00:00', '2017-04-18 00:00:00', '1');
