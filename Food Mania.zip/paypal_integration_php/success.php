<?php
include 'dbConfig.php';



include_once("../Food Mania/client_connection.php");
$con = new client_connection();
$con->client_connect();

//Get payment information from PayPal
//echo $item_number = $_REQUEST['item_number']."<br>"; 
// $txn_id = $_REQUEST['PHPSESSID']."<br>";
// echo $payment_gross = $_REQUEST['amt']."<br>";
// echo $currency_code = $_REQUEST['cc']."<br>";
// echo $payment_status = $_REQUEST['st']."<br>";

// print_r($_POST);
// echo "<br>";
// print_r($_GET);    
// echo "<br>";
// print_r($_REQUEST);
// echo "<br>";
// print_r($_SESSION);
// echo "<br>";
// print_r($_SERVER);
// echo "<br>";
//print_r($_COOKIE);



// //Get product total_product_price from database
// $res=mysqli_query($db,"SELECT total_product_price FROM products WHERE paypal_product_id = ".$item_number);
// $ans=mysql_fetch_row($res);

// $ans=mysqli_fetch_row($res);
// $productPrice = $ans['total_product_price'];

// if(!empty($txn_id) && $payment_gross == $productPrice)
// {
// 	//Check if payment data exists with the same TXN ID.
//     $prevPaymentResult = $db->query("SELECT payment_id FROM payments WHERE txn_id = '".$txn_id."'");

//     if($prevPaymentResult->num_rows > 0)
//     {
//         $paymentRow = $prevPaymentResult->fetch_assoc();
//         $last_insert_id = $paymentRow['payment_id'];
//     }
//     else
    // {
        //Insert tansaction data into the database


$q="SELECT * FROM products WHERE paypal_product_id=(SELECT MAX(paypal_product_id) FROM products)";
$r=mysql_query($q);
$a=mysql_fetch_array($r);

$txn_id=rand(10,10000);
$payment_gross=$a['total_product_price'];
$order_id=$a['order_id'];


    $query="INSERT INTO payments VALUES(NULL,'".$txn_id."','".$payment_gross."','USD','1')";
    if(mysql_query($query))
    {
        $_SESSION['order_id']=$order_id;
        header("Location:../Food Mania/send_otp.php?paypal=paypal_successfull&order_id=$order_id"); 
    }
    else
    {
        header("Location:../Food Mania/cart.php?paypal=paypal_cancle"); 
    }   
    // }
    // header("Location:../Food Mania/cart.php?paypal=paypal_successfil&notic=thank");
    
// }
// else
// { 
    // header("Location:../Food Mania/cart.php?paypal=paypal_cancle"); 
// } ?>