<?php
//Include db configuration file
include 'dbConfig.php';

session_start();
if(!isset($_SESSION['customer']))
{
    header("Location:../food mania/registration.php?mm=no_login");
}

include_once("../Food Mania/client_connection.php");
include_once("../Food Mania/food_mania_admin/production/connection.php");
$con = new client_connection();
$con->client_connect();

$con2 = new connection();
$con2->connect();

$tmp="select";
$register_id=$_GET['register_id'];
$res=$con2->iuds_tbl_redister($tmp,$register_id,$fname,$lname,$address,$gender,$bod,$contect,$email,$pass,$status,$ip_address);

$tmp="select";
$order_id=$_GET['order_id'];
$res2=$con2->iuds_order($tmp,$order_id,$status);



//Set useful variables for paypal form
$paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
$paypalID = "kishandholakiyabusiness@gmail.com"; //Business Email

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Food Mania</title>
</head>
<body style="text-align:center">
<?php

$query="INSERT INTO products VALUES(NULL,
                                    ".$_GET['register_id'].",
                                    ".$_GET['order_id'].",
                                    '".$res2['order_total_quantity_and_price']."',
                                    ".$_GET['total_payment'].",
                                    '1')";

mysql_query($query);
$res3=mysql_query("SELECT MAX(paypal_product_id) FROM products");

	
?>
    <h1>Please Wait For Connect with Paypal</h1>
    <form id="frm" action="<?php echo $paypalURL; ?>" method="post" style="font-size:20px;">

        <!-- Identify your business so that you can collect the payments. -->
        <input type="hidden" name="business" value="<?php echo $paypalID; ?>">
        
        <!-- Specify a Buy Now button. -->
        <input type="hidden" name="cmd" value="_xclick">
        
        <!-- Specify details about the item that buyers will purchase. -->
        <input type="hidden" name="item_name" value="<?php echo $res2['order_total_quantity_and_price']; ?>">
        <input type="hidden" name="item_number" value="<?php echo $res3[0]; ?>">
        <input type="hidden" name="amount" value="<?php echo  $_GET['total_payment']; ?>">
        <input type="hidden" name="currency_code" value="USD">
        
        <!-- Specify URLs -->
        <input type='hidden' name='cancel_return' value='http://localhost/paypal_integration_php/cancel.php'>
		<input type='hidden' name='return' value='http://localhost/paypal_integration_php/success.php'>
        
        <!-- Display the payment button. -->
        <!-- <input type="image" name="submit" border="0"
        src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
        <img alt="" border="0" width="1" height="1" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" > -->
    </form>
<script src="jquery-3.1.1.min.js"></script>
<script>
$(document).ready(function(){
    $("#frm").submit();
});
</script>



</body>
</html>
