Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/paypal-standard-payment-gateway-integration-php/

============ Instruction ============

1. Create a database (codexworld) and import the products_payments.sql file into the database (codexworld).

2. Open the "dbConfig.php" file and change $dbHost, $dbUsername, $dbPassword and $dbName variable values with your database credentials.

3. Open the "products.php" file and change the $paypalID variable value with your PayPal business email.

4. Now run the "products.php" file and test the functionality. 

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/paypal-standard-payment-gateway-integration-php/#respond. We will reply your query ASAP.